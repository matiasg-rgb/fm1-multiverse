#!/bin/sh
set -eu
cd "$(dirname "$0")"
"${CLANG:-clang}" --target=wasm32 -O2 -nostdlib -ffreestanding -fvisibility=hidden -Iengine -Ifw/firmware/gen \
  -Wl,--no-entry -Wl,--export-dynamic -Wl,--initial-memory=2097152 -Wl,-z,stack-size=131072 \
  -o web/wa_tur.wasm engine/kt_wasm.c
python3 make_web.py
