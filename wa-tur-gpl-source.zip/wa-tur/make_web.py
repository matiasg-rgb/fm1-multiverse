from pathlib import Path
from base64 import b64encode
root=Path(__file__).resolve().parent
w=b64encode((root/'web/wa_tur.wasm').read_bytes()).decode()
html=r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>WA TUR / a world shaped by sound — M-VAVE FM-1 synth</title>
<style>
:root{color-scheme:light;--ink:#263244;--muted:#697586;--border:#e6e9ef;--pink:#ff478f;--blue:#536df8;--cyan:#2ad8e5;--lime:#b8e536}
*{box-sizing:border-box}body{margin:0;background:#fafbfd;color:var(--ink);font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif}
button,input{font:inherit}button{cursor:pointer}button:focus-visible,input:focus-visible{outline:2px solid var(--blue);outline-offset:3px}
.main{max-width:1510px;margin:auto;padding:25px 28px 34px}.topbar{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:0 0 23px;flex-wrap:wrap}
.title{font-size:38px;letter-spacing:.25em;font-weight:550;line-height:1.1}.title b{font-weight:400;background:linear-gradient(130deg,var(--blue),var(--pink),#ffa83d);color:transparent;background-clip:text}
.sub{font-size:10px;letter-spacing:.23em;text-transform:uppercase;color:var(--muted);margin-top:7px}
.start{border:0;color:white;background:#28344b;border-radius:30px;padding:14px 27px;font-weight:650;letter-spacing:.08em;box-shadow:0 6px 18px #28344b24}
.start.on{background:#4057a3}.stage{background:white;border:1px solid var(--border);border-radius:18px;box-shadow:0 12px 45px #2530530c;overflow:hidden;position:relative}
#world{width:100%;height:auto;display:block;aspect-ratio:12/5}.stage-note{position:absolute;bottom:16px;left:22px;font:10px ui-monospace,Menlo,monospace;color:#7d8996;letter-spacing:.08em}
.tools{display:grid;grid-template-columns: minmax(0,1fr) 275px;gap:20px;margin-top:20px}.panel{border:1px solid var(--border);border-radius:15px;background:white;padding:19px}.rowhead{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}
h2{margin:0;font-size:12px;letter-spacing:.16em;font-weight:650;text-transform:uppercase}.micro{font-size:11px;color:var(--muted)}
.settings{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:24px 28px}
.knob .lab{display:flex;justify-content:space-between;gap:8px;font-size:12px;margin-bottom:9px;letter-spacing:.08em;font-weight:600}.knob .val{color:var(--muted);font:12px ui-monospace,monospace}
.knob input{width:100%;height:6px;accent-color:var(--blue);cursor:pointer}.knob:nth-child(3n + 2) input{accent-color:var(--pink)}.knob:nth-child(3n) input{accent-color:#82ad1b}
.scenegrid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:15px}
.scene-btn{border:1px solid #e1e5ed;padding:10px 7px;border-radius:9px;background:#fcfdff;letter-spacing:.06em;font-size:10px;color:#6a788d}
.scene-btn.sel{border-color:var(--blue);background:#f0f3ff;color:#3b50a7;font-weight:800}
.acts{display:flex;flex-wrap:wrap;gap:7px;margin:14px 0}.tag{background:#f8f9fd;border:1px solid #e4e8ef;border-radius:20px;padding:8px 11px;font-size:11px;color:#6b7688;letter-spacing:.06em}
.tag.on{background:#eaf1fc;color:#3445b3;border-color:#b2c7f9}
.screenwrap{display:grid;justify-content:center;gap:10px;background:#f9fafc;border-radius:9px;padding:13px 10px 16px}
#native{display:block;width:240px;height:240px;image-rendering:pixelated;border:1px solid #d4d9e2;box-shadow:0 3px 12px #00000013}
.screencap{font:10px ui-monospace,monospace;letter-spacing:.04em;color:#788396;text-align:center}
.meters{display:flex;gap:9px;margin:17px 0}.meter{flex:1;min-width:0}.meter .nm{font-size:9px;letter-spacing:.14em;color:#8490a1}.track{background:#ecf0f4;height:4px;border-radius:8px;overflow:hidden;margin-top:6px}.fill{height:100%;width:0%;background:var(--blue);transition:width .09s}.meter:nth-child(2) .fill{background:var(--pink)}.meter:nth-child(3) .fill{background:#99c81c}.meter:nth-child(4) .fill{background:var(--cyan)}
.keys{display:flex;justify-content:center;gap:3px;padding-top:6px;touch-action:manipulation}.key{width:31px;height:74px;border:1px solid #cbd3df;border-radius:0 0 6px 6px;background:linear-gradient(180deg,#ffffff,#f3f6fc);box-shadow:0 4px 0 #dce1ea;cursor:pointer;font-size:11px;color:#9ca7b5;display:flex;align-items:flex-end;justify-content:center;padding-bottom:8px}.key:active,.key.held{background:#dce3ff;border-color:#8aa2ee;box-shadow:0 2px 0 #b6c4ee}
.notes{color:#8190a1;font-size:11px;line-height:1.6;margin-top:16px}.note{display:flex;gap:6px;align-items:center} .dot{width:7px;height:7px;border-radius:50%;background:#8bcad0;display:inline-block}
.foot{color:#8995a3;font-size:11px;margin-top:20px;line-height:1.7}#err{color:#b30039;font-size:12px}
@media(max-width:1020px){.tools{grid-template-columns:1fr}.settings{grid-template-columns:repeat(3,1fr)}.scenegrid{grid-template-columns:repeat(4,1fr)}}
@media(max-width:570px){.main{padding:16px}.title{font-size:26px}.settings{grid-template-columns:repeat(2,1fr)}.scenegrid{grid-template-columns:repeat(2,1fr)}.panel{padding:12px}.key{width:26px;height:67px}.topbar{align-items:start}}
</style></head><body><div class="main">
<div class="topbar"><div><div class="title">W<b>A</b> TUR</div><div class="sub">percussive acoustic–electric bass · topology in sound</div></div><button class="start" id="start">▶  ACTIVATE AUDIO</button></div>
<div class="stage"><canvas id="world" width="1200" height="500"></canvas><div class="stage-note" id="stageStatus">4D PROJECTED SURFACE · ONE COUPLED MODULATION BUS</div></div>
<div class="tools"><div class="panel"><div class="rowhead"><h2>Sound ⇄ Shape</h2><span class="micro" id="meta">Scene 01 · 88 BPM</span></div>
<div class="settings" id="settings"></div>
<div class="rowhead" style="margin-top:23px;margin-bottom:4px"><h2>Tonal worlds / operatic voices</h2><span class="micro">8 integrated sonic worlds</span></div><div class="scenegrid" id="scenes"></div>
<div class="acts"><button id="mode" class="tag">GEOMETRY · 4D PROJECTION</button><button id="percussion" class="tag on">PERCUSSION · ON</button><button id="balls" class="tag on">BALLS · ON</button><button id="auto" class="tag">GENERATIVE BASS · OFF</button><button id="hit" class="tag">STRIKE ●</button></div>
<div class="meters"><div class="meter"><div class="nm">LOW</div><div class="track"><div class="fill" id="mLow"></div></div></div><div class="meter"><div class="nm">BUZZ</div><div class="track"><div class="fill" id="mBuzz"></div></div></div><div class="meter"><div class="nm">TREBLE</div><div class="track"><div class="fill" id="mHigh"></div></div></div><div class="meter"><div class="nm">PERC</div><div class="track"><div class="fill" id="mPerc"></div></div></div></div>
<div class="rowhead"><h2>Play bass and operatic voices</h2><span class="micro">Use keyboard A–K or click</span></div><div class="keys" id="keys"></div>
<div class="notes">A struck sphere changes the bass filter, compresses the terrain, and releases visible contour rings. Buzz draws upper harmonics and sharper ridges; acoustic string body shapes the low hills. Vintage Lagoon adds an original crooning amphibious singer, a shellac-disc crackle texture, and singing-responsive facial animation. The animated “4D” mode is a projection through an evolving additional coordinate, not literal four-dimensional space.</div>
</div><aside class="panel"><div class="rowhead"><h2>FM-1 / native display</h2></div><div class="screenwrap"><canvas id="native" width="240" height="240"></canvas><div class="screencap">240 × 240 RGB565 · exact shared C renderer</div></div><div class="notes" style="margin-top:18px"><div class="note"><span class="dot"></span><span>Same WebAssembly synthesis as firmware source</span></div><div class="note"><span class="dot"></span><span>White field, falling percussion spheres, line-to-terrain morph</span></div></div><div class="foot">Device preview is a software rendering—not a photo of a flashed FM-1. Browser performance canvas uses the same modulation signals at higher resolution.</div></aside></div>
<div class="foot">WA TUR · GPL-3.0 · built on the K-Tea / Dinghy / Felucca FM-1 platform · stereo 44.1 kHz engine · firmware source and tests included. <span id="err"></span></div></div>
<script>
'use strict';
const wasmBase64='__WASM__';
const NAMES=['PURE STRING','FELT WOOD','THUMB BASS','WIRE BUZZ','SOPRANO','BARITONE','OPERA CHOIR','VINTAGE LAGOON'];
const TEMPOS=[88,64,104,116,76,93,128,110];
const KNOBS=['TONE','PLUCK','BUZZ','TERRAIN','DEPTH','DIMENSION'];
const COLORS=[['#5872fc','#fc92bd','#dba1a5','#597bd9'],['#8291ae','#a5afbe','#dca8b4','#a69a94'],['#2349ce','#21b4b0','#95e17e','#f69b55'],['#1ed3f5','#b95aff','#ff5c75','#ffc857'],['#32beac','#83cbd0','#eaa5ba','#8d8ee5'],['#597dd1','#b6dbfb','#efb064','#a585db'],['#1871e9','#a658ff','#ff4acc','#f6bb38'],['#7d948c','#d0c59d','#c4d4bc','#416e70']];
const PAT_K=[0x1111,0x1001,0x1111,0x5151,0x1011,0x1111,0x5555,0x1555];
const PAT_W=[0x0100,0x0400,0x0440,0x2222,0x0802,0x0404,0x2222,0x2A22];
const PAT_H=[0x1111,0x0000,0x5555,0xAAAA,0x1515,0x5555,0xFFFF,0xAAAA];
const root=document.documentElement; const $=id=>document.getElementById(id);
const wc=$('world'),wg=wc.getContext('2d');const nc=$('native'),ng=nc.getContext('2d');
let a,context,processor,playing=false,scene=0,geom=2,balls=true,percussion=true,autoplay=false,ready=false,t0=performance.now();
const sliders=[],vals=[62,78,12,22,20,7];
const settings=$('settings');
KNOBS.forEach((name,i)=>{const box=document.createElement('div');box.className='knob';box.innerHTML=`<div class="lab"><span>${name}</span><span class="val" id="v${i}">${vals[i]}</span></div><input type="range" id="p${i}" min="0" max="127" value="${vals[i]}" aria-label="${name}">`;settings.append(box); const input=box.querySelector('input');input.addEventListener('input',()=>{vals[i]=+input.value;$('v'+i).textContent=vals[i];if(ready)a.kt_set_param(i,vals[i]);});sliders.push(input);});
const scenegrid=$('scenes');NAMES.forEach((name,i)=>{const b=document.createElement('button');b.textContent=`0${i+1} · ${name}`;b.className='scene-btn';b.addEventListener('click',()=>setScene(i));scenegrid.append(b);});
const keys=[]; 'ASDFGHJKL'.split('').forEach((sym,i)=>{let b=document.createElement('button');b.className='key';b.textContent=sym;b.onpointerdown=e=>{e.preventDefault();b.setPointerCapture?.(e.pointerId);key(i,true);b.classList.add('held');};b.onpointerup=b.onpointercancel=e=>{key(i,false);b.classList.remove('held');};$('keys').append(b);keys.push(b);});
function key(i,on){if(ready)a.kt_key(i,on?1:0);}
document.addEventListener('keydown',e=>{if(e.repeat||e.target.tagName==='INPUT'||e.target.tagName==='BUTTON')return;let i='ASDFGHJKL'.indexOf(e.key.toUpperCase());if(i>=0){key(i,true);keys[i]?.classList.add('held');}});
document.addEventListener('keyup',e=>{let i='ASDFGHJKL'.indexOf(e.key.toUpperCase());if(i>=0){key(i,false);keys[i]?.classList.remove('held');}});
function sync(){if(!ready)return;for(let i=0;i<6;i++){vals[i]=a.kt_get_param(i);sliders[i].value=vals[i];$('v'+i).textContent=vals[i];}
 [...scenegrid.children].forEach((b,i)=>b.classList.toggle('sel',i===scene));$('meta').textContent=`Scene 0${scene+1} · ${TEMPOS[scene]} BPM`;
 $('percussion').classList.toggle('on',percussion);$('balls').classList.toggle('on',balls);$('auto').classList.toggle('on',autoplay);
 $('percussion').textContent='PERCUSSION · '+(percussion?'ON':'OFF');$('balls').textContent='BALLS · '+(balls?'ON':'OFF');$('auto').textContent='GENERATIVE BASS · '+(autoplay?'ON':'OFF');
 $('mode').textContent=['GEOMETRY · 2D CONTOUR','GEOMETRY · 3D RELIEF','GEOMETRY · 4D SLICE','GEOMETRY · HYPERFOLD'][geom];}
function setScene(i){scene=i;if(ready)a.kt_set_species(scene);sync();}
$('mode').onclick=()=>{geom=(geom+1)%4;a?.kt_button(6);sync();};
$('percussion').onclick=()=>{percussion=!percussion;a?.kt_button(10);sync();};
$('balls').onclick=()=>{balls=!balls;a?.kt_button(2);sync();};
$('auto').onclick=()=>{autoplay=!autoplay;a?.kt_button(12);sync();};
$('hit').onclick=()=>{a?.kt_button(7);};
async function boot(){if(ready)return;
 let raw=atob(wasmBase64),data=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)data[i]=raw.charCodeAt(i);
 let wasm=await WebAssembly.instantiate(data.buffer,{});a=wasm.instance.exports;a.kt_init(17972);ready=true;sync();}
let chunk=new Float32Array(512),cursor=256,ratio=1;
function fill(){a.kt_audio_buf(256);const src=new Int32Array(a.memory.buffer,a.kt_abuf(),512);for(let i=0;i<512;i++)chunk[i]=src[i]/32768;}
async function start(){try{await boot();if(!context){context=new (window.AudioContext||window.webkitAudioContext)({sampleRate:44100,latencyHint:'interactive'});ratio=44100/context.sampleRate;
 processor=context.createScriptProcessor(1024,0,2);processor.onaudioprocess=e=>{let l=e.outputBuffer.getChannelData(0),r=e.outputBuffer.getChannelData(1);for(let i=0;i<l.length;i++){
 if(!playing){l[i]=r[i]=0;continue;}while(cursor>=256){cursor-=256;fill();}
 let p=cursor|0,f=cursor-p,j=Math.min(p+1,255);
 l[i]=(chunk[2*p]*(1-f)+chunk[2*j]*f)*.82;r[i]=(chunk[2*p+1]*(1-f)+chunk[2*j+1]*f)*.82;
 cursor+=ratio;}};processor.connect(context.destination);
 }
 await context.resume();playing=true;
 if(!autoplay){autoplay=true;a.kt_button(12);}
 $('start').textContent='■  PAUSE AUDIO';$('start').classList.add('on');sync();
 }catch(e){$('err').textContent='Audio activation error: '+e.message;console.error(e);}}
$('start').onclick=async()=>{if(playing){playing=false;$('start').textContent='▶  ACTIVATE AUDIO';$('start').classList.remove('on');await context?.suspend();}else await start();};
const image=ng.createImageData(240,240);let lastNative=0;
function drawNative(ts){if(!ready||ts-lastNative<50)return;lastNative=ts;
 a.kt_render_rows(0,240);const src=new Uint16Array(a.memory.buffer,a.kt_fb(),240*240),dst=image.data;
 for(let i=0;i<src.length;i++){let v=src[i];dst[i*4]=(v>>11)*255/31;dst[i*4+1]=((v>>5)&63)*255/63;dst[i*4+2]=(v&31)*255/31;dst[i*4+3]=255;}ng.putImageData(image,0,0);
}
const minmax=(v,min,max)=>Math.max(min,Math.min(max,v));
function drawWorld(ts){const w=wc.width,h=wc.height,t=(ts-t0)/1000,cs=COLORS[scene];let lo=0,high=0,bright=0,mid=0,impact=0,osc=0,phase=0,step=0;
 if(ready){lo=a.kt_visual_low();mid=a.kt_visual_mid();high=a.kt_visual_high();bright=a.kt_visual_bright();impact=a.kt_visual_perc();osc=a.kt_visual_osc()/65536;phase=a.kt_visual_phase()/65536;step=a.kt_visual_step();}
 wg.fillStyle='#fff';wg.fillRect(0,0,w,h);
 // Subtle graph-paper perspective. Colour appears only as the sound constructs it.
 wg.strokeStyle='#e8edf4';wg.lineWidth=.7;for(let i=0;i<8;i++){let y=110+i*i*4.0;wg.beginPath();wg.moveTo(0,y);wg.lineTo(w,y);wg.stroke();}
 wg.strokeStyle='#edf0f4';for(let x=0;x<w;x+=50){wg.beginPath();wg.moveTo(x,120);wg.lineTo(x+80,h);wg.stroke();}
 let terrain=vals[3]/127,depth=vals[4]/127,dimension=vals[5]/127,buzz=vals[2]/127;
 let layers=7+Math.round(terrain*21),energy=minmax(lo/4000,0,1.5),treble=minmax(high/1200,0,1.6),gloss=minmax(bright/11500,0,1);
 const topX=115,baseY=260,spacing=3.6+depth*6;
 for(let layer=layers-1;layer>=0;layer--){
  wg.beginPath();let amp=23+terrain*90+energy*95,drift=t*.32+(osc/20000);
  for(let x=0;x<w+3;x+=3){let px=x/w, z=layer/layers,angle=px*15.7+drift+z*2.2;
   let fundamental=Math.sin(angle)*amp*(.3+.8*px),upper=Math.sin(angle*2.35+z*6)*((buzz*30+treble*16)*px),fizz=Math.sin(angle*5.1+z*12)*((gloss*10+buzz*12)*px);
   let latent=Math.sin(t*.42+z*7.0+px*3.0)*dimension*40;
   let y=baseY+layer*spacing+px*34-(fundamental+upper+fizz)*.47;
   if(geom==0)y=baseY+layer*3.8+px*15-fundamental*.45;
   if(geom==1)y+=z*z*depth*53;
   if(geom==2)y+=latent;
   if(geom==3)y+=latent+Math.cos(t*.41+z*13+px*11)*dimension*45;
   y-=Math.sin((px-z)*18+t*2.0)*(minmax(impact/3000,0,1))*18;
   if(x===0)wg.moveTo(x,y);else wg.lineTo(x,y);
  }
  wg.strokeStyle=cs[(layer+scene)%4];wg.lineWidth=1.4+(layers-layer)/layers*.65;wg.globalAlpha=minmax(.27+.5*(1-layer/layers),.12,.85);wg.stroke();
 }
 wg.globalAlpha=1;
 // Oscillator source trace: exactly linked to sonic phase, becoming the world on its right.
 wg.beginPath();wg.strokeStyle='#42516d';wg.lineWidth=1.55;
 for(let x=15;x<topX+110;x+=2){let u=x/200,sc=Math.sin(u*24+osc/5000)*15+Math.sin(u*48+osc/2500)*12*buzz;
 let y=258+sc*(.2+.8*u);if(x===15)wg.moveTo(x,y);else wg.lineTo(x,y);}wg.stroke();
 // Falling percussion balls live above the shared topology and project impact rings.
 const pats=[PAT_K[scene],PAT_W[scene],PAT_H[scene]],xp=[w*.48,w*.64,w*.80],ballColors=[cs[0],cs[2],cs[1]],envs=ready?[a.kt_visual_kick(),a.kt_visual_wood(),a.kt_visual_hat()]:[0,0,0];
 let next=(step+1)&15;
 for(let j=0;j<3;j++){
  let scheduled=percussion&&((pats[j]&(1<<next))!==0),r=(scheduled?17:12)+j*3,y=scheduled?75+phase*phase*240:78;
  wg.beginPath();wg.ellipse(xp[j],346,32,5,0,0,Math.PI*2);wg.fillStyle='#b7bfcd25';wg.fill();
  if(balls){const grad=wg.createRadialGradient(xp[j]-r*.35,y-r*.45,1,xp[j],y,r);grad.addColorStop(0,'#ffffff');grad.addColorStop(.3,scheduled?'#ffffff': '#f4f6f8');grad.addColorStop(.72,ballColors[j]);grad.addColorStop(1,'#25283c');wg.fillStyle=grad;wg.beginPath();wg.arc(xp[j],y,r,0,Math.PI*2);wg.fill();}
  if(envs[j]>1500){let spread=18+Math.min(70,envs[j]/380);wg.beginPath();wg.ellipse(xp[j],346,spread,9+spread*.1,0,0,Math.PI*2);wg.strokeStyle=ballColors[j];wg.globalAlpha=minmax(envs[j]/25000,0,.7);wg.lineWidth=1.2;wg.stroke();wg.globalAlpha=1;}
 }
 // Lagoon: animated artwork generated from the exact same C vocal meters.
 if(scene===7){
  const voice=ready?a.kt_visual_voice():0,vowel=ready?a.kt_visual_vowel():0,crackle=ready?a.kt_visual_crackle():0;
  const x=920,y=191,mouth=8+minmax(voice/28,0,46),gills=9+vowel*.14;
  // Purely geometric figure, a warm antique gramophone sea-room, not sampled film art.
  for(let i=9;i>=0;i--){wg.beginPath();wg.arc(150,145,35+i*8,0,Math.PI*2);wg.strokeStyle=i%2?'#b5a27b35':'#c6a66a50';wg.lineWidth=1.2;wg.stroke();}
  const g=wg.createRadialGradient(x-34,y-50,8,x,y,156);g.addColorStop(0,'#d2f6e7');g.addColorStop(.65,'#69b7a7');g.addColorStop(1,'#286c73');
  wg.fillStyle=g;wg.beginPath();wg.ellipse(x,y,99,120,-.03,0,Math.PI*2);wg.fill();
  wg.fillStyle='#eafbf4';wg.beginPath();wg.ellipse(x-37,y-31,21,26,0,0,Math.PI*2);wg.ellipse(x+37,y-31,21,26,0,0,Math.PI*2);wg.fill();
  wg.fillStyle='#163d51';for(const dx of [-37,37]){wg.beginPath();wg.arc(x+dx,y-28,9,0,Math.PI*2);wg.fill();}
  wg.fillStyle='#ffffff';for(const dx of [-40,34]){wg.beginPath();wg.arc(x+dx,y-32,3,0,Math.PI*2);wg.fill();}
  wg.fillStyle='#25494c';wg.beginPath();wg.ellipse(x+1,y+45,19,mouth,0,0,Math.PI*2);wg.fill();
  wg.fillStyle='#f7bbc1';wg.beginPath();wg.ellipse(x+2,y+49,11,Math.max(2,mouth*.38),0,0,Math.PI*2);wg.fill();
  wg.strokeStyle='#285f67';wg.lineWidth=3;for(const side of [-1,1])for(let i=0;i<3;i++){let gy=y+4+i*15;wg.beginPath();wg.moveTo(x+side*82,gy);wg.lineTo(x+side*(82+gills),gy-6);wg.stroke();}
  wg.strokeStyle='#b4d5dc';wg.lineWidth=1.3;for(let i=0;i<5;i++){let r=5+i*7+Math.min(12,voice/150);wg.beginPath();wg.arc(x+128,y-90-i*18,r,0,Math.PI*2);wg.stroke();}
  wg.fillStyle='#726f68';wg.font='11px ui-monospace,monospace';wg.fillText('78 RPM   /   LAGOON ARIA',710,389);
  if(crackle>50){wg.fillStyle='#ac8a4b';for(let i=0;i<12;i++)wg.fillRect((i*167+Math.floor(t*100))%w,(i*39)%h,1.5,1.5);}
 }
 wg.fillStyle='#6d7889';wg.font='12px ui-monospace,SFMono-Regular,monospace';wg.fillText('OSCILLATOR',18,218);wg.fillText('SYNTHETIC SPACE   /   '+['2D','3D','4D SLICE','HYPERFOLD'][geom],w-345,464);
 wg.font='bold 12px ui-monospace,monospace';wg.fillText(NAMES[scene],19,50);
 if(ready){$('mLow').style.width=minmax(lo/30,0,100)+'%';$('mBuzz').style.width=minmax(bright/80,0,100)+'%';$('mHigh').style.width=minmax(high/35,0,100)+'%';$('mPerc').style.width=minmax(impact/60,0,100)+'%';}
}
let lastFrame=0;function tick(ts){if(ready){a.kt_update((ts-t0)|0);drawNative(ts);}if(ts-lastFrame>=28){drawWorld(ts);lastFrame=ts;}requestAnimationFrame(tick);}
boot().catch(e=>{$('err').textContent='WASM could not load: '+e.message;console.error(e);});requestAnimationFrame(tick);
</script></body></html>'''
html=html.replace('__WASM__',w)
(root/'web/Wa-Tur-Playable.html').write_text(html)
(root/'Wa-Tur-Playable.html').write_text(html)
print('Generated',len(html),'HTML bytes incl',len(w),'wasm base64')
