# WA TUR — implementation handoff
Continue coding from the existing shared engine in `engine/ktea_engine.c` and FM-1 app in `fw/firmware/src/ktea.c`. Keep a single engine. Preserve existing bass and percussion functionality while refining all eight scenes. Prioritize:

1. Confirm scene 08 formant crooner voice level, vintage bandwidth/crackle and animation at the true 240×240 RGB565 size, and scene 05–07 soprano/baritone/choir timbral differences.
2. Increase both bass articulation and formant resonance quality without clipping or exceeding FM-1 CPU/RAM budget. No heap allocation in the audio ISR.
3. Refine scene-specific oscillator → terrain, harmonic buzz → ridge, percussion → falling ball impact, vocal formant → mouth/gills, effects → spatial lighting routing.
4. Measure actual frequency response, peak amplitudes, voice bleed, CPU usage, RAM. Do not claim full FFT; current frequency estimates are lightweight low/mid/high filters.
5. Build actual `.fwsc` with authentic JieLi pi32v2/AC79 toolchain (see `fw/build.sh`), validate CRC + emulator boot, then test on physical M-VAVE FM-1 and retain full regression log.
6. Provide exact generated firmware SHA-256 and changelog. Never substitute previously compiled firmware.

Explicit restrictions: do not insert unlicensed David Foster Wallace recordings or scripts, do not use film soundtrack samples, and do not claim the original illustrated singing amphibian is an exact film character. Keep project GPL-3.0 notices intact.

New tests: `tests/watur_coupling.cjs` verifies formant-vowel energy and
terrain mutations in Vintage Lagoon vs other scenes. `tests/browser_smoke.py`
checks the actual browser interaction, and `tests/target-build-attempt.log`
records the missing compiler. Never present source builds as flash-ready images.
