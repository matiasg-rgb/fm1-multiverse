# Distribution notice — Wa-Tur (development candidate)

This source package accompanies the browser build in the release candidate. The inherited
firmware code is **GPL-3.0-only**; inspect `fw/LICENSE` and `fw/LICENSING.md` for original
contributor attribution. The designburg/Dinghy logo is **not** free licensed and has been
removed from this redistribution bundle; generated illustrations, media previews, host WAVs,
and cached build outputs were omitted pending separate asset review.

This is **source code**, not a verified FM-1 flashable package. The supplied browser instrument
uses the C engine compiled to WebAssembly. Hardware flashing requires explicit user-directed
installation, compatible SDK and cross-toolchain, recovery procedures, and physical tests.
The work is not affiliated with or endorsed by M-VAVE.

This repackaging does not claim ownership of upstream platform code and does not change its license.
