/* SPDX-License-Identifier: GPL-3.0-only */
/* WA TUR / TOPO BASS + OPERA / VINTAGE LAGOON for M-VAVE FM-1. One interconnected bass/percussion/terrain engine.
 * Bass and percussion retain independently adjustable voices, but share DSP energy,
 * a unified topographic modulation bus, and sound-derived geometry.
 * Host + target + WebAssembly use this exact engine. No malloc/floats in audio ISR.
 * Original engine code by OpenAI, built on K-Tea/Dinghy/Felucca platform (GPL-3.0).
 */
#include <stdint.h>
#include "tonic_pitch.h"
#ifndef KT_POOL
#define KT_POOL
#endif
#ifndef KT_API
#define KT_API
#endif
#ifndef KT_HAVE_FONT
typedef struct { uint8_t h,pad,first,last; const uint8_t *adv,*bw; const uint16_t *off; const uint8_t *data; } felucca_font_t;
#include "felucca_font.h"
#endif
#define FS 44100u
#define POLY 5
#define STRING_MAX 1024
#define W 120
#define H 120
#define L (W*H)
#define RGB565(r,g,b) ((uint16_t)((((uint32_t)(r)>>3)<<11)|(((uint32_t)(g)>>2)<<5)|((uint32_t)(b)>>3)))

typedef struct {
    uint32_t magic;
    uint8_t ver, scene, p[6];
    int8_t octave;
    uint8_t perc, balls, geometry, autoplay, hold, patch;
} kt_settings_t;
enum {P_TONE,P_PLUCK,P_BUZZ,P_TERRAIN,P_DEPTH,P_DIM};
static const char *const pname[6]={"TONE","PLUCK","BUZZ","TERRAIN","DEPTH","DIMENSION"};
static const char *const scenes[8]={"PURE STRING","FELT WOOD","THUMB BASS","WIRE BUZZ","SOPRANO","BARITONE","OPERA CHOIR","VINTAGE LAGOON"};
static const uint8_t defaults[8][6]={
 {62,78,12,22,20,7}, {32,46,10,30,38,17}, {43,96,34,42,49,22}, {86,62,108,55,60,35},
 {41,73,29,70,75,47}, {72,88,51,88,81,79}, {75,37,84,105,76,98}, {54,63,24,96,103,91}
};
static const uint8_t bpm[8]={88,64,104,116,76,93,128,110};
static const uint8_t root[8]={40,43,40,45,38,42,40,36};
/* 16-step percussion patterns; percussion impacts feed the shared topology modulation. */
static const uint16_t kick_pat[8]={0x1111,0x1001,0x1111,0x5151,0x1011,0x1111,0x5555,0x1111};
static const uint16_t wood_pat[8]={0x0100,0x0400,0x0440,0x2222,0x0802,0x0404,0x2222,0x0404};
static const uint16_t hat_pat [8]={0x1111,0x0000,0x5555,0xAAAA,0x1515,0x5555,0xFFFF,0x0101};
static const uint16_t colors[8][4]={
 {0x00DB,0xEC9D,0xFCD2,0xAC4B}, {0x6D78,0x9CF3,0xED18,0xBB70},
 {0x241F,0x1DDC,0xA7F0,0xFAAA}, {0x095E,0x843D,0xF80C,0xFCA7},
 {0x01DA,0x2ED2,0xEE9E,0x8A70}, {0x31BD,0x9EFA,0xEA47,0xBC70},
 {0x043F,0x4B5F,0xD83F,0xFFE5}, {0x5BCE,0x9550,0xE569,0x3456}
};

typedef struct {
    int16_t string[STRING_MAX];
    uint32_t phase,inc;
    uint16_t len,idx;
    int32_t amp, filt;
    uint8_t midi,key,held,active;
} voice_t;
static voice_t v[POLY] KT_POOL;
static uint16_t world[L] KT_POOL;
static int16_t echoL[2048] KT_POOL,echoR[2048] KT_POOL;
static uint32_t echoPos, seed=0xD15EA5Eu, sample_count;
static kt_settings_t S;
static uint8_t save_req,help_on,preview_scene;
static uint32_t now_ms, last_ms, last_autostep=UINT32_MAX, frame_serial;
static int32_t popup_id=-1;
static uint32_t popup_until;
/* main -> audio. Consistent single-writer on main except manually injected hits through counter. */
/* 4 sixteenths per beat: round(2^32 * 4 / (60 * 44100)) = 6492. */
static volatile uint32_t ap_stepinc=88*6492u, ap_trig;
static volatile uint8_t ap_perc=1,ap_scene;
static volatile int32_t ap_tone=15000,ap_pluck=80,ap_buzz=1000,ap_space=9000;
static volatile int32_t ap_couple=9200,ap_depth=36;
/* audio -> main, telemetry from actual signal path. */
static volatile uint32_t ao_phase,ao_step,ao_stepfrac,ao_bass,ao_perc,ao_peak,ao_note,ao_strikes,ao_osc;
/* Measured sonic attributes used by both the LCD and the browser projection.
 * Low/mid/high are non-FFT one-pole bands; not spectral-analysis claims. */
static volatile uint32_t ao_low,ao_mid,ao_high,ao_bright,ao_kick,ao_wood,ao_hat,ao_env;
static int32_t band_lp_slow,band_lp_fast,env_hold;
static uint32_t step_phase, step_index;
static uint32_t kick_phase,kick_inc,kick_env,wood_env,hat_env,manual_seen;
static int32_t wood_lp,lowL,lowR;
static int32_t play_note=-1;
/* Opera voice generator shares note pitch, envelope and spatial buses with bass.
 * Scene 4: high solo, scene 5: low solo, scene 6: harmonic choir, scene 7:
 * narrow-band shellac crooner. No recorded voice or copyrighted samples. */
static uint32_t sing_phase, sing_phase2, sing_lfo;
static int32_t sing_hp, sing_lp, shellac_hp, shellac_low;
static uint32_t vinyl_phase;
static volatile uint32_t ao_vowel, ao_voice, ao_crackle;


static uint32_t noise32(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static int32_t iabs(int32_t a){return a<0?-a:a;}
static int32_t clip(int32_t a,int32_t lo,int32_t hi){return a<lo?lo:a>hi?hi:a;}
static int32_t sine(uint32_t ph){
    int32_t x=(int32_t)ph>>16,ax=x<0?-x:x, y,ay;
    y=(x*(32768-ax))>>13;ay=y<0?-y:y;
    y+=((((y*ay)>>15)-y)*7373)>>15;
    return clip(y,-32767,32767);
}
static uint16_t blend(uint16_t a,uint16_t b,int t){
    int ar=a>>11,ag=(a>>5)&63,ab=a&31;
    int br=b>>11,bg=(b>>5)&63,bb=b&31;
    t=clip(t,0,256);
    return (uint16_t)(((ar+((br-ar)*t>>8))<<11)|((ag+((bg-ag)*t>>8))<<5)|(ab+((bb-ab)*t>>8)));
}
static uint16_t tint(uint16_t base,int shade){return blend(base,RGB565(255,255,255),shade);}
static void pix(int x,int y,uint16_t c){if((unsigned)x<W&&(unsigned)y<H)world[y*W+x]=c;}
static void line(int x0,int y0,int x1,int y1,uint16_t c){
    int dx=iabs(x1-x0),dy=-iabs(y1-y0),sx=x0<x1?1:-1,sy=y0<y1?1:-1,e=dx+dy;
    for(;;){pix(x0,y0,c);if(x0==x1&&y0==y1)break;int e2=2*e;if(e2>=dy){e+=dy;x0+=sx;}if(e2<=dx){e+=dx;y0+=sy;}}
}
static int note_at(int k){return clip(40+k+(int)S.octave*12,28,108);}
static void note_on(int note,int key,int velocity){
    int i,best=0,min_amp=0x7FFFFFFF;
    uint32_t inc=TONIC_INC[clip(note,0,127)];
    if(inc<1)inc=1;
    for(i=0;i<POLY;i++){
        if(!v[i].active){best=i;break;}
        if(v[i].amp<min_amp){min_amp=v[i].amp;best=i;}
    }
    voice_t *q=&v[best];
    /* 44.1 kHz / freq from DDS phase increment; executed in MAIN only. */
    uint32_t len=TONIC_PERIOD[clip(note,0,127)];
    len=(uint32_t)clip((int)len,30,STRING_MAX-1);
    q->len=(uint16_t)len;q->idx=0;q->phase=0;q->inc=inc;q->filt=0;
    q->midi=(uint8_t)note;q->key=(uint8_t)key;q->held=1;q->active=1;
    q->amp=clip(velocity*258,4000,32767);
    for(i=0;i<(int)len;i++){
        int32_t r=(int32_t)((noise32()>>16)&65535u)-32768;
        /* Real excited string: noise + deterministic pick position comb. */
        int pos=(i*7/(int)len)&1;
        q->string[i]=(int16_t)((r*(pos?3:5))>>3);
    }
    ao_note=(uint32_t)note;
}
static void note_off(int k){int i;for(i=0;i<POLY;i++)if(v[i].active&&v[i].key==k)v[i].held=0;}
static void all_notes_off(void){int i;for(i=0;i<POLY;i++)v[i].held=0;}
static void percussion_hit(int typ){
    if(typ&1){kick_env=30000;kick_phase=0;kick_inc=9000000u;}
    if(typ&2)wood_env=24500;
    if(typ&4)hat_env=12000;
    if(typ)ao_strikes++;
}
/* Audio callback. Identical host, target and WASM DSP. Separate voice and drum buses. */
KT_API void kt_audio(int32_t *out,uint32_t n){
    uint32_t i;
    uint32_t local_bass=0,local_drums=0,local_peak=0;
    uint32_t local_low=0,local_mid=0,local_high=0,local_bright=0;
    uint32_t local_voice=0,local_crackle=0,local_vowel=0;

    for(i=0;i<n;i++){
        int32_t b=0,d=0,l,r;
        unsigned j;
        /* Oscillator / Karplus-Strong pluck bus. */
        for(j=0;j<POLY;j++){
            voice_t *q=&v[j];
            if(!q->active)continue;
            int idx=q->idx,after=idx+1==(int)q->len?0:idx+1;
            int32_t string=q->string[idx], nxt=q->string[after];
            int32_t damp=32665-(127-ap_pluck)*2;
            int32_t avg=((string+nxt)*damp)>>16;
            q->string[idx]=(int16_t)clip(avg,-32767,32767);
            q->idx=(uint16_t)after;
            q->phase+=q->inc;
            int32_t osc=sine(q->phase);
            int32_t harm=sine(q->phase*2u);
            /* Additive brightness: the upper partial is a real second oscillator. */
            int32_t third=sine(q->phase*3u);
            int32_t shaped=(osc*(19000-ap_buzz/2)+harm*(ap_buzz/3)+third*(ap_buzz/6))>>15;
            local_bright+=(uint32_t)iabs((harm+third)*ap_buzz>>16);
            int32_t s=(string*3+shaped)>>2;
            /* A drum impact physically opens the bass filter for a short transient;
             * this is the coupling from the falling sphere to the whole instrument. */
            int32_t drive=(int32_t)(((uint32_t)kick_env+(uint32_t)wood_env/2u)*(uint32_t)ap_couple>>16);
            int32_t cutoff=clip(ap_tone+drive/2,1200,31900);
            q->filt+=((s-q->filt)*cutoff)>>15;
            b+=(q->filt*q->amp)>>16;
            if(!q->held){q->amp-=(int32_t)(8+(127-ap_pluck)/2);if(q->amp<=0){q->active=0;q->amp=0;}}
            /* Even sustained notes eventually damp rather than ring forever. */
            if(q->held&&sample_count%4096u==0u&&q->amp>2000)q->amp-=32;
            ao_phase=q->phase;
        }
        /* Sample-clocked 16-step percussion: independent, editable and bypassable. */
        {
            uint32_t old=step_phase;
            step_phase+=ap_stepinc;
            if(step_phase<old){
                uint16_t bit=(uint16_t)(1u<<(step_index&15u));
                unsigned scene=ap_scene&7u,hit=0;
                if(ap_perc){
                    if(kick_pat[scene]&bit)hit|=1;
                    if(wood_pat[scene]&bit)hit|=2;
                    if(hat_pat[scene]&bit)hit|=4;
                    if(hit)percussion_hit((int)hit);
                }
                step_index=(step_index+1u)&15u;
                ao_step=step_index;
            }
            ao_stepfrac=step_phase>>16;
        }
        if(ap_trig!=manual_seen){manual_seen=ap_trig;percussion_hit(3);}
        if(kick_env){
            kick_phase+=kick_inc;
            d+=(sine(kick_phase)*(int32_t)kick_env)>>16;
            kick_inc-=kick_inc>3800000u?15000u:0u;
            kick_env=kick_env>110u?kick_env-110u:0u;
        }
        if(wood_env){
            int32_t a=(int32_t)((noise32()>>16)&65535u)-32768;
            wood_lp+=((a-wood_lp)*20000)>>15;
            d+=(wood_lp*(int32_t)wood_env)>>16;
            wood_env=wood_env>250u?wood_env-250u:0;
        }
        if(hat_env){
            int32_t a=(int32_t)((noise32()>>16)&65535u)-32768;
            d+=(a*(int32_t)hat_env)>>18;
            hat_env=hat_env>550u?hat_env-550u:0;
        }
        b=clip(b,-26000,26000);d=clip(d,-24000,24000);
        /* Single coupled synthesis path: formant singers feed the same stereo
         * room and the same bass-derived spectral/geometry telemetry. Scene
         * decides voice morphology, not a separate firmware/audio engine. */
        if(ap_scene>=4){
            uint32_t base=TONIC_INC[(int)ao_note<128?(int)ao_note:52];
            if(!base)base=TONIC_INC[52];
            /* broad vibrato and pitch drift tied to a slow shared phase */
            sing_lfo+=487000u;vinyl_phase+=79000u;
            int32_t vib=sine(sing_lfo);
            int32_t drift=(int32_t)(((int64_t)base*vib)/(32768*170));
            if(ap_scene==7)drift+=(int32_t)(((int64_t)base*sine(vinyl_phase))/(32768*220));
            int mode=ap_scene;
            uint32_t inc=(mode==4?base*2u:mode==5?base/2u:mode==7?base/2u:base);
            sing_phase+=(uint32_t)((int64_t)inc+drift);
            sing_phase2+= mode==6?base+(base>>1):base;
            int32_t a=sine(sing_phase),harm=sine(sing_phase*2u);
            int32_t chorus=sine(sing_phase2);
            int32_t src=(a*11+harm*5+(mode==6?chorus*8:0))>>4;
            /* Continuous vowel movement: the exact control affects formants,
             * then measured voice energy shifts terrain and mouth animation. */
            int32_t vowel=clip((vib+32768)>>9,0,127);
            local_vowel+=(uint32_t)vowel;
            int32_t f1=clip(3200+(int)ap_buzz/5+(mode==4?5500:0)+(vowel-64)*40,1500,25500);
            int32_t f2=clip(3900+(int)ap_tone/4+(mode==5?2500:0)-(vowel-64)*45,2500,29000);
            sing_lp+=((src-sing_lp)*f1)>>15;
            sing_hp+=((src-sing_hp)*f2)>>15;
            /* Formant gap exaggerates vowels; sounding human-like without
             * misrepresenting it as an actual opera recording. */
            int32_t voice=clip((sing_hp-sing_lp)*2+sing_lp/3,-16000,16000);
            int32_t gain=mode==7?8500:(mode==6?8000:6500);
            voice=(voice*gain)>>15;
            b=clip(b+voice,-26000,26000);
            local_voice+=(uint32_t)iabs(voice);
            /* 1920s shellac aesthetic: sparse impulse ticks + bandwidth
             * limitation. Deterministic noise and envelope, no audio samples. */
            if(mode==7){
                /* Horn/gramophone bandwidth, with gently uneven speed. */
                shellac_low+=((b-shellac_low)*7800)>>15;
                b=shellac_low;
                int32_t hiss=(int32_t)(noise32()>>17)-16384;
                int32_t snap=((sample_count%8107u)==0u)?(int32_t)((noise32()>>17)&8191)-4096:0;
                shellac_hp+=(hiss-shellac_hp)*900>>15;
                int32_t dust=(hiss-shellac_hp)/64+snap;
                b=clip(b+dust,-26000,26000);
                local_crackle+=(uint32_t)iabs(dust);
            }
        }
        local_bass+=(uint32_t)iabs(b);local_drums+=(uint32_t)iabs(d);
        /* Signed intermediate samples preserve waveform information, the absolute
         * band differences express light/texture separately from volume. */
        {
            int32_t mixed=(b*3+d)>>2;
            band_lp_slow+=((mixed-band_lp_slow)*280)>>15;
            band_lp_fast+=((mixed-band_lp_fast)*3900)>>15;
            local_low+=(uint32_t)iabs(band_lp_slow);
            local_mid+=(uint32_t)iabs(band_lp_fast-band_lp_slow);
            local_high+=(uint32_t)iabs(mixed-band_lp_fast);
            int32_t e=iabs(mixed);
            if(e>env_hold)env_hold=e;else env_hold-=env_hold>12?12:env_hold;
        }
        /* Stereo space with a bounded, low-cost echo. */
        l=b+d;
        r=b+(d*3>>2);
        lowL+=((l-lowL)*ap_tone)>>16;lowR+=((r-lowR)*ap_tone)>>16;
        l=lowL+(echoL[echoPos]*ap_space>>16);
        r=lowR+(echoR[(echoPos+1021u)&2047u]*ap_space>>16);
        echoL[echoPos]=(int16_t)clip(l>>2,-12000,12000);
        echoR[echoPos]=(int16_t)clip(r>>2,-12000,12000);
        echoPos=(echoPos+1u)&2047u;
        l=clip(l,-30000,30000);r=clip(r,-30000,30000);
        out[2u*i]=l;out[2u*i+1u]=r;
        if((uint32_t)iabs(l)>local_peak)local_peak=(uint32_t)iabs(l);
        sample_count++;
    }
    if(n){
        ao_bass=local_bass/n;ao_perc=local_drums/n;ao_peak=local_peak;
        ao_low=local_low/n;ao_mid=local_mid/n;ao_high=local_high/n;
        ao_bright=local_bright/n;
    }
    ao_kick=kick_env;ao_wood=wood_env;ao_hat=hat_env;ao_env=(uint32_t)env_hold;
    if(n){ao_voice=local_voice/n;ao_crackle=local_crackle/n;}
    ao_vowel=n?local_vowel/n:0u;
    ao_osc=(uint32_t)(v[0].phase>>16);
}
static void scene_apply(int n){
    int i;
    n=(n+8)%8;S.scene=(uint8_t)n;ap_scene=(uint8_t)n;
    for(i=0;i<6;i++)S.p[i]=defaults[n][i];
    ap_stepinc=bpm[n]*6492u;preview_scene=(uint8_t)n;ao_note=root[n];
    all_notes_off();popup_id=10;popup_until=now_ms+1600u;
}
KT_API void kt_init(uint32_t s){
    int i,j;
    seed=s?s:0xF1A3u;S.magic=0x544F4E43u;S.ver=2;S.scene=0;S.octave=0;S.perc=1;S.balls=1;S.geometry=2;S.autoplay=0;S.hold=0;S.patch=0;
    for(i=0;i<POLY;i++){v[i].active=0;v[i].amp=0;v[i].held=0;for(j=0;j<STRING_MAX;j++)v[i].string[j]=0;}
    for(i=0;i<2048;i++){echoL[i]=0;echoR[i]=0;}
    for(i=0;i<L;i++)world[i]=0xFFFF;
    band_lp_slow=0;band_lp_fast=0;env_hold=0;play_note=-1;
    kick_phase=kick_inc=kick_env=wood_env=hat_env=0;
    echoPos=sample_count=0;lowL=lowR=wood_lp=0;
    ao_phase=ao_note=ao_strikes=ao_osc=0;
    scene_apply(0);now_ms=0;last_ms=0;step_phase=0;step_index=0;ao_step=0;ao_stepfrac=0;ao_bass=0;ao_perc=0;ao_peak=0;ap_trig=0;manual_seen=0;frame_serial=0;
    ao_low=ao_mid=ao_high=ao_bright=ao_kick=ao_wood=ao_hat=ao_env=0;
    sing_phase=sing_phase2=sing_lfo=vinyl_phase=0;sing_hp=sing_lp=shellac_hp=shellac_low=0;
    ao_vowel=ao_voice=ao_crackle=0;
}
KT_API void kt_get_settings(kt_settings_t *out){*out=S;}
KT_API void kt_set_settings(const kt_settings_t *src){
    int i;if(src->magic!=0x544F4E43u||src->ver!=2)return;
    scene_apply(src->scene&7);
    for(i=0;i<6;i++)S.p[i]=(uint8_t)clip(src->p[i],0,127);
    S.octave=(int8_t)clip(src->octave,-2,2);S.perc=!!src->perc;S.balls=!!src->balls;S.geometry=src->geometry%4;S.autoplay=!!src->autoplay;S.hold=0;
}
KT_API int kt_take_save(void){int x=save_req;save_req=0;return x;}
KT_API int kt_quiet(void){return ao_peak<48;}
KT_API void kt_key(int k,int down){if(k<0||k>26)return;if(down)note_on(note_at(k),k,100);else if(!S.hold)note_off(k);}
KT_API void kt_midi_note(int note,int vel,int on){int i;if(on&&vel)note_on(note,100+note,vel);else for(i=0;i<POLY;i++)if(v[i].active&&v[i].key==100+note&&!S.hold)v[i].held=0;}
KT_API int kt_get_species(void){return S.scene;}
KT_API int kt_get_param(int p){return (unsigned)p<6?S.p[p]:0;}
KT_API void kt_set_param(int p,int value){if((unsigned)p<6)S.p[p]=(uint8_t)clip(value,0,127);}
KT_API void kt_set_species(int n){scene_apply(n);}
KT_API uint32_t kt_visual_peak(void){return ao_peak;}
KT_API uint32_t kt_visual_bass(void){return ao_bass;}
KT_API uint32_t kt_visual_perc(void){return ao_perc;}
KT_API uint32_t kt_visual_osc(void){return ao_osc;}
KT_API uint32_t kt_visual_strikes(void){return ao_strikes;}
KT_API uint32_t kt_visual_low(void){return ao_low;}
KT_API uint32_t kt_visual_mid(void){return ao_mid;}
KT_API uint32_t kt_visual_high(void){return ao_high;}
KT_API uint32_t kt_visual_bright(void){return ao_bright;}
KT_API uint32_t kt_visual_kick(void){return ao_kick;}
KT_API uint32_t kt_visual_wood(void){return ao_wood;}
KT_API uint32_t kt_visual_hat(void){return ao_hat;}
KT_API uint32_t kt_visual_envelope(void){return ao_env;}
KT_API uint32_t kt_visual_voice(void){return ao_voice;}
KT_API uint32_t kt_visual_vowel(void){return ao_vowel;}
KT_API uint32_t kt_visual_crackle(void){return ao_crackle;}
KT_API uint32_t kt_visual_step(void){return ao_step;}
KT_API uint32_t kt_visual_phase(void){return ao_stepfrac;}
KT_API void kt_encoder(int e,int steps){
    static const uint8_t map[6]={P_DEPTH,P_DIM,P_TONE,P_PLUCK,P_BUZZ,P_TERRAIN};
    if(e<0||e>6||!steps)return;
    if(e==6){scene_apply((S.scene+(steps>0?1:7))&7);return;}
    int p=map[e];S.p[p]=(uint8_t)clip(S.p[p]+3*steps,0,127);popup_id=p;popup_until=now_ms+1100u;
}
KT_API void kt_button(int b){
    switch(b){
    case 0:S.octave=(int8_t)clip(S.octave-1,-2,2);break;
    case 1:S.octave=(int8_t)clip(S.octave+1,-2,2);break;
    case 2:S.balls^=1u;break;                 /* FX: visible falling 3D spheres */
    case 3:S.p[P_DIM]=(uint8_t)((S.p[P_DIM]+29u)&127u);break;
    case 4:S.p[P_PLUCK]=(uint8_t)((S.p[P_PLUCK]+25u)&127u);break;
    case 5:S.patch=(uint8_t)((S.patch+1u)&3u);break;
    case 6:S.geometry=(uint8_t)((S.geometry+1u)&3u);break;  /* EDIT: contour -> 3D -> 4D slice -> beyond */
    case 7:ap_trig++;break;                    /* GLO: independent manual ball strike */
    case 8:help_on^=1u;break;
    case 9:save_req=1;break;
    case 10:S.perc^=1u;break;                  /* ARP: percussion audio */
    case 11:S.patch=(uint8_t)((S.patch+1u)&3u);break;
    case 12:S.autoplay^=1u;all_notes_off();break;  /* PLAY */
    case 13:S.hold^=1u;if(!S.hold)all_notes_off();break;
    }
    popup_id=11;popup_until=now_ms+1000;
}
/* 120x120 logical field scaled 2x to FM-1 240x240 RGB565.
 * One world: string waveform -> ridges; buzz -> jagged peaks and harmonic tint;
 * upper spectral energy -> fine micro-lines; percussion impacts -> ripples and
 * terrain compression; spatial echo -> pale haze. The "4D" mode is a moving
 * projection of an extra coordinate, not literal four spatial axes on an LCD.
 */
static void ring_world(int cx,int cy,int radius,uint16_t col){
    for(int x=-radius;x<=radius;x++){
        int r2=radius*radius-x*x,y=0;
        while((y+1)*(y+1)<=r2)y++;
        pix(cx+x,cy+y,col);pix(cx+x,cy-y,col);
    }
}
static void lagoon_singer(void){
    /* Original smiling amphibious crooner and old phonograph disc, atop
     * the same contours. Jaw is driven by actual formant energy. */
    uint16_t emerald=RGB565(67,124,113),mist=RGB565(194,220,208);
    uint16_t ink=RGB565(56,80,78),gold=RGB565(185,143,91);
    int vocal=clip((int)ao_voice/70,0,18);
    int jaw=1+vocal/4+((int)ao_vowel/24);
    jaw=clip(jaw,1,13);
    for(int r=20;r>1;r-=4)ring_world(23,35,r,tint(gold,105+r*3));
    ring_world(23,35,6,ink);ring_world(23,35,2,gold);
    /* Clean filled portrait silhouette, readable on the tiny RGB565 screen. */
    for(int y=16;y<=49;y++)for(int x=69;x<=108;x++){
        int dx=x-89,dy=y-33;
        if(dx*dx*3+dy*dy*4<=1200){
            int depth=clip(100+(49-y)*3+(x-70),70,238);
            pix(x,y,blend(mist,emerald,depth));
        }
    }
    ring_world(89,33,18,tint(emerald,95));
    for(int y=19;y<31;y++)for(int x=75;x<87;x++)if((x-81)*(x-81)+(y-25)*(y-25)<33)pix(x,y,RGB565(246,247,239));
    for(int y=19;y<31;y++)for(int x=90;x<102;x++)if((x-96)*(x-96)+(y-25)*(y-25)<33)pix(x,y,RGB565(246,247,239));
    ring_world(81,25,6,emerald);ring_world(96,25,6,emerald);
    ring_world(81,25,2,ink);ring_world(96,25,2,ink);
    for(int y=32;y<37;y++){
        pix(70,y,mist);pix(105,y,mist);
    }
    line(79,40,96,40+jaw,ink);
    if(jaw>2){line(79,40,79,40+jaw,ink);line(96,40+jaw,79,40+jaw,ink);}
    /* Gills and bubbles breathe with the measured voice envelope. */
    for(int i=0;i<3;i++){
        line(70-i*2,30+i*3,72-i*2-(int)(ao_vowel/50),33+i*3,emerald);
        line(103+i*2,30+i*3,101+i*2,33+i*3,emerald);
        if((int)ao_voice>(i+1)*180)ring_world(109-i*4,15-i*4,1+i,RGB565(126,179,185));
    }
}
static void make_world(void){
    int x,y,z,oldx,oldy;
    int bass=clip((int)ao_bass,0,14000),lo=clip((int)ao_low,0,14000);
    int mid=clip((int)ao_mid,0,14000),hi=clip((int)ao_high,0,14000);
    int bright=clip((int)ao_bright,0,12000);
    int kick=clip((int)ao_kick,0,30000),wood=clip((int)ao_wood,0,25000),hat=clip((int)ao_hat,0,13000);
    int buzz=S.p[P_BUZZ],terrain=S.p[P_TERRAIN],dim=S.p[P_DIM],depth=S.p[P_DEPTH];
    int energy=clip((bass+lo+mid)/12,0,2400);
    int vocal=clip((int)ao_voice,0,6000),vowel=(int)ao_vowel;
    uint32_t phase=ao_phase,time=(now_ms*6200u)+(uint32_t)dim*530000u;
    uint16_t ink=RGB565(47,53,67),paper=RGB565(253,253,253);
    int loops=2+terrain/15+energy/370;
    if(loops>14)loops=14;
    for(y=0;y<H;y++)for(x=0;x<W;x++){
        int v=((x*19+y*11+x*y*3)&63)==0?5:0;
        world[y*W+x]=blend(paper,RGB565(207,214,225),v*5);
    }
    /* Waveform on the left: trace bends from the actual oscillator phase;
     * higher harmonics leave finer, more irregular ink. */
    {
        int lastx=-1,lasty=0,amp=2+clip(lo/400,0,10);
        for(x=1;x<51;x++){
            uint32_t a=phase+(uint32_t)x*(85000000u+(uint32_t)buzz*230000u);
            int32_t w=sine(a)+(sine(a*2u)*buzz/210)+(sine(a*3u)*hi/16000);
            int yy=69+(int)(((int64_t)w*amp)>>15);
            if(lastx>=0)line(lastx,lasty,x,yy,ink);
            lastx=x;lasty=yy;
        }
    }
    /* Every topographical layer is part of a continuous projected surface. */
    for(z=loops-1;z>=0;z--){
        uint16_t col=colors[S.scene][(z+S.patch)&3];
        int fade=clip(70+z*105/loops,0,189);
        col=tint(col,fade);
        oldx=-1;oldy=0;
        for(x=2;x<120;x+=2){
            int sx=x-8+z*depth/160;
            int sy=50+z*(1+depth/108);
            uint32_t a=(uint32_t)x*(39000000u+(uint32_t)terrain*160000u)+phase/3u+time/8u;
            uint32_t b=(uint32_t)x*79000000u+(uint32_t)z*220000000u+time/5u;
            int32_t fundamental=sine(a+(uint32_t)z*260000000u);
            int32_t folding=sine(b+(uint32_t)dim*17000000u);
            int32_t fizz=sine((a*3u)+(uint32_t)z*131000000u);
            /* String fundamental forms hills; upper partials make their edges buzz. */
            int32_t h=(fundamental*(4+terrain/11+energy/300)>>15)
                     +(folding*(dim/13+mid/2000)>>15)
                     +(fizz*(buzz/19+hi/2200)>>15);
            /* Vocal formants are elevations in the SAME terrain, not a layer
             * drawn on top: the singer shapes the world that bass and balls touch. */
            if(vocal)h+=(sine(a+(uint32_t)vowel*45000000u+(uint32_t)z*190000000u)*(2+vocal/200)>>15);
            /* Kick compresses the whole projected terrain; wood adds a local crater,
             * hats flicker crest detail. Spheres and landscape share these signals. */
            if(kick)h+=(sine((uint32_t)x*154000000u+(uint32_t)z*80000000u+time)*kick>>18);
            if(wood)h+=(sine((uint32_t)(x-62)*(uint32_t)(x-62)*1360000u+time/4u)*wood>>18);
            if(S.geometry==0)h=(fundamental*(4+terrain/12)>>15)+(fizz*buzz>>20);
            else if(S.geometry==1)h+=(z*z*depth/260);
            else if(S.geometry==2)h+=(sine(time/3u+(uint32_t)z*300000000u)*dim>>18);
            else h+=(sine(a+time/2u+(uint32_t)z*365000000u)*dim>>18)+(folding*dim>>17)+(sine(time+(uint32_t)x*46000000u)*bright>>18);
            /* Continuous soft limiter preserves peak shape without screen-edge
             * plateaus (important on the small 240x240 LCD). */
            int relief=(h*18)/(18+iabs(h));
            sy=clip(sy-relief,31,94); sx+=(z*depth/210)-5;
            if(oldx>=0)line(oldx,oldy,sx,sy,col);
            if(z>1&&S.geometry!=0&&(x%10)==0){
                line(sx,sy,sx,sy+clip(depth/20,0,6),tint(col,90));
            }
            /* High partials appear as pointillist crest sparks, never noise-only. */
            if(hi>260 && ((x+z*7+(int)(phase>>28))%23)==0){
                pix(sx,sy-1,tint(col,clip(hi/32+hat/64,25,180)));
            }
            oldx=sx;oldy=sy;
        }
    }
    /* Audible impacts create short-lived concentric lines tied to their envelopes.
     * They remain visible even when ball sprites are hidden. */
    {
        const int levels[3]={kick,wood,hat};
        const int anchors[3]={26,60,93};
        for(int t=0;t<3;t++)if(levels[t]>850){
            int r=3+(30000-levels[t])/1700;
            if(r>24)r=24;
            for(x=-r;x<=r;x++){
                int d=r*r-x*x;
                int yy=0;
                while((yy+1)*(yy+1)<=d)yy++;
                pix(anchors[t]+x,54+yy,tint(colors[S.scene][t],130));
                pix(anchors[t]+x,54-yy,tint(colors[S.scene][t],130));
            }
        }
    }
    if(S.scene==7)lagoon_singer();
    line(3,105,117,105,RGB565(216,221,229));
    frame_serial++;
}
KT_API void kt_update(uint32_t ms){
    int beat=(int)ao_step;
    now_ms=ms;
    if(ms==last_ms)return;
    last_ms=ms;
    ap_perc=S.perc;ap_scene=S.scene;
    ap_tone=clip(3600+S.p[P_TONE]*200,2000,31500);
    ap_pluck=S.p[P_PLUCK];ap_buzz=S.p[P_BUZZ]*245;
    ap_space=S.p[P_DEPTH]*150;
    ap_couple=3800+(S.p[P_TERRAIN]*120)+(S.p[P_DIM]*38);
    ap_depth=S.p[P_DEPTH];
    if(S.autoplay&&last_autostep!=(uint32_t)beat){
        last_autostep=(uint32_t)beat;
        if((beat&3)==0){if(play_note>=0)note_off(127);play_note=root[S.scene]+((beat>>2)&1?7:0);note_on(play_note,127,74);}
    }
    make_world();
}
KT_API void kt_leds(uint32_t *btn,uint32_t *keys,uint32_t *glow){
    int i;uint32_t k=0,b=0,g=0;
    if(S.balls)b|=1u<<2;
    if(S.perc)b|=1u<<10;
    if(S.autoplay)b|=1u<<12;
    if(S.hold)b|=1u<<13;
    for(i=0;i<POLY;i++)if(v[i].active&&v[i].held&&v[i].key<27)k|=1u<<v[i].key;
    for(i=0;i<27;i++)if(i%12==0)g|=1u<<i;
    *btn=b;*keys=k;*glow=g;
}
/* LCD: white stage with shaded falling spheres composited IN the sound-world.
 * Balls use percussion phase, reflect actual bass brightness and cause impact
 * ripples visible in the contour field, all fed by the same synthesis bus. */
static uint16_t *rbuf;static int ry0,rh;
static void dot2(int x,int y,uint16_t c){if((unsigned)x<240&&(unsigned)(y-ry0)<(unsigned)rh)rbuf[(y-ry0)*240+x]=c;}
static int txt(int x,int y,const felucca_font_t *f,const char *s,uint16_t c){
    for(;*s;s++){
        unsigned ch=(uint8_t)*s;if(ch<f->first||ch>f->last)ch='?';
        unsigned idx=ch-f->first,w=f->bw[idx],pitch=(w+1u)/2u;
        const uint8_t *g=f->data+f->off[idx];
        for(unsigned yy=0;yy<f->h;yy++){
            int sy=y+(int)yy;
            if(sy<ry0||sy>=ry0+rh)continue;
            for(unsigned xx=0;xx<w;xx++){
                unsigned t=g[yy*pitch+xx/2u],v=(xx&1)?(t&15u):(t>>4);
                int sx=x+(int)xx-f->pad;
                if(v&&(unsigned)sx<240u){uint16_t bg=rbuf[(sy-ry0)*240+sx];dot2(sx,sy,blend(bg,c,(int)v*17));}
            }
        }
        x+=f->adv[idx];
    }
    return x;
}
static void sphere(int cx,int cy,int r,uint16_t color){
    int x,y;
    for(y=-r;y<=r;y++){
        int sy=cy+y;if(sy<ry0||sy>=ry0+rh)continue;
        for(x=-r;x<=r;x++){
            int d=x*x+y*y,rad=r*r;if(d>rad)continue;
            int hx=x+r/3,hy=y+r/3;
            int hl=clip(196-(hx*hx+hy*hy)*225/rad,4,220);
            if((unsigned)(cx+x)>=240u)continue;
            uint16_t bg=rbuf[(sy-ry0)*240+cx+x];
            /* Brightness and oscillator phase colour the reflected sphere surface. */
            int gleam=clip(hl+(int)ao_bright/48+(int)ao_high/64,0,255);
            uint16_t shade=blend(RGB565(29,35,49),color,gleam);
            dot2(cx+x,sy,blend(bg,shade,245));
        }
    }
}
KT_API void kt_render(uint16_t *buf,int y0,int h,int swap){
    int x,y,k;uint16_t c;
    rbuf=buf;ry0=y0;rh=h;
    for(y=y0;y<y0+h;y++)for(x=0;x<240;x++){
        c=world[(y>>1)*W+(x>>1)];
        buf[(y-y0)*240+x]=c;
    }
    /* Three percussion parts, sharing timing, harmonic light and ground deformation. */
    if(S.balls&&S.perc){
        unsigned n=(unsigned)ao_step&15u, next=(n+1u)&15u;
        int prog=(int)ao_stepfrac;uint16_t hitbit=(uint16_t)(1u<<next);
        const uint16_t pats[3]={kick_pat[S.scene],wood_pat[S.scene],hat_pat[S.scene]};
        const int xpos[3]={53,117,181};
        for(k=0;k<3;k++){
            int active=(pats[k]&hitbit)!=0;
            /* Fall before the sound event, reaching the impact bar at tick wrap. */
            /* Fixed-point quadratic fall with one safe 64-bit multiply outside audio ISR. */
            int py=active?35+(int)(((uint64_t)prog*(uint64_t)prog*63u)>>32):31;
            /* Landing shadow, visually independent from oscillation lines. */
            for(x=-13;x<=13;x+=2){int ysh=105+(x*x/80);dot2(xpos[k]+x,ysh,RGB565(223,219,226));}
            sphere(xpos[k],py,active?7+k:4+k/2,
                   active?colors[S.scene][k]:tint(colors[S.scene][k],185));
            /* Highlight halo is tied to actual audible transient amplitude. */
            int env=(k==0)?(int)ao_kick:(k==1)?(int)ao_wood:(int)ao_hat;
            if(active&&env>1800){
                for(int dx=-12;dx<=12;dx+=3){
                    int dy=(12-iabs(dx))/3;
                    dot2(xpos[k]+dx,102-dy,tint(colors[S.scene][k],160));
                }
            }
        }
    }
    if(y0<32||y0+h>197){
        txt(10,5,&FONT_S,"WA TUR",RGB565(28,31,40));
        txt(110,5,&FONT_S,"BASS / ARIA",RGB565(76,78,89));
        txt(9,195,&FONT_S,scenes[S.scene],RGB565(55,60,72));
        /* Visible miniature signal meters: bass, buzz, treble, drums. */
        {
            const int power[4]={(int)ao_low,(int)ao_bright,(int)ao_high,(int)ao_perc};
            for(int t=0;t<4;t++){
                int n=clip(power[t]/125,0,33);
                int start=9+57*t;
                for(int j=0;j<n;j++)dot2(start+j,216,colors[S.scene][t]);
            }
        }
        txt(9,224,&FONT_S,S.perc?"BALL PERC ON":"BALL PERC OFF",RGB565(88,85,111));
        txt(153,224,&FONT_S,S.balls?"DROP VIS ON":"DROP VIS OFF",RGB565(88,85,111));
        if(help_on){txt(6,35,&FONT_S,"K1-4 TONE PLUCK BUZZ TERR",RGB565(48,55,67));txt(6,51,&FONT_S,"SELECT DEPTH  ALG DIM",RGB565(48,55,67));txt(6,67,&FONT_S,"ARP PERC  FX BALLS",RGB565(48,55,67));txt(6,83,&FONT_S,"EDIT 2D 3D 4D FOLD",RGB565(48,55,67));}
        if(popup_id>=0&&popup_id<6&&now_ms<popup_until){
            txt(10,22,&FONT_S,pname[popup_id],RGB565(45,50,64));
        }
    }
    if(swap)for(k=0;k<h*240;k++)buf[k]=(uint16_t)(buf[k]<<8|buf[k]>>8);
}
