# WA TUR — M-VAVE FM-1 unified bass / opera / percussive topology synthesizer

WA TUR is one sound + visual engine. Bass strings, falling percussive spheres, formant voice synthesis, spectral light, and topographic fields share audio clocks and control signals. It is **not** two independently running instruments.

## New scene 08: VINTAGE LAGOON
An original, cute amphibious crooner with 1920s shellac-disc atmosphere: small rounded eyes and moving mouth, gills and bubbles, a phonograph-disc graphic, simulated surface crackle and filtered formant vocals. Not an exact character reproduction, archival voice or vintage recording. Its mouth motion responds to measured `ao_voice`; its vowel movement to `ao_vowel`; shellac texture to `ao_crackle`.

## Scene list
1. Pure String — acoustic-electric strings
2. Felt Wood — dry muted strings and delicate impact
3. Thumb Bass — round low pluck
4. Wire Buzz — upper partials, brighter topographic peaks
5. Soprano — high formant solo
6. Baritone — low formant solo
7. Opera Choir — layered three-harmonic texture
8. Vintage Lagoon — shellac/crooner + amphibious singer

## Music → geometry
- String fundamentals → long terrain contours, low frequency height.
- Harmonic buzz and highs → jagged ridges and luminous details.
- Pluck transients and drum events → falling spheres and topographical impact rings.
- Formant vocal energy → mouth openness, breathing gills, water bubbles.
- Vowel movement → mouth/gill timing and slow phase colour.
- Space/echo → depth; dimension → projected coordinate / hyperfold.

## Run
- Open `Wa-Tur-Playable.html` in a desktop browser; activate sound, click a scene, play using A–L.
- Build WebAssembly using `./build_web.sh`, then `python3 make_web.py`.
- Run `cd fw && tests/run_host.sh` to generate native 240×240 host simulator screenshots and WAV.
- Run `node tests/wasm_regression.cjs` for the eight-scene DSP and framebuffer checks.

## Build flashable FM-1 firmware
`cd fw && ./build.sh --release 0.1`
Requires a genuine JieLi pi32v2 cross-compiler and compatible AC79 SDK. **No new `.fwsc` is included because that target toolchain and physical device are not verified here.** Do not flash a renamed ZIP, host binary, or another project's `.fwsc`.

## Current verification
C host build passed. WebAssembly compilation passed. Eight-scene synthesis/render regression passed. Browser JS syntax passed. RGB565 scenes rendered at the exact 240×240 device resolution. Real-device CPU/RAM, fidelity, UI input, latency and firmware flashing remain unverified.

## Rights
Instrument code builds on K-Tea/Dinghy/Felucca GPL-3.0 code and maintains GPL licensing. Visual character design and procedural synthesis are original. David Foster Wallace's *This Is Water* speech/text is not embedded; supply licensed/user-authorized source files before adding a speech-grain layer. Artistic references are not representations of copyrighted artworks.

## Revision 1.1: voice-to-terrain coupling
The same singing PCM contributes to low/mid/high filter telemetry, terrain relief,
and the cute aquatic crooner expression. Vowel/formant LFO now directly changes
the audio filters. Scene 08 adds 78-rpm-style pitch wow, bandwidth shaping,
static and crackle. Scene 05–07 retain soprano/baritone/choir oscillator modes.
The vintage sound is synthetic, not sourced from archival vinyl.

The full *This Is Water* speech is NOT embedded. The historical and art references
serve as broad creative direction; no third-party artworks are embedded.

**Native firmware identity:** `FM-1_948` continues the prior TONIC prototype;
renaming its display to WA TUR does not create another product ID.
The same `ktea_engine.c` is compiled in the host, WebAssembly and target app.
