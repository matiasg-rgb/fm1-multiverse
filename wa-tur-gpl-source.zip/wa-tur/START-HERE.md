# WA TUR — ONE-ENGINE FM-1 INSTRUMENT

**Development release 1.1 • M-VAVE FM-1 • eight scenes**

WA TUR is the renamed and extended TONIC experimental firmware. It is **one C DSP engine**—not two instruments, and not a separate video playback app. Its electric/acoustic plucked string, additive buzz, percussion impacts, opera voices, shellac/gramophone effect and scene geometry interact through common signal and time measurements.

## What to open

- `Wa-Tur-Playable.html`: standalone playable browser version, using the same compiled WASM C DSP and exact 240×240 FM-1 screen drawing code.
- `Wa-Tur-Eight-FM1-Scenes.png`: eight software-generated FM-1 screen previews, not on-device photographs.
- `Wa-Tur-Four-Voice-Demo.wav`: 18-second generated audio audition (4s soprano, 4s baritone, 4s choir, 6s lagoon).
- `engine/ktea_engine.c`: shared C sound/visual core.
- `fw/firmware/src/ktea_engine.c`: **identical** shared core inside the FM-1 app.
- `fw/firmware/src/ktea.c`: actual FM-1 app entry, MIDI, input and display glue.
- `CLAUDE.md`: actionable finalization instructions.

## Musical / visual mapping

| Sound activity | Real native display response |
|---|---|
| Bass fundamental and plucked string | Primary contours and relief |
| Additive buzz + treble | Micro-ridges, shimmer sparks and colour layers |
| Kick / wood / hat impulses | Falling spheres, impact ripples, bass-filter opening |
| Formant vowel synthesis | Bending topographical surface, amphibian gill gesture |
| Vocal envelope (measured PCM amplitude) | Aquatic singer's mouth and water bubbles |
| 78-rpm-style wow, filter, noise and crackle | Aged phonograph tone, analogue mark detail |
| Depth / dimension | Layer count, relief and time-dependent 4D-like projections |

## Test instructions

```sh
./build_web.sh                         # Clang WASM compile + standalone HTML
node tests/wasm_regression.cjs         # 8-scene audio + framebuffer test
node tests/watur_coupling.cjs          # operatic + terrain + shellac coupling test
node tests/create_voice_demo.cjs       # regenerates the 18-second demo
python3 tests/browser_smoke.py         # optional Playwright browser GUI test
cd fw && tests/run_host.sh             # native desktop C simulator, WAV and PNGs
```

The actual target compilation (requiring genuine JieLi pi32v2 cross-compiler + AC79 SDK) is:

```sh
cd fw && ./build.sh --release 0.1
```

The target build presently stops at a missing JieLi cross-compiler. **No new `.fwsc` is included or represented as validated.** The product ID in this inherited firmware project is `FM-1_948`; preserve this identity during revision rather than claiming a new identity has been assigned. Once a compiler/SDK is installed, validate the final firmware package checksums, boot the emulator, and test on the actual device before flashing it generally.

## Aesthetic direction

White/ivory modern art field, thin sculptural contours, sparse angular/expressive linework, and gradually accumulating coloured relief. Scene 08 adds an original smiling amphibious gramophone-era crooner, not an exact reproduction of a film character. Vintage crackle is synthesis—not sampled archival vinyl. Operatic voices are synthesized vowel-like sounds, not human recordings. Do not bundle copyrighted music, film imagery or the full David Foster Wallace speech unless appropriate rights and the source files are supplied.
