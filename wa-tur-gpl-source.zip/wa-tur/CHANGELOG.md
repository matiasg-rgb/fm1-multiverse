# WA TUR changelog

## 1.1 — 2026-11-16

- Renamed TONIC into WA TUR in browser, firmware app label and native UI while retaining FM-1_948 source identity.
- Integrated eight sound scenes including upper voice, lower voice, group voice and the shellac-era lagoon singer.
- Corrected visual telemetry order so the sung signal participates in the same frequency/energy measures as bass and drums.
- Added audible formant filter modulation, differentiated soprano/baritone registers and choir harmony, and subtle gramophone wow/bandwidth/noise.
- Added audio-energy-driven mouth, vowel-responsive gills and record-groove artwork on the native FM-1 stage.
- Added a high-resolution, telemetry-driven lagoon performer to the browser, but retained the exact native framebuffer alongside it.
- Tested native C host, WebAssembly audio/framebuffer regression (8/8), focused coupling tests, real Chromium button/audio interaction, and no-clipping audio preview.
- Target `.fwsc` still not compiled; missing cross-compiler and AC79 SDK, physical hardware not tested.
