# Build status and safety gate

| Stage | Status |
|---|---|
| C host compile | PASS (see `tests/host-wa-tur.log`) |
| WebAssembly compile | PASS (`web/wa_tur.wasm`) |
| Eight-scene audio/visual tests | PASS (`tests/wa-tur-regression.json`) |
| Voice/terrain/cackle test | PASS (`tests/watur-coupling-results.json`) |
| Browser interaction in Chromium | PASS (`tests/browser-wa-tur.log`) |
| Render 240×240 RGB565 software frames | PASS (`Wa-Tur-Eight-FM1-Scenes.png`) |
| 18-second acoustic preview clip | PASS; no clipped samples |
| JieLi AC79 target compile | BLOCKED: genuine target compiler missing |
| `.fwsc` package created / CRC validated | NOT DONE |
| Emulator boot | NOT DONE |
| Physical M-VAVE FM-1 flash / latency / CPU profiling | NOT DONE |

Do **not** rename a ZIP, WASM file, previously compiled firmware, or host executable to `.fwsc` to imply target compatibility. A flash-ready firmware must be produced by the proper target build, pass checksum/integrity checks and be exercised on target hardware.
