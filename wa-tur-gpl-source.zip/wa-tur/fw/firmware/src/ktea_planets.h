/* SPDX-License-Identifier: GPL-3.0-only */
/* K-Tea: the planets. Each is a sound recipe, a scale, a palette and a geometry.
 * Adding a planet costs a few hundred bytes: the sound is generated when you travel there. */
#pragma once
#include <stdint.h>

enum { KIND_KTEA, KIND_CRYSTAL, KIND_AMBER, KIND_MOSS, KIND_TIDE, KIND_EMBER, KIND_AURORA, KIND_NEBULA };
enum { TEX_SOFT, TEX_FACET, TEX_BANDS, TEX_MOSS, TEX_OCEAN, TEX_LAVA, TEX_ICE, TEX_SWIRL };

typedef struct { uint8_t len; int8_t st[7]; } kt_scale_t;
static const kt_scale_t KT_SCALES[] = {
    {5, {0, 2, 4, 7, 9}},              /* 0 major pentatonic */
    {7, {0, 2, 4, 6, 7, 9, 11}},       /* 1 lydian */
    {7, {0, 2, 3, 5, 7, 9, 10}},       /* 2 dorian */
    {7, {0, 2, 4, 5, 7, 9, 10}},       /* 3 mixolydian */
    {7, {0, 2, 3, 5, 7, 8, 10}},       /* 4 aeolian */
    {7, {0, 1, 3, 5, 7, 8, 10}},       /* 5 phrygian */
    {7, {0, 2, 4, 5, 7, 9, 11}},       /* 6 ionian */
    {5, {0, 3, 5, 7, 10}},             /* 7 minor pentatonic */
};

typedef struct {
    const char *name, *mood;
    uint8_t root;                      /* MIDI note of the lowest key's degree */
    uint8_t scale, kind, tex;
    uint8_t sides;                     /* seed polygon: 0 circle, 3.. sides; 7 draws a star */
    uint8_t ring;                      /* planetary ring */
    int8_t wind_x, wind_y;             /* particle drift, 1/16 px per frame (low-res) */
    uint8_t trail;                     /* glow memory, 200..250: higher = longer trails */
    uint8_t spin;                      /* planet rotation speed */
    uint8_t sky0[3], sky1[3], neb[3];  /* sky top, sky bottom, nebula */
    uint8_t pl0[3], pl1[3], pl2[3];    /* planet: dark, mid, light */
    uint8_t gl0[3], gl1[3], gl2[3];    /* glow: low, mid, high pitch */
    uint8_t def[6];                    /* size, density, scatter, drift, space, tone */
} kt_planet_t;

static const kt_planet_t KT_PLANETS[] = {
    {"K-TEA", "warm chimes, rose and tea", 48, 0, KIND_KTEA, TEX_SOFT, 5, 0, 0, -3, 236, 3,
     {26, 8, 30}, {92, 34, 58}, {150, 70, 90},
     {70, 30, 40}, {200, 120, 110}, {255, 214, 170},
     {255, 120, 150}, {255, 196, 110}, {150, 230, 160},
     {70, 82, 40, 60, 96, 70}},
    {"CRYSTAL", "glass bells in cold light", 50, 1, KIND_CRYSTAL, TEX_FACET, 3, 0, 0, 0, 230, 2,
     {0, 4, 18}, {10, 30, 70}, {60, 90, 160},
     {30, 60, 110}, {120, 190, 240}, {235, 250, 255},
     {120, 140, 255}, {90, 230, 255}, {255, 255, 255},
     {50, 74, 60, 50, 110, 112}},
    {"AMBER", "a slow gas giant", 45, 2, KIND_AMBER, TEX_BANDS, 4, 1, 4, 0, 240, 2,
     {16, 6, 0}, {80, 40, 8}, {140, 80, 30},
     {90, 40, 10}, {210, 120, 40}, {255, 220, 150},
     {255, 100, 30}, {255, 180, 60}, {255, 245, 200},
     {84, 84, 38, 50, 90, 64}},
    {"MOSS", "breath and spores", 47, 3, KIND_MOSS, TEX_MOSS, 6, 0, 1, -2, 232, 2,
     {0, 14, 8}, {16, 60, 40}, {60, 120, 70},
     {20, 50, 20}, {70, 140, 60}, {200, 230, 120},
     {60, 200, 90}, {170, 240, 80}, {255, 250, 160},
     {64, 86, 50, 64, 80, 70}},
    {"TIDE", "whale song under deep water", 43, 4, KIND_TIDE, TEX_OCEAN, 0, 0, 5, 1, 244, 1,
     {0, 4, 20}, {0, 30, 60}, {20, 70, 120},
     {0, 30, 80}, {20, 110, 170}, {150, 230, 255},
     {40, 90, 255}, {40, 210, 220}, {200, 120, 255},
     {90, 70, 44, 60, 104, 60}},
    {"EMBER", "a slow fire, rising sparks", 41, 5, KIND_EMBER, TEX_LAVA, 4, 0, 0, -10, 226, 4,
     {12, 0, 2}, {60, 8, 6}, {120, 30, 10},
     {40, 6, 4}, {200, 50, 10}, {255, 200, 60},
     {255, 40, 20}, {255, 120, 20}, {255, 230, 90},
     {58, 90, 56, 56, 76, 56}},
    {"AURORA", "a choir in the polar sky", 48, 6, KIND_AURORA, TEX_ICE, 8, 0, 0, -1, 246, 1,
     {0, 4, 14}, {6, 24, 40}, {30, 90, 80},
     {60, 80, 100}, {170, 210, 230}, {245, 255, 255},
     {40, 255, 140}, {60, 200, 255}, {230, 80, 255},
     {96, 80, 40, 62, 100, 74}},
    {"NEBULA", "a dark star nursery", 40, 7, KIND_NEBULA, TEX_SWIRL, 7, 1, -2, 0, 248, 1,
     {6, 0, 14}, {34, 6, 50}, {120, 30, 130},
     {30, 6, 50}, {110, 40, 150}, {230, 160, 255},
     {120, 60, 255}, {255, 70, 200}, {130, 200, 255},
     {110, 72, 66, 70, 112, 66}},
};
#define KT_NPLANETS ((int)(sizeof(KT_PLANETS) / sizeof(KT_PLANETS[0])))
