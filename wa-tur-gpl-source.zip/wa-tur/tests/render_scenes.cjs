const fs=require('fs'),path=require('path');
(async()=>{
 const {instance}=await WebAssembly.instantiate(fs.readFileSync(path.join(__dirname,'../web/wa_tur.wasm')),{});const a=instance.exports;
 let index=[];
 const base=path.join(__dirname,'../previews/native');fs.mkdirSync(base,{recursive:true});
 for(let i=0;i<8;i++){
  a.kt_init(440+i);a.kt_set_species(i);
  if(i>4)a.kt_button(6);
  a.kt_key((i*2)%20,1);
  for(let k=0;k<146;k++){a.kt_audio_buf(256);a.kt_update(1+k*6);}
  a.kt_render_rows(0,240);
  const px=new Uint16Array(a.memory.buffer,a.kt_fb(),240*240),rgb=Buffer.alloc(240*240*3);
  for(let k=0;k<px.length;k++){let v=px[k];rgb[k*3]=Math.round((v>>11)*255/31);rgb[k*3+1]=Math.round(((v>>5)&63)*255/63);rgb[k*3+2]=Math.round((v&31)*255/31);}
  let title=String(i+1).padStart(2,'0');fs.writeFileSync(path.join(base,title+'.rgb'),rgb);
  index.push({scene:i+1,bass:a.kt_visual_bass(),low:a.kt_visual_low(),mid:a.kt_visual_mid(),high:a.kt_visual_high(),buzz:a.kt_visual_bright(),hits:a.kt_visual_strikes()});
 }
 fs.writeFileSync(path.join(base,'scene-telemetry.json'),JSON.stringify(index,null,2));console.log(index);
})().catch(e=>{console.error(e);process.exitCode=1});
