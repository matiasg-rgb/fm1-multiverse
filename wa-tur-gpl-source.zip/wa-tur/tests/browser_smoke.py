from playwright.sync_api import sync_playwright
from pathlib import Path
p='file:///mnt/data/Wa-Tur-FM1/web/Wa-Tur-Playable.html'
with sync_playwright() as P:
 browser=P.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox','--autoplay-policy=no-user-gesture-required','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
 errs=[]
 page.on('pageerror',lambda x:errs.append(str(x)))
 page.set_content(Path('/mnt/data/Wa-Tur-FM1/web/Wa-Tur-Playable.html').read_text(), wait_until='domcontentloaded',timeout=20000)
 page.wait_for_timeout(850)
 print('wasm',page.locator('#meta').inner_text(),'button',page.locator('#start').inner_text())
 page.click('#start',timeout=15000)
 page.wait_for_timeout(2100)
 print('after start',page.locator('#start').inner_text(), 'meters',page.evaluate('Array.from(document.querySelectorAll(".fill")).map(e=>e.style.width)'))
 page.click('.scene-btn:nth-child(8)')
 page.click('#mode')
 page.locator('#p2').fill('110')
 page.wait_for_timeout(750)
 page.screenshot(path='/mnt/data/Wa-Tur-FM1/Wa-Tur-browser-preview.png',full_page=True)
 print('changed',page.locator('#meta').inner_text(),page.locator('#mode').inner_text(),page.locator('#v2').inner_text())
 print('errors:',errs)
 assert 'PAUSE' in page.locator('#start').inner_text()
 assert 'VINTAGE LAGOON' in page.locator('.sel').inner_text()
 assert not errs
 browser.close()
