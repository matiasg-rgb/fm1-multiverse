/* SPDX-License-Identifier: GPL-3.0-only */
const assert=require('node:assert/strict');
const fs=require('node:fs');
(async()=>{
 const {instance}=await WebAssembly.instantiate(fs.readFileSync(__dirname+'/../web/wa_tur.wasm'),{});
 const a=instance.exports;
 const audio=(n=256)=>{a.kt_audio_buf(n); return new Int32Array(a.memory.buffer,a.kt_abuf(),2*n);};
 const picture=()=>{a.kt_render_rows(0,240);return new Uint16Array(a.memory.buffer,a.kt_fb(),240*240).slice();};
 const score=(samples)=>samples.reduce((t,x)=>t+Math.abs(x),0);
 const checksum=(pix)=>pix.reduce((t,x,i)=>(t+(x*(i%37+1)))>>>0,0);
 a.kt_init(17491);
 let results=[];
 for(let scene=0;scene<8;scene++){
  a.kt_init(17491+scene);a.kt_set_species(scene);a.kt_key(scene%12,1);
  let energy=0,low=0,hi=0,buzz=0;let frames=0;
  for(let j=0;j<190;j++){
   energy+=score(audio());a.kt_update(j*6+1);
   low=Math.max(low,a.kt_visual_low());hi=Math.max(hi,a.kt_visual_high());
   buzz=Math.max(buzz,a.kt_visual_bright());frames++;
  }
  const pix=picture();const distinct=new Set(pix).size;
  assert(energy>10000,`scene ${scene}: silent audio`);
  assert(distinct>12,`scene ${scene}: blank native screen`);
  assert(low>0&&hi>0&&buzz>=0,`scene ${scene}: missing spectra`);
  results.push({scene,energy,low,hi,buzz,colors:distinct,checksum:checksum(pix),peak:a.kt_visual_peak()});
 }
 assert(new Set(results.map(x=>x.checksum)).size===8,'scene-specific native visuals collide');
 function snapshot(perc,balls,geom){
  a.kt_init(777);a.kt_set_species(6);a.kt_key(3,1);
  if(!perc)a.kt_button(10);if(!balls)a.kt_button(2);
  while(geom-->0)a.kt_button(6);
  let total=0;
  for(let j=0;j<550;j++){total+=score(audio());a.kt_update(j*6+1);}
  return {total,picture:checksum(picture()),hits:a.kt_visual_strikes()};
 }
 let on=snapshot(true,true,0),off=snapshot(false,true,0),hidden=snapshot(true,false,0),dimension=snapshot(true,true,2);
 assert(on.hits>off.hits,'percussion fails to generate hits');
 assert(on.total!==off.total,'percussion fails to change audible audio');
 assert(on.picture!==off.picture,'percussion impact fails to change visual scene');
 assert(on.picture!==hidden.picture,'ball display toggle fails');
 assert(on.picture!==dimension.picture,'geometry 4D projection fails');
 // Settings round-trip, all in one firmware, no second percussion project.
 a.kt_init(89);a.kt_set_species(5);a.kt_set_param(2,127);a.kt_settings_out();
 const ptr=a.kt_sbuf(),n=a.kt_sbuf_size();const saved=new Uint8Array(a.memory.buffer,ptr,n).slice();
 a.kt_set_species(1);new Uint8Array(a.memory.buffer,ptr,n).set(saved);a.kt_settings_in();
 assert.equal(a.kt_get_species(),5);assert.equal(a.kt_get_param(2),127);
 console.log(JSON.stringify({status:'passed',scenes:results,coupling:{on,off,hidden,dimension},settings:n},null,2));
})().catch(e=>{console.error(e.stack);process.exitCode=1});
