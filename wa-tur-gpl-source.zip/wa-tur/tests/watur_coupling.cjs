const fs=require('fs'),assert=require('assert').strict,path=require('path');
(async()=>{
 const {instance}=await WebAssembly.instantiate(fs.readFileSync(path.join(__dirname,'../web/wa_tur.wasm')),{});const a=instance.exports;
 function render(scene,buzz=60){
  a.kt_init(1973);a.kt_set_species(scene);a.kt_set_param(2,buzz);a.kt_key(7,1);
  let total=0,maxvoice=0,maxcrackle=0,maxVowel=0;const sample=new Float64Array(100);let ns=0;
  for(let k=0;k<360;k++){
   a.kt_audio_buf(256);const ab=new Int32Array(a.memory.buffer,a.kt_abuf(),512);
   for(let j=0;j<512;j++){
    total+=Math.abs(ab[j]);if((j%50)==0)sample[(ns++)%100]+=ab[j];
   }
   a.kt_update(k*6+1);maxvoice=Math.max(maxvoice,a.kt_visual_voice());
   maxVowel=Math.max(maxVowel,a.kt_visual_vowel());maxcrackle=Math.max(maxcrackle,a.kt_visual_crackle());
  }
  a.kt_render_rows(0,240);const px=new Uint16Array(a.memory.buffer,a.kt_fb(),240*240);
  let sum=0,unique=new Set();for(let j=0;j<px.length;j++){sum=(sum+px[j]*(j%41+1))>>>0;unique.add(px[j]);}
  return {scene,buzz,total,maxvoice,maxcrackle,maxVowel,checksum:sum,colors:unique.size,sample:Math.round(sample.reduce((q,v)=>q+Math.abs(v),0))};
 }
 const bass=render(0),soprano=render(4),baritone=render(5),choir=render(6),lagoon=render(7);
 const moreBuzz=render(7,127);
 assert.equal(bass.maxvoice,0,'bass-only unexpectedly synthesizes voice');
 for(const obj of [soprano,baritone,choir,lagoon])assert(obj.maxvoice>10,`voice silent ${obj.scene}`);
 assert(lagoon.maxcrackle>0,'shellac crackle inactive');
 assert(lagoon.maxVowel>0,'vowel filter LFO inactive');
 assert(lagoon.colors>25,'lagoon display blank');
 assert(new Set([soprano,baritone,choir,lagoon].map(s=>s.sample)).size===4,'voices not differentiated');
 assert.notEqual(lagoon.checksum,moreBuzz.checksum,'buzz does not deform sound-driven terrain');
 assert.notEqual(lagoon.sample,moreBuzz.sample,'buzz does not affect vocal/audio texture');
 const result={status:'PASS',bass,soprano,baritone,choir,lagoon,moreBuzz};
 fs.writeFileSync(path.join(__dirname,'watur-coupling-results.json'),JSON.stringify(result,null,2));
 console.log('PASS: one coupled sound/visual engine; 4 voice scenes and 78 RPM setting; real audio-to-geometry change');
})().catch(e=>{console.error(e);process.exit(1)});
