const fs=require('fs'),path=require('path');
(async()=>{
 const {instance}=await WebAssembly.instantiate(fs.readFileSync(path.join(__dirname,'../web/wa_tur.wasm')),{});const a=instance.exports;
 const parts=[{scene:4,seconds:4},{scene:5,seconds:4},{scene:6,seconds:4},{scene:7,seconds:6}];
 const chunks=[];let totalFrames=0,clipped=0,peak=0;
 for(let x=0;x<parts.length;x++){
  const part=parts[x];a.kt_init(44100+part.scene);a.kt_set_species(part.scene);a.kt_key(7,1);
  const frames=part.seconds*44100;let done=0;
  while(done<frames){const n=Math.min(256,frames-done);a.kt_audio_buf(n);const pcm=new Int32Array(a.memory.buffer,a.kt_abuf(),2*n),b=Buffer.alloc(2*n*2);
   for(let j=0;j<pcm.length;j++){
    let s=pcm[j];peak=Math.max(peak,Math.abs(s));if(Math.abs(s)>=32768)clipped++;
    b.writeInt16LE(Math.max(-32768,Math.min(32767,s)),j*2);
   }
   chunks.push(b);done+=n;a.kt_update(Math.round(done*1000/44100));
  }
  totalFrames+=frames;
 }
 const h=Buffer.alloc(44);h.write('RIFF',0);h.writeUInt32LE(36+totalFrames*4,4);h.write('WAVEfmt ',8);h.writeUInt32LE(16,16);h.writeUInt16LE(1,20);h.writeUInt16LE(2,22);h.writeUInt32LE(44100,24);h.writeUInt32LE(44100*4,28);h.writeUInt16LE(4,32);h.writeUInt16LE(16,34);h.write('data',36);h.writeUInt32LE(totalFrames*4,40);
 const target=path.join(__dirname,'../Wa-Tur-Four-Voice-Demo.wav');fs.writeFileSync(target,Buffer.concat([h,...chunks]));
 console.log(JSON.stringify({output:target,totalSeconds:totalFrames/44100,peak,clipped,sections:parts}));
})().catch(e=>{console.error(e);process.exitCode=1});
