// Maradonna 04: the singer. A chiptune formant voice sings "MA-RA-DO-NNA" at power-on (and on kt_say).
// Checks the sound is real (pitch, syllable order, vowel formants measured from the output itself), that the
// picture's singer shapes come only from the singer's measured state, and writes a WAV + frames to listen/look at.
import fs from 'node:fs';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';
const wasm = fs.readFileSync(new URL('./web/maradonna.wasm', import.meta.url));
const mk = () => new WebAssembly.Instance(new WebAssembly.Module(wasm), {}).exports;
const frame = e => { e.kt_render_rows(0, 240); return new Uint16Array(e.memory.buffer, e.kt_fb(), 57600).slice(); };
const diff = (a, b) => { let n = 0; for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) n++; return n; };
fs.mkdirSync('test-shots', { recursive: true });
const png = (f, path, scale = 2) => {
  const W = 240 * scale, raw = Buffer.alloc((W * 3 + 1) * W);
  for (let y = 0; y < W; y++) { raw[y * (W * 3 + 1)] = 0; for (let x = 0; x < W; x++) { const v = f[((y / scale) | 0) * 240 + ((x / scale) | 0)], o = y * (W * 3 + 1) + 1 + x * 3;
    raw[o] = ((v >> 11) & 31) * 255 / 31; raw[o + 1] = ((v >> 5) & 63) * 255 / 63; raw[o + 2] = (v & 31) * 255 / 31; } }
  const crc = b => { let c, t = []; for (let n = 0; n < 256; n++) { c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
    c = 0xffffffff; for (const x of b) c = t[(c ^ x) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (ty, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(ty), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
  const ih = Buffer.alloc(13); ih.writeUInt32BE(W, 0); ih.writeUInt32BE(W, 4); ih[8] = 8; ih[9] = 2;
  fs.writeFileSync(path, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ih), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
};
const res = {};
// 1. power-on: record 3 s with the flock silenced, telemetry per 128-sample block
const e = mk(); e.kt_init(21); e.kt_button(12);           // flock off: hear the singer alone
const pcm = [], tl = []; let ms = 0, acc = 0, shots = {};
for (let b = 0; b < 1034; b++) {                         // ~3.0 s
  e.kt_audio_buf(128); const a = new Int32Array(e.memory.buffer, e.kt_abuf(), 256); for (let i = 0; i < 256; i++) pcm.push(a[i]);
  acc += 128000 / 44100; if (acc >= 33) { ms += Math.floor(acc); acc -= Math.floor(acc); e.kt_update(ms);
    for (const at of [900, 1080, 1250, 1500, 1700]) if (!shots[at] && ms >= at) { e.kt_set_scene(at === 1250 ? 1 : at === 1700 ? 2 : 0); shots[at] = frame(e); png(shots[at], `test-shots/singer-${at}ms.png`); } }
  tl.push({ t: b * 128 / 44.1, env: e.kt_visual_say_env(), syl: e.kt_visual_say_syl(), f1: e.kt_visual_say_f(0), f2: e.kt_visual_say_f(1), hz: e.kt_visual_say_hz(), b: [0, 1, 2].map(k => e.kt_visual_say_band(k)) });
}
// WAV for listening
{
  const n = pcm.length / 2, buf = Buffer.alloc(44 + n * 4);
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + n * 4, 4); buf.write('WAVEfmt ', 8); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(2, 22);
  buf.writeUInt32LE(44100, 24); buf.writeUInt32LE(176400, 28); buf.writeUInt16LE(4, 32); buf.writeUInt16LE(16, 34); buf.write('data', 36); buf.writeUInt32LE(n * 4, 40);
  for (let i = 0; i < n * 2; i++) buf.writeInt16LE(Math.max(-32768, Math.min(32767, pcm[i])), 44 + i * 2);
  fs.writeFileSync('test-shots/singer-poweron.wav', buf);
}
const sung = tl.filter(x => x.syl >= 0), order = []; for (const x of sung) if (order.at(-1) !== x.syl) order.push(x.syl);
res.startMs = Math.round(sung[0].t); res.durationMs = Math.round(sung.at(-1).t - sung[0].t); res.syllables = order.join(',');
res.pitchHz = [Math.min(...sung.map(x => x.hz)), Math.max(...sung.map(x => x.hz))];
res.peakEnv = Math.max(...tl.map(x => x.env)); res.count = e.kt_visual_say_count();
assert.equal(res.syllables, '0,1,2,3', 'sings MA RA DO NNA in order');
assert.ok(res.startMs > 600 && res.startMs < 900, 'starts just after power-on');
assert.ok(res.durationMs > 800 && res.durationMs < 1400, 'a short cadence');
assert.ok(res.pitchHz[0] > 150 && res.pitchHz[1] < 900, 'a sung register');
// 2. the vowels are in the sound itself: harmonic energy below/above 1 kHz in the 'a' of MA vs the 'O' of DO
const mono = i => (pcm[2 * i] + pcm[2 * i + 1]) / 2;
const centroid = (t0, hz) => { const n = 2048, s0 = Math.round(t0 * 44.1); let sw = 0, sp = 0;   // harmonic-power centroid, 250-2200 Hz
  for (let h = 1; h * hz < 2200; h++) { const f = h * hz; if (f < 250) continue; let re = 0, im = 0;
    for (let i = 0; i < n; i++) { const w = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / n), v = mono(s0 + i) * w; re += v * Math.cos(2 * Math.PI * f * i / 44100); im += v * Math.sin(2 * Math.PI * f * i / 44100); }
    const p = re * re + im * im; sw += p * f; sp += p; } return sw / sp; };
const at = s => tl.filter(x => x.syl === s && x.env > 3000);
const aMid = at(0)[Math.floor(at(0).length * 0.6)], oMid = at(2)[Math.floor(at(2).length * 0.55)], mMid = at(0)[1];
res.centroidHz = { m: Math.round(centroid(mMid.t, mMid.hz)), a: Math.round(centroid(aMid.t, aMid.hz)), o: Math.round(centroid(oMid.t, oMid.hz)) };
assert.ok(res.centroidHz.a > res.centroidHz.o + 120, "the 'a' of MA is brighter than the 'O' of DO (formants measured in the output)");
let pk = 0, clip = 0; for (const v of pcm) { pk = Math.max(pk, Math.abs(v)); if (Math.abs(v) >= 32767) clip++; }
res.outPeak = pk; res.clippedSamples = clip;
assert.ok(pk > 6000 && clip < 50, 'clearly audible, not clipping');
res.silentAfter = tl.filter(x => x.t > 2600).every(x => x.syl < 0);
assert.ok(res.silentAfter);
// 3. the picture: during the song, turning the VOICE layer off removes the ribbon, sparks, halos and gape;
//    long after the song (and with no voices) the same toggle changes nothing near the beak
{
  const g = mk(); g.kt_init(22); g.kt_button(12); let t = 0;
  const step = n => { for (let i = 0; i < n; i++) { g.kt_audio_buf(128); if (i % 10 === 0) g.kt_update(t += 29); } };
  step(390);                                               // ~1.13 s: mid-song
  g.kt_set_layers(31); g.kt_update(t += 1); const on = frame(g); g.kt_set_layers(30); g.kt_update(t); const off = frame(g); g.kt_set_layers(31);
  res.voiceLayerPixelsDuringSong = diff(on, off);
  step(2400);                                              // ~7 s later: song, ribbon and sparks gone
  g.kt_set_layers(31); g.kt_update(t += 1); const on2 = frame(g); g.kt_set_layers(30); g.kt_update(t); const off2 = frame(g);
  res.voiceLayerPixelsAfter = diff(on2, off2);
  assert.ok(res.voiceLayerPixelsDuringSong > 2000 && res.voiceLayerPixelsAfter < 60, 'singer visuals follow the singer, and leave nothing behind');
  const before = g.kt_visual_say_count(); g.kt_say(); step(60); res.retrigger = g.kt_visual_say_count() === before + 1 && g.kt_visual_say_syl() >= 0;
  assert.ok(res.retrigger, 'kt_say sings again');
}
// 4. cost: audio time per second of sound while singing vs just after (WASM here; relative figure)
{
  const h = mk(); h.kt_init(23); h.kt_button(12); let t = 0;
  for (let i = 0; i < 240; i++) { h.kt_audio_buf(128); if (i % 10 === 0) h.kt_update(t += 29); }
  const time = n => { const a0 = performance.now(); for (let i = 0; i < n; i++) h.kt_audio_buf(128); return performance.now() - a0; };
  const sing = time(200) * 344.5 / 200;                    // inside the song (0.70 .. 1.28 s)
  for (let i = 0; i < 1400; i++) h.kt_audio_buf(128);
  const after = time(200) * 344.5 / 200;
  res.audioMsPerSecond = { singing: +sing.toFixed(2), after: +after.toFixed(2) };
}
console.log(JSON.stringify(res, null, 1)); console.log('PASS singer');
