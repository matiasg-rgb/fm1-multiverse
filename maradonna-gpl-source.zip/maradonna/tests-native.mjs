// Maradonna 03: the FM-1 picture itself (kt_render, the same C as the firmware), rendered in WebAssembly.
// Causality: visual layers must not invent activity in silence; percussion visuals exist only when it is on;
// scenes and species are visibly distinct. Also times audio and picture at silent / moderate / maximum density.
import fs from 'node:fs';
import assert from 'node:assert/strict';
const wasm = fs.readFileSync(new URL('./web/maradonna.wasm', import.meta.url));
const mk = () => new WebAssembly.Instance(new WebAssembly.Module(wasm), {}).exports;
const frame = e => { e.kt_render_rows(0, 240); return new Uint16Array(e.memory.buffer, e.kt_fb(), 57600).slice(); };
const lum = f => { let s = 0; for (const v of f) s += ((v >> 11) & 31) * 2 + ((v >> 5) & 63) + (v & 31) * 2; return s / f.length; };
const diff = (a, b, y0 = 0, y1 = 240) => { let n = 0; for (let i = y0 * 240; i < y1 * 240; i++) if (a[i] !== b[i]) n++; return n; };
const meanRGB = (f, y0, y1) => { let r = 0, g = 0, b = 0, n = 0; for (let i = y0 * 240; i < y1 * 240; i++) { const v = f[i]; r += (v >> 11) & 31; g += (v >> 5) & 63; b += v & 31; n++; } return [r / n, g / n, b / n]; };
const run = (e, blocks, t) => { for (let i = 0; i < blocks; i++) { e.kt_audio_buf(128); if (i % 12 === 0) e.kt_update(t += 35); } return t; };
const res = {};
// 1. silence: with no voices, no grains and percussion off, toggling the VOICE / GRAINS / RHYTHM layers changes nothing
{
  const e = mk(); e.kt_init(11); e.kt_button(12); let t = run(e, 3400, 600);   // flock off; the power-on song and its reverb tail fade
  e.kt_set_layers(31); e.kt_update(t += 35); const a = frame(e);
  e.kt_set_layers(31 & ~1 & ~2 & ~16); e.kt_update(t += 0); const b = frame(e);
  res.silentLayerDiff = diff(a, b, 20, 240);   // (the top line holds the species name)
  assert.ok(res.silentLayerDiff < 300, 'silent picture must not depend on signal layers: ' + res.silentLayerDiff);
}
// 2. percussion: its rings appear only when it is on
{
  const e = mk(); e.kt_init(12); e.kt_button(12); let t = run(e, 300, 600); e.kt_key(4, 1); t = run(e, 400, t);
  e.kt_set_layers(16); let maxOff = 0, maxOn = 0;   // RHYTHM layer only
  const ref = frame(e);
  for (let i = 0; i < 20; i++) { t = run(e, 8, t); maxOff = Math.max(maxOff, diff(ref, frame(e), 170, 220)); }
  e.kt_button(11);
  for (let i = 0; i < 30; i++) { t = run(e, 8, t); maxOn = Math.max(maxOn, diff(ref, frame(e), 170, 220)); }
  res.percussionPixels = { off: maxOff, on: maxOn };
  assert.ok(maxOn > maxOff + 150, 'kick/snare rings appear only with percussion on');
}
// 3. scenes are distinct
{
  const e = mk(); e.kt_init(13); let t = run(e, 300, 600); const L = [];
  for (let s = 0; s < 3; s++) { e.kt_set_scene(s); e.kt_update(t += 35); L.push(lum(frame(e))); }
  res.sceneLuma = L.map(x => +x.toFixed(1));
  assert.ok(L[1] < L[0] * 0.6 && Math.abs(L[2] - L[0]) > 1, 'Atelier, Nocturne and Prism differ');
}
// 4. the eight species: the bird's own colours differ (body region)
{
  const e = mk(); e.kt_init(14); e.kt_button(12); let t = run(e, 100, 600); const cols = [];
  for (let s = 0; s < 8; s++) {
    if (s) { e.kt_set_species(s); for (let k = 0; k < 900 && e.kt_get_species() !== s; k++) { e.kt_audio_buf(128); e.kt_update(t += 12); } t = run(e, 200, t); }
    e.kt_update(t += 35); cols.push(meanRGB(frame(e), 90, 170).map(v => Math.round(v)).join('/'));
  }
  res.speciesBodyColour = cols;
  assert.equal(new Set(cols).size, 8, 'eight distinct birds');
}
// 5. grains build the network: with GRAINS on vs off the sky differs while grains flow
{
  const e = mk(); e.kt_init(15); e.kt_set_param(1, 120); e.kt_key(6, 1); let t = run(e, 500, 600);
  e.kt_set_layers(31); e.kt_update(t += 35); const a = frame(e); e.kt_set_layers(31 & ~2); e.kt_update(t); const b = frame(e);
  res.grainLayerSkyPixels = diff(a, b, 12, 140);
  assert.ok(res.grainLayerSkyPixels > 100, 'grain network drawn from real events');
}
// 6. timing (WASM on this machine; the FM-1 figure comes from the emulator, see TEST_REPORT.md)
{
  const time = (setup) => { const e = mk(); e.kt_init(16); setup(e); let t = run(e, 300, 600);
    const a0 = performance.now(); for (let i = 0; i < 345; i++) e.kt_audio_buf(128); const audioMsPerSec = performance.now() - a0;
    const r0 = performance.now(); for (let i = 0; i < 40; i++) { e.kt_update(t += 35); e.kt_render_rows(0, 240); } const frameMs = (performance.now() - r0) / 40;
    return { audioMsPerSecond: +audioMsPerSec.toFixed(1), updatePlusRenderMs: +frameMs.toFixed(2), grains: e.kt_visual_grain_count(), tris: e.kt_visual_tris() }; };
  res.perf = {
    silent: time(e => { e.kt_button(12); }),
    moderate: time(e => { e.kt_key(3, 1); e.kt_key(8, 1); }),
    maximum: time(e => { e.kt_set_param(1, 127); e.kt_set_param(0, 127); e.kt_button(11); e.kt_button(2); for (const k of [1, 4, 7, 10, 13, 16]) e.kt_key(k, 1); }),
  };
}
console.log(JSON.stringify({ status: 'PASS', ...res }, null, 1));
