# CLAUDE.md — MARADONNA / PIGEON MORPHING INSTRUMENT

## Project identity
MARADONNA is a minimal but expressive pigeon-themed, colourful, 3D modular synthesizer based on K-Tea for the M-VAVE FM-1. It combines a cross-platform C granular/voice audio engine, a portable WebAssembly build, an offline single-file WebGL browser instrument, and a lower-complexity 240×240 native FM-1 visualization. The eight voices are *pigeon-inspired synthetic presets*, not recordings or authentic bioacoustic reconstructions.

## You are inheriting the existing working project
Do not replace it with a mockup or rewrite from scratch. Read `README.md`, `VISUAL_ENGINE_03.md` (and `VISUAL_ENGINE_02.md` for history), `TEST_REPORT.md`, `ARCHITECTURE.md`, and `HANDOFF_TASKS.md` before editing. The current files are the baseline for incremental development; preserve eight species, their identities/palettes, all six controls, optional percussion (OFF by default), three scenes, existing musical capabilities, and fallback accessibility. See `reference/K-Tea-source-ORIGINAL.zip` one directory up for the prior original source, if provenance/diff analysis is needed.

## Source-of-truth map
- `engine/ktea_engine.c`: audio engine with `kt_visual_*` telemetry; shared with native C.
- `engine/kt_wasm.c`: WebAssembly wrapper.
- `web/index.template.html`: EDIT THIS to change browser UI, shaders, data binding, visuals. It contains CSS, JS, GLSL, Worklet and fallback.
- `web/maradonna.wasm`: built C output; do not hand-edit.
- `web/Maradonna.html`: GENERATED standalone HTML; do not treat as the source.
- `fw/firmware/src/ktea_engine.c`: native copy of C engine. Keep synchronized with `engine/ktea_engine.c` when editing synthesis.
- `fw/firmware/src/ktea.c`: device UI and physical mapping.
- `fw/README.md`, `fw/docs/`, `fw/build.sh`: specific device SDK/toolchain notes and cautions.
- `tests-telemetry.mjs`, `tests-native.mjs`, `tests-singer.mjs`, `tests-browser.mjs`: the 03/04 test suite (see TEST_REPORT.md).
- `tests-reactivity.mjs`: initial WebAssembly/telemetry smoke test.
- The Device view in the browser IS `kt_render` (the FM-1 picture). Design picture changes in C, never browser-only first.
- The singer (04): `VX_SEG` phoneme table + `vx_block/vx_sample/vx_measure` in kt_audio; `kt_say()`; picture in `singer_strip()` and `lyric()`.

## The essential design rule
**Visual change must correspond to a concrete DSP signal or a user control that causally changes sound.** Current linkage: audio spectrum + voices → breathing/energy; real grain spawn counter + active grains → particle field/segmentation; scan and flutter controls → wing/tail movement; wet mix and shimmer/bloom → atmospheric halo; actual percussion envelopes → impact rings. Keep visual output stable when silent, controllable via five independent visual-layer toggles, and tasteful rather than overwhelming. The artistry may map signals nonliterally, but telemetry must not be invented.

## Audio–visual behaviours to maintain
- Eight species: Rock Dove, Fantail, King, Jacobin, Tumbler, Pouter, Nicobar, Racer.
- Morph controls: Form, Flock, Flutter, Motion, Air, Colour (0–127).
- Visual environments: Atelier, Nocturne, Prism.
- The singer greets "MA-RA-DO-NNA" at power-on (and on ♪ SING / `kt_say`); its visuals belong to the VOICE layer.
- Layer controls: Voice, Grains, Modulation, FX, Rhythm; click toggles, shift-click isolates.
- Optional Feet/Percussion defaults OFF; sound and visuals toggle together when enabled.
- Transport/keyboard, Web MIDI and fallback renderer remain operable.
- The 3D renderer can be computationally expensive: provide GPU-adaptive quality or practical fallback rather than sacrificing audio continuity.
- For FM-1, never attempt to port WebGL to hardware; use 240×240 framebuffer and bounded CPU cost.

## Immediate instructions for the next pass
1. Examine the current implementation, produce a short gap and regression-risk inventory.
2. Improve synthesis-driven morphing, especially event→geometry differentiation, modulation routing, and visual quality, without breaking audio or controls.
3. Make audio/visual coupling easy to audit; any claimed reactive relationship should have a real measurable source.
4. Add bounded, deterministic tests for telemetry, percussion default OFF, voice switching, scene and layer toggles, WebGL compile/runtime (where possible), and host C simulator.
5. Keep documentation and screenshots current. Compare performance at silent, moderate, and maximum grain density.
6. Don't present a build as flash-ready unless you genuinely generated and tested an actual Maradonna `.fwsc` with correct SDK/toolchain and appropriate hardware verification. Never rename/repackage an old K-Tea `.fwsc` as Maradonna.
7. Give the user edited files/source archive plus concise verification results. Avoid circular requests for confirmation; implement what is safe and testable.

## Commands from project root
```sh
./build_web.sh              # needs clang with wasm32 + Python 3
node tests-telemetry.mjs && node tests-native.mjs && node tests-singer.mjs && node tests-reactivity.mjs
node tests-browser.mjs      # Playwright + Chrome; serves the page over HTTP
cd fw && tests/run_host.sh tests/scripts/maradonna_04_singer.txt
# DEVICE BUILD ONLY when proper JieLi SDK and toolchain actually installed:
cd fw && ./build.sh
```

## Provenance and license
Base source is GPL-3.0-only, with various third-party attributions; retain notices and comply with GPL when sharing derivatives. See `fw/LICENSING.md`, `fw/LICENSE`, and upstream K-Tea reference. Third-party logo/artwork licenses require special attention; do not claim they are GPL-cleared merely because other code is GPL. Do not ship the proprietary JieLi SDK within this package. Original `.fwsc` is deliberately excluded to avoid accidentally flashing non-Maradonna firmware.
