#!/bin/sh
# Maradonna: build the offline browser instrument from the FM-1 sound engine.
set -eu
cd "$(dirname "$0")"
"${CLANG:-clang}" --target=wasm32 -O2 -nostdlib -ffreestanding -fvisibility=hidden -Iengine -Ifw/firmware/gen \
  -Wl,--no-entry -Wl,--export-dynamic -Wl,--initial-memory=2097152 -Wl,-z,stack-size=131072 \
  -o web/maradonna.wasm engine/kt_wasm.c
python3 - <<'PYIN'
import base64
from pathlib import Path
binary=Path('web/maradonna.wasm').read_bytes()
template=Path('web/index.template.html').read_text()
Path('web/Maradonna.html').write_text(template.replace('__WASM__',base64.b64encode(binary).decode()),encoding='utf-8')
print('Built web/Maradonna.html: '+str(len(binary))+' bytes of WebAssembly')
PYIN
