# MARADONNA / TEST REPORT — Visual Engine 03 + Singer 04 (16 Nov 2026)

All commands are run from the project root unless noted. Every test drives the real engine; none uses mocks.

| Check | Result | Evidence |
|:--|:--|:--|
| WASM build (`./build_web.sh`) | PASS | 119,144 B engine embedded in `web/Maradonna.html` |
| C engine parity | PASS | `engine/ktea_engine.c` and `fw/firmware/src/ktea_engine.c` are identical (`diff -q`) |
| Telemetry (`node tests-telemetry.mjs`) | PASS, 11 checks | silence is silent; key → scope/dry/tail; attack flag; event ring; MOTION LFO; percussion off/on; 8 species differ; effective params; REAL recording in/out; singer greeting + `kt_say` |
| Native picture (`node tests-native.mjs`) | PASS | silent layer diff 0 px; percussion rings 82 px off vs 2,495 on; scene luma 146 / 50 / 144; 8 distinct body colours; grain network 2,502 sky px |
| Singer (`node tests-singer.mjs`) | PASS | starts at 662 ms, lasts 1.18 s; syllables MA, RA, DO, NNA in order; pitch 293–466 Hz; vowel centroid from the output itself m 405 / a 882 / o 706 Hz; peak 17.6 k, 0 clipped samples; VOICE layer 8,160 px during the song, 0 after; re-trigger works |
| Legacy smoke (`node tests-reactivity.mjs`) | PASS | unchanged from baseline |
| Browser (`node tests-browser.mjs`, headless Chrome, SwiftShader) | PASS | engine active; power-on song reaches VMAP (sing 1.0); Device view lit 57,600 px; percussion default off; kick .88 / snare .59 / hat .95; Nocturne darker; layer solo/restore; Studio WebGL 56 steps; AUDIT 23 rows; ♪ SING sings; species switch; 0 page errors |
| Host simulator (`cd fw && tests/run_host.sh tests/scripts/maradonna_04_singer.txt`) | PASS | firmware C on the host: sings at power-on, PNGs at 0.9–4 s and a WAV |
| FM-1 package with the real SDK (`cd fw && ./build.sh`) | PASS | `fw/build/maradonna.fwsc`, 612,227 B, identity **FM-1_935**, sha256 `57974fd317836b87f2be31920a6838965fe7f086183a400601b3eaa8dc5c7918`; image 95,428 B of 581,564; RAM 54,464 B of 98,304; pool 269,568 B of 344,064; no 64-bit division, register access in hal/ only |
| FM-1 emulator (joakimeriksson fm1-emu, 160 MHz) | PASS (emulated) | the SDK package boots; the screen matches the host simulator; it sings at power-on (`test-shots/emulator-04-singing-1.4s.png`) |
| CPU headroom on the FM-1 | NOT VERIFIED | the emulator's load readout on this Mac swung 41 → 92 % in a sawtooth even with no input, so it measures the host browser, not the chip. WASM on x86: audio 1.1 ms per second of sound silent, 4.4 ms at 28 grains, 2.9 ms while singing; picture 1.2–1.4 ms per frame. These are relative numbers only. |
| WebGL on a real GPU | NOT VERIFIED | only SwiftShader (software) in headless Chrome |
| Physical FM-1 | NOT VERIFIED | not flashed: no latency, thermal, panel or control test on hardware |

## Limitations
- The Maradonna `.fwsc` is SDK-built and emulator-checked, but it is **not hardware-verified**. Flash it only through
  the documented route (Hub → official V15 → TransitFM1 → *Install a package file*), and keep the official firmware
  to return to.
- A rebuilt WASM is not byte-identical to the shipped baseline because of toolchain differences. Behaviour is
  checked, not bytes.
- Headless Chromium cannot start an AudioWorklet from a blob on `file://`. This was already true in the baseline,
  so the browser test serves the page over HTTP. A real browser opening the file directly falls back to the
  compatibility engine if needed.
- REAL pigeon recordings are browser-only and none are bundled (see VISUAL_ENGINE_03.md for licensing).
