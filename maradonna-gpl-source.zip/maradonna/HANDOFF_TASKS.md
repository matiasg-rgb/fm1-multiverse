# Next engineering cycle — MARADONNA 05

## Where 03/04 left it
- The FM-1 picture is a lit 3D pigeon in a river-city scene. The browser's Device view shows exactly that picture.
- Every morph comes from measured telemetry; the AUDIT view lists all 23 rows live.
- The singer greets "MA-RA-DO-NNA" at power-on.
- The SDK-built `.fwsc` (FM-1_935) boots and sings in the emulator. It is not yet hardware-verified.

## Priorities
### P0: Hardware truth
- Flash `Maradonna-04-dev.fwsc` through Hub → official V15 → TransitFM1 → *Install a package file*, keeping the
  official firmware to return to.
- On the device, measure the audio thread and frame time at silence, at maximum density and during the song.
  Consider a firmware self-timer readout behind HOME (help).
- Check panel colour and gamma against the Device view, then pots, encoders and buttons, plus thermals over 30 minutes.
- If the frame rate drops at maximum density, lower the tail/wing mesh detail first and never the audio.

### P1: The singer
- Give the device a way to sing again without losing an existing function (for example, a long-press on HOME).
- Optional lyrics or phrases per species (same formant machinery; keep it short and cute).
- Optional: let REAL recordings drive a true channel vocoder (formant envelopes taken from the recording).

### P2: Picture
- Real-GPU check of the Studio view (Chrome/Edge, macOS + Windows); tune the QUALITY table.
- Per-species variety in the skyline and river (still procedural; no text from the user's figures).
- The planetary-ring branch in `kt_render` is a K-Tea leftover (gated by `P->ring`); remove it if unused.

### P3: Packaging
- A reproducible build container for WASM, so that bytes as well as behaviour match.
- Bake a licensed CC0 pigeon recording into an optional firmware variant only if it is credited and licence-checked.

## Definition of done
- All five test files pass.
- The `.fwsc` is rebuilt with a new sha256 recorded in TEST_REPORT.md.
- Emulator and hardware results are reported separately.
- Docs and screenshots are current.
