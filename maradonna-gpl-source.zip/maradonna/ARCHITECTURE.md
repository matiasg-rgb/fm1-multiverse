# MARADONNA — Technical architecture / Claude handoff

```text
 encoders / buttons / keys / MIDI           browser UI (same messages)
                 │                                   │
                 └──────────►  engine/ktea_engine.c  ◄┘   (one C file: FM-1 firmware and WebAssembly)
                                   │
          AUDIO side: kt_audio()   │   MAIN side: kt_update() / kt_render()
   grains ─ tone LP ─ (+singer) ─ FDN reverb ─ out      NMAP followers ─ 3D mesh ─ strip raster ─ overlays
                 │                                          ▲
                 └── telemetry 03/04 (volatile ao_*, rings) ┘
                                   │
          kt_visual_* exports ─► browser: VMAP (same table) ─► Device view (= kt_render) / Studio (WebGL)
```

## The two sides
- **Audio** (`kt_audio`, the FM-1 audio interrupt):
  - 28 grains read the 65,536-sample source, with the MOTION LFO swaying grain position and pan width;
  - optional percussion;
  - one-pole tone filter;
  - **the singer** (a pulse carrier through three formant filters, phoneme timeline `VX_SEG`);
  - 4-line FDN reverb.
- **Main** (`kt_update` + `kt_render`): keys, knobs, autoplay, weather and the species generator, followed by the
  picture: `nmap_frame` → `mesh_frame` → `kt_render` in 60-row strips (`stage_rows`, `bird_strip`, `overlays_strip`,
  `singer_strip`, then text).
- The two sides share only volatile words, each with one writer: `ap_*` main → audio, and `ao_*` + rings audio → main.
  There is no heap, no float and no 64-bit division (the FM-1 has no libgcc).

## Telemetry (all measured inside kt_audio)
- **Scope and levels:** `kt_scope` (256 output samples, decimated ×4), `ao_dry`, `ao_rev` (FDN tail), `ao_lfo`.
- **Voices:** per-voice packed level, rising flag, degree and note.
- **Grain events:** 8-byte records (seed, pan, length, amp, interval, pos8, lfo8).
- **Percussion:** peak-held kick, snare and hat envelopes, and the drum step.
- **Singer (04):**
  - `ao_vx_env`: output envelope;
  - `ao_vx_band[3]`: each formant filter's own output;
  - `ao_vx_f1`, `ao_vx_f2`: formant centres in use;
  - `ao_vx_hz`: pitch;
  - `ao_vx_syl`: syllable 0–3, or −1;
  - `ao_vx_count`: phrases begun.

The browser reads the same values through `kt_visual_*` and `kt_visual_say_*`.

## Targets
- `engine/kt_wasm.c` is built with `clang --target=wasm32` (`build_web.sh`) and embedded as base64 into
  `web/Maradonna.html` from `web/index.template.html`. The AudioWorklet runs the WASM engine, including the picture,
  and posts the framebuffer to the page.
- `fw/` is the FM-1 firmware on Dinghy/Felucca. `fw/build.sh` → `tools/build.py` → `fw/build/maradonna.fwsc`, using
  the JieLi AC79 SDK and toolchain (installed separately and never shipped here).
  - Dev identity **FM-1_935**: unique, so the Firmware Hub and TransitFM1 never confuse it with K-Tea (FM-1_934) or
    with catalogue firmware (FM-1_920 is ChoralRoot).

## Verified boundaries (16 Nov 2026)
**Verified:**
- tests for telemetry, native picture, singer, browser and the legacy smoke test;
- the host simulator;
- an SDK-built `.fwsc` that boots and sings in the FM-1 emulator.

**Not verified:** real-GPU WebGL, the physical FM-1 (CPU headroom, latency, thermals, panel), and flashing.
See TEST_REPORT.md.

## Quality gates
1. Generated files correspond to source: rebuild, and the C copies are identical.
2. Every visual effect draws from bounded, measured telemetry or a control that changes the sound. Silence relaxes to rest.
3. The Device view is the firmware picture. The browser never shows a "device" picture the FM-1 cannot draw.
4. The audio callback stays bounded: the singer costs nothing when idle, and the picture is decoupled from audio.
5. Hardware gate: build and emulator checks are reported separately from hardware; no accidental flash.
