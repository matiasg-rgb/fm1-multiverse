// Maradonna 02: deterministic smoke test for the real WASM synthesis-to-visual bridge.
import fs from 'node:fs';
import assert from 'node:assert/strict';
const wasm=fs.readFileSync(new URL('./web/maradonna.wasm',import.meta.url));
const e=new WebAssembly.Instance(new WebAssembly.Module(wasm),{}).exports;
for(const name of ['kt_visual_grain_events','kt_visual_grain_count','kt_visual_voice_count',
  'kt_visual_kick','kt_visual_snare','kt_visual_hat','kt_visual_wet',
  'kt_visual_scan_phase','kt_visual_pulse_phase','kt_visual_bloom'])
 assert.equal(typeof e[name],'function',`Missing exported telemetry: ${name}`);
e.kt_init(187834);
assert.equal(e.kt_get_flag(0),0,'Percussion must default to disabled');
assert.equal(e.kt_get_species(),0);
e.kt_set_param(4,127); e.kt_update(500);
assert.equal(e.kt_get_param(4),127);
assert.ok(e.kt_visual_wet()>0);
let initial=e.kt_visual_grain_events(),maxVoices=0,maxGrains=0,maxKick=0,maxHat=0,maxSnare=0;
e.kt_midi_note(62,110,1);
e.kt_button(11);assert.equal(e.kt_get_flag(0),1);
for(let i=0;i<550;i++){
 e.kt_audio_buf(128);
 if(i%12===0)e.kt_update(i*3+600);
 maxVoices=Math.max(maxVoices,e.kt_visual_voice_count());
 maxGrains=Math.max(maxGrains,e.kt_visual_grain_count());
 maxKick=Math.max(maxKick,e.kt_visual_kick());
 maxHat=Math.max(maxHat,e.kt_visual_hat());
 maxSnare=Math.max(maxSnare,e.kt_visual_snare());
}
assert.ok(e.kt_visual_grain_events()>initial,'No real grain spawn events');
assert.ok(maxGrains>0,'No audio grain activity');
assert.ok(maxVoices>0,'No seeded voices');
assert.ok(maxKick>0&&maxHat>0&&maxSnare>0,'Missing percussion envelopes');
e.kt_button(11);assert.equal(e.kt_get_flag(0),0);
console.log(JSON.stringify({status:'PASS',wasmBytes:wasm.length,grainEvents:e.kt_visual_grain_events()-initial,
   maxGrains,maxVoices,maxKick,maxHat,maxSnare,wet:e.kt_visual_wet(),percOff:e.kt_get_flag(0)},null,2));
