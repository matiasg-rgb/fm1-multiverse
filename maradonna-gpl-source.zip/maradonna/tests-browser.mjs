// Maradonna 03: drives the generated web/Maradonna.html in headless Chromium (Playwright).
// Checks: no page errors, audio engine starts, the Device view shows the C framebuffer, the Studio WebGL shader
// compiles (SwiftShader software GPU here: real GPUs still need checking), scenes and layers reach the engine,
// percussion is off by default and toggles, AUDIT renders, telemetry flows into VMAP.
// Usage: node tests-browser.mjs [outdir]    (needs the playwright package and a Chrome/Chromium)
import { chromium } from 'playwright';
import path from 'node:path';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import http from 'node:http';
/* a tiny static server: AudioWorklet modules from blob: URLs are refused on file:// pages in Chromium */
const server = http.createServer((req, res) => { const f = path.resolve('.' + decodeURIComponent(req.url.split('?')[0])); if (!f.startsWith(path.resolve('.')) || !fs.existsSync(f)) { res.writeHead(404); res.end(); return; } res.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'application/octet-stream' }); fs.createReadStream(f).pipe(res); });
await new Promise(r => server.listen(0, '127.0.0.1', r));
const out = process.argv[2] || 'test-shots';
fs.mkdirSync(out, { recursive: true });
const file = `http://127.0.0.1:${server.address().port}/web/Maradonna.html`;
const exe = ['/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser'].find(p => fs.existsSync(p));
const browser = await chromium.launch({ executablePath: exe, args: ['--autoplay-policy=no-user-gesture-required', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 980 } });
const errors = [];
page.on('pageerror', e => errors.push(String(e)));
page.on('console', m => { if (m.type() === 'error' && !/status of 404/.test(m.text())) errors.push(m.text());   /* (the test server has no favicon) */ });
const log = {};
await page.goto(file);
await page.waitForTimeout(800);
log.webgl = await page.evaluate(() => window.MARADONNA_GL);
await page.click('#activate');
// power-on: the singer greets ("MA-RA-DO-NNA"); its measured envelope reaches VMAP, the Device view shows the song
log.powerOnSing = await page.evaluate(async () => { let m = 0, syl = new Set(); const t0 = performance.now();
  while (performance.now() - t0 < 2400) { const U = window.MARADONNA_U; if (U) m = Math.max(m, U.osc[2]); const s = window.__lastSyl; if (s !== undefined) syl.add(s); await new Promise(z => setTimeout(z, 30)); }
  return { singPeak: m }; });
assert.ok(log.powerOnSing.singPeak > 0.3, 'the power-on song reaches VMAP');
await page.waitForTimeout(100);
log.status = await page.textContent('#statusLabel');
assert.match(log.status, /ENGINE ACTIVE/);
const deviceStats = () => page.evaluate(() => {
  const c = document.querySelector('#device'), d = c.getContext('2d').getImageData(0, 0, 240, 240).data;
  let lit = 0, sum = 0, hist = new Set();
  for (let i = 0; i < d.length; i += 4) { const v = d[i] + d[i + 1] + d[i + 2]; sum += v; if (v > 30) lit++; hist.add((d[i] >> 4) << 8 | (d[i + 1] >> 4) << 4 | d[i + 2] >> 4); }
  return { lit, mean: sum / (d.length / 4), colours: hist.size };
});
log.device0 = await deviceStats();
assert.ok(log.device0.lit > 40000 && log.device0.colours > 60, 'the Device view shows the engine framebuffer');
// play: three keys, let grains flow
for (const k of ['z', 'c', 'b']) await page.keyboard.down(k);
await page.waitForTimeout(2200);
log.vmapPlaying = await page.evaluate(() => ({ voice: window.MARADONNA_U.voice, grain: window.MARADONNA_U.grain, harm: window.MARADONNA_U.harm, fx: window.MARADONNA_U.fx, impacts: window.MARADONNA_U.impB.filter((x, i) => i % 4 === 3 && x > 0).length }));
assert.ok(log.vmapPlaying.voice[0] > 0.05, 'voice energy reaches VMAP');
assert.ok(log.vmapPlaying.harm.some(h => h > 0.05), 'the measured waveform reaches VMAP');
await page.screenshot({ path: path.join(out, 'browser-device-atelier.png') });
for (const k of ['z', 'c', 'b']) await page.keyboard.up(k);
// percussion: off by default, toggles on
log.percDefault = await page.evaluate(() => flags[0]);
assert.equal(log.percDefault, false);
await page.click('button[data-btn="11"]');
await page.keyboard.down('x'); await page.waitForTimeout(600);
log.rhythm = await page.evaluate(async () => { const m = [0, 0, 0]; for (let i = 0; i < 50; i++) { const r = window.MARADONNA_U.rhythm; for (let k = 0; k < 3; k++) m[k] = Math.max(m[k], r[k]); await new Promise(z => setTimeout(z, 40)); } return { kick: m[0], snare: m[1], hat: m[2], engineFlag: flags[0] }; });
assert.equal(log.rhythm.engineFlag, true, 'the engine reports percussion on');
assert.ok(log.rhythm.kick > 0.05 && log.rhythm.snare > 0.02 && log.rhythm.hat > 0.01, 'kick, snare and hat envelopes reach VMAP separately ' + JSON.stringify(log.rhythm));
// scenes reach the engine (the Device view changes with them)
await page.click('button[data-scene="1"]'); await page.waitForTimeout(700);
log.deviceNocturne = await deviceStats();
assert.ok(log.deviceNocturne.mean < log.device0.mean * 0.75, 'NOCTURNE darkens the FM-1 picture');
await page.screenshot({ path: path.join(out, 'browser-device-nocturne.png') });
await page.click('button[data-scene="2"]'); await page.waitForTimeout(700);
await page.screenshot({ path: path.join(out, 'browser-device-prism.png') });
// layers: shift-click isolates, and the engine receives the mask
await page.click('[data-layer="4"]', { modifiers: ['Shift'] }); await page.waitForTimeout(400);
log.layersSolo = await page.evaluate(() => visualLayers.map(Number).join(''));
assert.equal(log.layersSolo, '00001');
await page.click('[data-layer="4"]'); await page.waitForTimeout(300);
log.layersAll = await page.evaluate(() => visualLayers.map(Number).join(''));
assert.equal(log.layersAll, '11111');
// Studio view: WebGL sculpture
await page.click('button[data-scene="0"]');
await page.click('button[data-view="studio"]'); await page.waitForTimeout(2500);
log.renderNote = await page.textContent('#renderNote');
await page.screenshot({ path: path.join(out, 'browser-studio.png') });
// AUDIT
await page.click('#auditBtn'); await page.waitForTimeout(500);
log.auditRows = await page.evaluate(() => document.querySelectorAll('.audit-r').length);
assert.equal(log.auditRows, 23);
await page.screenshot({ path: path.join(out, 'browser-audit.png') });
await page.keyboard.up('x');
// SING again from the button; capture the Device view mid-phrase
await page.click('#auditBtn');
await page.click('[data-view="device"]'); await page.waitForTimeout(200);
await page.click('#singBtn'); await page.waitForTimeout(700);
log.singButton = await page.evaluate(() => window.MARADONNA_U.osc[2]);
await page.screenshot({ path: path.join(out, 'browser-device-singing.png') });
assert.ok(log.singButton > 0.2, 'SING button sings');
// species switch through the UI
await page.click('.bird:nth-child(2)'); await page.waitForTimeout(3500);
log.speciesName = await page.textContent('#speciesName');
assert.equal(log.speciesName.trim(), 'FANTAIL');
log.errors = errors;
assert.equal(errors.length, 0, 'page errors: ' + errors.join(' | '));
await browser.close(); server.close();
console.log(JSON.stringify({ status: 'PASS', ...log }, null, 1));
