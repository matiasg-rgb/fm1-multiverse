# MARADONNA — Pigeon morphing instrument

An eight-species granular synthesizer for the M-VAVE FM-1, with an offline, single-file browser companion that runs
the very same C engine (WebAssembly), sound and picture alike. Built on K-Tea / Dinghy / Felucca (credited below).

## Play the browser instrument
Open `web/Maradonna.html` in Chrome or Edge and tap **ACTIVATE AUDIO + ENTER**. The singer greets you with
"MA-RA-DO-NNA", a lush chiptune vocoder voice, and then the flock begins.

- **DEVICE** view (default) shows exactly what the FM-1 screen shows: the C engine's own 240×240 framebuffer.
  **STUDIO** is a browser-only WebGL sculpture, marked *NOT ON FM-1*.
- Eight species (Rock Dove, Fantail, King, Jacobin, Tumbler, Pouter, Nicobar, Racer), each with its own scale,
  sound generator, palette, form and skyline.
- Six controls: Form, Flock, Flutter, Motion, Air, Colour.
- Buttons: Flock (self-play), Pulse, Shimmer, Hold, **Feet / Percussion** (off by default), Evolve, Bloom, Swell,
  and **♪ SING** to hear the greeting again.
- Three scenes: Atelier, Nocturne, Prism.
- Five visual layers: Voice, Grains, Mod, FX, Rhythm. Click to mute a layer; Shift-click to solo it. The sound is
  never affected.
- **AUDIT** (Shift+A) lists every signal → morph mapping with live values.
- **LOAD PIGEON RECORDING** makes the grains read a real recording; **SYNTH SOURCE** goes back.
- Keyboard: on-screen keys or Z–/, A–', Q–Y. Web MIDI is supported where the browser allows it.

## Sound honesty
The built-in voices and the singer are **synthetic**, pigeon-inspired timbres, not recordings or bioacoustic replicas.
Real pigeon calls enter only when you load a recording in the browser; none are bundled. Use recordings whose licence
allows it (Freesound CC0; xeno-canto per-recording Creative Commons licences; Macaulay Library only with permission).
The FM-1 has no audio input.

## FM-1 firmware
- `cd fw && ./build.sh` builds `fw/build/maradonna.fwsc` (identity FM-1_935). It needs the JieLi AC79 SDK and
  toolchain, which are installed separately and not included here.
- The current package was built with the real SDK and checked in the FM-1 emulator, where it boots and sings at
  power-on. **It has not been tested on hardware.**
- To install: Firmware Hub → *Back to official V15* → TransitFM1 → *Install TransitFM1* → *Install a package file*.
  See `fw/README.md` and `fw/docs` for recovery notes.
- `cd fw && tests/run_host.sh tests/scripts/maradonna_04_singer.txt` runs the firmware C on your computer and writes
  PNG screens and a WAV.

## Tests
```sh
./build_web.sh
node tests-telemetry.mjs && node tests-native.mjs && node tests-singer.mjs && node tests-reactivity.mjs
node tests-browser.mjs        # needs Playwright + Chrome
```
Results and limitations are in `TEST_REPORT.md`. The design is described in `VISUAL_ENGINE_03.md`.

## License
GPL-3.0-only, based on K-Tea / Dinghy / Felucca. See `fw/LICENSE`, `fw/LICENSING.md` and the source headers.
Third-party fonts and notices remain in place. The designburg logo (`fw/assets/logo.svg`) is not covered by the GPL.
