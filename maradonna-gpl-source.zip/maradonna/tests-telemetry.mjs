// Maradonna 03: bounded, deterministic tests of the measured telemetry the visuals are allowed to use.
// Every check drives the real WebAssembly engine; nothing here is a mock.
import fs from 'node:fs';
import assert from 'node:assert/strict';
const wasm = fs.readFileSync(new URL('./web/maradonna.wasm', import.meta.url));
const mk = () => new WebAssembly.Instance(new WebAssembly.Module(wasm), {}).exports;
const results = [];
const check = (name, fn) => { fn(); results.push(name); };

const EXPORTS = ['kt_visual_rev_tail', 'kt_visual_dry', 'kt_visual_lfo', 'kt_visual_lfo_depth', 'kt_visual_tone',
  'kt_visual_drum_step', 'kt_visual_scope_head', 'kt_visual_scope', 'kt_visual_ev_head', 'kt_visual_ev_ring',
  'kt_visual_eff', 'kt_visual_voice'];
const run = (e, blocks, from = 0) => { for (let i = 0; i < blocks; i++) { e.kt_audio_buf(128); if (i % 12 === 0) e.kt_update(from + i * 3); } return from + blocks * 3; };
const scope = e => { const r = new Int16Array(e.memory.buffer, e.kt_visual_scope(), 256); return Array.from(r); };
const rms = a => Math.sqrt(a.reduce((s, v) => s + v * v, 0) / a.length);
const events = (e, from, to) => {
  const ring = new Uint8Array(e.memory.buffer, e.kt_visual_ev_ring(), 64 * 8), out = [];
  for (let h = Math.max(from, to - 64); h < to; h++) { const o = (h & 63) * 8;
    out.push({ seed: ring[o], pan: ring[o + 1], len8: ring[o + 2], amp: ring[o + 3], iv: (ring[o + 4] << 24) >> 24, pos8: ring[o + 5], lfo8: ring[o + 6] }); }
  return out;
};
const voice = v => ({ level: v & 32767, rising: (v >> 15) & 1, deg: (v >> 16) & 255, note: v >>> 24 });

check('all telemetry-03 exports present', () => { const e = mk(); for (const n of EXPORTS) assert.equal(typeof e[n], 'function', n); });

check('silence is silent: scope, dry, reverb tail and voices are zero before any note', () => {
  const e = mk(); e.kt_init(1); e.kt_button(12); /* FLOCK self-play off */ let t = run(e, 40, 600);
  // autoplay may have started a seed before the toggle reached kt_update; release everything and let it decay
  t = run(e, 900, t);
  assert.ok(rms(scope(e)) < 40, 'scope should be ~0 in silence, rms=' + rms(scope(e)));
  assert.ok(e.kt_visual_dry() < 60, 'dry follower ' + e.kt_visual_dry());
  for (let i = 0; i < 10; i++) assert.ok(voice(e.kt_visual_voice(i)).level < 300);
});

check('a key produces measured oscillation, dry level and a reverb tail that outlives it', () => {
  const e = mk(); e.kt_init(2); e.kt_button(12); let t = run(e, 900, 600);
  e.kt_key(5, 1); t = run(e, 300, t);
  const s1 = rms(scope(e)), d1 = e.kt_visual_dry(), r1 = e.kt_visual_rev_tail();
  assert.ok(s1 > 300, 'scope rms ' + s1); assert.ok(d1 > 300, 'dry ' + d1); assert.ok(r1 > 50, 'tail ' + r1);
  e.kt_key(5, 0); t = run(e, 140, t);                           // ~0.4 s after release
  const d2 = e.kt_visual_dry(), r2 = e.kt_visual_rev_tail();
  assert.ok(r2 > 0 && r2 / Math.max(1, r1) > d2 / Math.max(1, d1) * 0.5, `the tail should decay more slowly than the dry signal (dry ${d1}->${d2}, tail ${r1}->${r2})`);
});

check('voice telemetry: attack is flagged while rising, then clears at sustain; degree and note match the key', () => {
  const e = mk(); e.kt_init(3); e.kt_button(12); let t = run(e, 900, 600);
  e.kt_key(3, 1); e.kt_audio_buf(128);
  let v = [...Array(10)].map((_, i) => voice(e.kt_visual_voice(i))).find(x => x.level > 0 || x.rising);
  assert.ok(v && v.rising === 1, 'rising flag at onset');
  t = run(e, 400, t);
  v = [...Array(10)].map((_, i) => voice(e.kt_visual_voice(i))).find(x => x.level > 20000);
  assert.ok(v && v.rising === 0, 'sustain clears the rising flag');
  assert.equal(v.deg, 3 % 5, 'Rock Dove is pentatonic: key 3 is degree 3');
  assert.ok(v.note >= 40 && v.note < 100);
});

check('grain events: the ring holds real, bounded attributes and advances exactly with the counter', () => {
  const e = mk(); e.kt_init(4); e.kt_set_param(1, 120); e.kt_key(7, 1);
  const h0 = e.kt_visual_ev_head(), c0 = e.kt_visual_grain_events();
  run(e, 200, 600);
  const h1 = e.kt_visual_ev_head(), c1 = e.kt_visual_grain_events();
  assert.equal((h1 - h0) >>> 0, (c1 - c0) >>> 0, 'ring head and grain counter agree');
  const ev = events(e, h0, h1); assert.ok(ev.length > 5, 'events ' + ev.length);
  for (const g of ev) { assert.ok(g.seed < 10); assert.ok(g.len8 >= 1 && g.amp >= 1); assert.ok([-12, 0, 7, 12].includes(g.iv)); }
  assert.ok(new Set(ev.map(g => g.pan)).size > 2, 'pans vary');
});

check('MOTION drives an audible LFO: depth follows the knob, the phase moves, grain events carry it', () => {
  const e = mk(); e.kt_init(5); e.kt_set_param(3, 0); e.kt_update(600);
  const d0 = e.kt_visual_lfo_depth(); e.kt_set_param(3, 127); e.kt_update(620);
  const d1 = e.kt_visual_lfo_depth(); assert.ok(d1 > d0 * 2 && d1 > 6000, `depth ${d0}->${d1}`);
  const seen = new Set(); for (let i = 0; i < 400; i++) { e.kt_audio_buf(128); if (i % 12 === 0) e.kt_update(640 + i * 3); seen.add(e.kt_visual_lfo() >> 12); }
  assert.ok(seen.size >= 6, 'LFO swings through ' + seen.size + ' buckets');
});

check('percussion is OFF by default and produces no envelopes; ON produces kick, snare and hat steps', () => {
  const e = mk(); e.kt_init(6); assert.equal(e.kt_get_flag(0), 0); e.kt_key(2, 1);
  let mk_ = 0, ms = 0, mh = 0, t = 600;
  for (let i = 0; i < 600; i++) { e.kt_audio_buf(128); if (i % 12 === 0) e.kt_update(t += 36); mk_ = Math.max(mk_, e.kt_visual_kick()); ms = Math.max(ms, e.kt_visual_snare()); mh = Math.max(mh, e.kt_visual_hat()); }
  assert.equal(mk_ + ms + mh, 0, 'no envelopes while off');
  e.kt_button(11); assert.equal(e.kt_get_flag(0), 1); const steps = new Set();
  for (let i = 0; i < 900; i++) { e.kt_audio_buf(128); if (i % 12 === 0) e.kt_update(t += 36); mk_ = Math.max(mk_, e.kt_visual_kick()); ms = Math.max(ms, e.kt_visual_snare()); mh = Math.max(mh, e.kt_visual_hat()); steps.add(e.kt_visual_drum_step()); }
  assert.ok(mk_ > 0 && ms > 0 && mh > 0); assert.equal(steps.size, 8, 'all eight steps fire');
});

check('species switching: every one of the eight pigeons loads, and their waveforms differ', () => {
  const e = mk(); e.kt_init(7); e.kt_button(12); let t = run(e, 50, 600); const sig = [];
  for (let s = 0; s < 8; s++) {
    if (s) { e.kt_set_species(s); for (let k = 0; k < 800 && e.kt_get_species() !== s; k++) { e.kt_audio_buf(128); e.kt_update(t += 12); } }
    assert.equal(e.kt_get_species(), s, 'species ' + s);
    t = run(e, 300, t); e.kt_key(10, 1); t = run(e, 260, t);
    const sc = scope(e); let zc = 0; for (let i = 1; i < 256; i++) if ((sc[i - 1] < 0) !== (sc[i] < 0)) zc++;
    sig.push(zc); e.kt_key(10, 0); t = run(e, 200, t);
  }
  assert.ok(new Set(sig).size >= 5, 'zero-crossing signatures ' + sig.join(','));
});

check('effective parameters are bounded and equal the knob when weather is still', () => {
  const e = mk(); e.kt_init(8); e.kt_set_param(3, 0); e.kt_update(600);
  for (let p = 0; p < 6; p++) { const v = e.kt_visual_eff(p); assert.ok(v >= 0 && v <= 127); }
  assert.equal(e.kt_visual_eff(3), 0);
});

check('REAL source: a committed recording becomes what the grains read; SYNTH SOURCE restores the voice', () => {
  const e = mk(); e.kt_init(9); e.kt_button(12); let t = run(e, 900, 600);
  const n = 30000, pcm = new Int16Array(e.memory.buffer, e.kt_src_buf(), n);   // a stand-in "coo": a gliding 380-520 Hz tone, amplitude-swelled
  for (let i = 0; i < n; i++) { const u = i / n; pcm[i] = Math.round(20000 * Math.sin(Math.PI * u) * Math.sin(2 * Math.PI * (380 * i + 70 * n * u * u) / 44100)); }
  e.kt_src_commit(n); assert.equal(e.kt_visual_src_real(), 1, 'REAL flag set');
  e.kt_key(7, 1); t = run(e, 300, t); assert.ok(rms(scope(e)) > 300, 'the recording sounds through the grains');
  e.kt_key(7, 0); e.kt_set_species(2); for (let k = 0; k < 900 && e.kt_get_species() !== 2; k++) { e.kt_audio_buf(128); e.kt_update(t += 12); }
  assert.equal(e.kt_visual_src_real(), 1, 'the recording survives a species change');
  e.kt_src_synth(); for (let k = 0; k < 900 && e.kt_visual_src_real(); k++) { e.kt_audio_buf(128); e.kt_update(t += 12); }
  assert.equal(e.kt_visual_src_real(), 0, 'back to the synthetic voice');
});

check('the singer: power-on greeting, then silence; kt_say sings again', () => {
  const e = mk(); e.kt_init(10); e.kt_button(12); let seen = new Set(), t = 0;
  for (let i = 0; i < 1100; i++) { e.kt_audio_buf(128); if (i % 10 === 0) e.kt_update(t += 29); seen.add(e.kt_visual_say_syl()); }
  assert.deepEqual([...seen].sort(), [-1, 0, 1, 2, 3]); assert.equal(e.kt_visual_say_count(), 1); assert.equal(e.kt_visual_say_syl(), -1);
  e.kt_say(); for (let i = 0; i < 40; i++) e.kt_audio_buf(128); assert.equal(e.kt_visual_say_count(), 2); assert.ok(e.kt_visual_say_env() > 500);
});

console.log(JSON.stringify({ status: 'PASS', checks: results.length, names: results }, null, 1));
