/* SPDX-License-Identifier: GPL-3.0-only */
/* Maradonna: eight sculptural pigeon voices for the M-VAVE FM-1.
 * Built on Dinghy (zvenson) and Felucca's platform (Leo Kuroshita, Hügelton Instruments).
 *
 * The sound and the picture are ktea_engine.c (the same file runs in the browser prototype).
 * This file only connects it to the FM-1: the audio interrupt, the panel, MIDI, the screen, the settings.
 *
 *   keys       seed the selected pigeon voice: grains in that bird's scale
 *   K1..K4     FORM FLOCK FLUTTER MOTION; SELECT: AIR; ALGORITHM: COLOUR; PRESETS: species
 *   PLAY       self-playing flock         REC   hold (keys latch, the scan freezes)
 *   GLO        bloom                       FX    shimmer (octaves up)
 *   ARP        pulse                       ENV   slow swell
 *   SEQ        feet / rhythmic percussion (off by default)   LFO colours  SCL evolve   SAVE memory
 *   HOME       help                        OCT- OCT+ octave
 *   MIDI in    notes from USB or TRS play seeds (chromatic); the keys' notes go out on channel 1 */
static void app_idle(void);
#define LCD_IDLE app_idle
#define APP_NAME "MARADONNA"
#define CV_MAX (240u * 120u)                    /* two strips of 240 x 60: one drawn while the other goes out */
#include "platform.c"

#define KT_POOL __attribute__((section(".pool")))
#define KT_HAVE_FONT 1
#define KT_API static
#include "ktea_engine.c"

static void app_audio(int32_t *out, uint32_t n) { kt_audio(out, n); }

static uint32_t idle_ok;
static void midi_in(void)
{
    uint8_t st, d1, d2;
    while (midi_get(&st, &d1, &d2)) {
        uint32_t ty = st & 0xF0u;
        if (ty == 0x90u && d2) kt_midi_note(d1, d2, 1);
        else if (ty == 0x80u || ty == 0x90u) kt_midi_note(d1, 0, 0);
    }
}
static void app_idle(void)
{
    if (idle_ok) midi_in();
}

static void draw_frame(void)
{
    uint32_t s;
    idle_ok = 1;
    for (s = 0; s < 4u; s++) {
        uint16_t *half = cv_px + (s & 1u) * (240u * 60u);
        if (s >= 2u) lcd_sync();                /* the half we are about to draw into may still be going out */
        kt_render(half, (int)(s * 60u), 60, 1);
        lcd_blit(0, s * 60u, 240, 60, half);
        platform_poll();
    }
    idle_ok = 0;
}

static void app_main(void)
{
    uint32_t prev = 0, k, b, rel, btn, keys_lit, glow, last_btn = ~0u, last_keys = ~0u, last_glow = ~0u;
    int32_t e;
    kt_settings_t set;
#ifdef DINGHY_HOST
    kt_init(12345u);
#else
    kt_init(fm1_ticks());
#endif
    if (settings_load(&set, sizeof set) == 0) kt_set_settings(&set);

    for (;;) {
        uint32_t keys, down, up;
        platform_poll();

        keys = fm1_in.notes;
        down = keys & ~prev;
        up = prev & ~keys;
        prev = keys;
        for (k = 0; k < 27u; k++) {
            if (down >> k & 1u) { kt_key((int)k, 1); midi_send(0x90u, (uint8_t)(53u + k), 100); }
            if (up >> k & 1u) { kt_key((int)k, 0); midi_send(0x80u, (uint8_t)(53u + k), 0); }
        }
        b = fm1_input_edges(&rel);
        for (k = 0; k < 14u; k++) if (b >> k & 1u) kt_button((int)k);
        for (k = 0; k < 7u; k++) if ((e = fm1_enc_take(k)) != 0) kt_encoder((int)k, e);
        midi_in();

        kt_update(fm1_ms);
        draw_frame();

        kt_leds(&btn, &keys_lit, &glow);
        if (btn != last_btn) { for (k = 0; k < 14u; k++) fm1_led_key(k, btn >> k & 1u); last_btn = btn; }
        if (keys_lit != last_keys || glow != last_glow) {
            for (k = 0; k < 27u; k++) {
                fm1_led_key(KEY_LED(k), keys_lit >> k & 1u);
                if (!(keys_lit >> k & 1u)) fm1_led_key_glow(KEY_LED(k), glow >> k & 1u);
            }
            last_keys = keys_lit; last_glow = glow;
        }
        if (kt_take_save()) {                   /* SAVE pressed: the erase stalls the sound for a moment */
            kt_get_settings(&set);
            settings_save(&set, sizeof set);
        }
    }
}
