# MARADONNA / VISUAL ENGINE 03 + THE SINGER (04)

## One picture, two screens
The FM-1's own renderer (`kt_render` in `engine/ktea_engine.c`) is the picture. The browser's default **DEVICE** view
shows that exact 240×240 framebuffer, computed by the same C compiled to WebAssembly, pixel for pixel. What you see
there is what the FM-1 shows. Nothing is designed in the browser first and "compressed" for the device afterwards.
**STUDIO** is an optional browser-only WebGL sculpture, labelled *NOT ON FM-1*.

## The native renderer (C, integers only, no 64-bit division)
- A lit pigeon made of 18–20 ellipsoid parts: body, breast/crop, head, beak (two mandibles while singing), wings,
  seven tail feathers, legs and feet, plus the Jacobin's ruff and the Nicobar's collar. It is drawn strip by strip
  (60 rows) with a z-buffer, Gouraud shading, fresnel rim, specular, a warm/cool tint from the filter, thin-film
  shimmer, and a gradient painted by the voices that are sounding.
- The scene uses motifs from the user's own book figures, drawn procedurally. None of the figures' writing and none
  of their image files are used:
  - a river city skyline with an arched bridge and a dusk sun;
  - river wave crests that are the measured waveform;
  - reflections stretched by the reverb tail;
  - the ledge the bird stands on;
  - a constellation network of grain events;
  - ribbon streamers for the voices.
- Three scenes: **Atelier** (ink on paper), **Nocturne** (dusk, silhouettes, lit windows), **Prism** (spectral bands).
- Five visual layers with the same switches as the browser: VOICE, GRAINS, MOD, FX, RHYTHM. Turning a layer off
  removes only its shapes; the sound never changes.

## Signal → morph (NMAP in C, mirrored by VMAP in the browser; the AUDIT button lists every row live)
| Measured source (inside `kt_audio`) | Morph | Layer |
|:--|:--|:--|
| voice levels, attack flags | breath, crop and rim flash; voice-coloured gradient | VOICE |
| `kt_scope` (the real output, 256 samples) | river crests, waveform line; browser: ripple harmonics | VOICE |
| dry level (pre-reverb) | crest height (relaxes flat when the signal is silent) | VOICE |
| grain events (pos, pan, interval, length, amp) | surface bulges and rings where the grain sat; network stars | GRAINS |
| active grains / spawn rate | wing segmentation, shimmer pulse | GRAINS |
| scan position, the MOTION LFO the grains follow | wing lift, tail sway, body yaw | MOD |
| reverb tail (FDN output), AIR in use, shimmer | halo, reflections, thin film, rim | FX |
| kick / snare / hat envelopes (peak-held) | squash onto the feet, tail flick, glints; floor rings | RHYTHM |
| **the singer** (see below) | beak gape, crop swell, vowel plume, formant halos, ripples, chip sparks, lit lyric | VOICE |

## The singer (04): a lush chiptune vocoder that sings "MA-RA-DO-NNA"
**Sound.** A 25 % pulse carrier, chiptune style, with a soft fifth on the left and a slightly sharp octave on the
right for width, plus a 4-bit triangle an octave up for sparkle. It runs through three resonant formant filters
(Chamberlin state-variable band-passes) that glide through the phonemes:

> m · a · r · a · d (closure, burst) · O · nn · a

The formants are lifted 12.5 % for a small, cute voice. The pitch follows the species' key: the "DO" accent always
lands between G4 and F♯5, with chiptune slides between syllables and a vibrato on the last "a". The phrase lasts
about 1.2 s. It sits after the tone filter and before the reverb, so AIR blooms around it.
- It sings once **at power-on**, 0.65 s after start. The flock waits until 1.9 s.
- It sings again from **♪ SING** in the browser (`kt_say()` in C).
- On the FM-1 it is the power-on greeting. The device has no button free for it without taking one away from an
  existing function.

**Picture.** Everything below is driven by what the singer measures inside `kt_audio`:
- the output envelope;
- each formant band's own output;
- the formant centres and pitch in use;
- the syllable being sung.

The morphs:
- **Beak and crop:** the beak opens into two mandibles with the envelope, and the crop swells as a cooing pigeon's does.
- **Vowel plume:** each frame releases three beads of light from the beak. F2 aims them: front vowels fly forward,
  back vowels fly up and behind. F1 sets how far and how wide they fan. The colour is the vowel's own (open a = gold,
  O = violet, nasals = rose).
- **Formant halos:** three rings at the beak, one per formant band, each as bright as that band's output.
- **Syllable ripples:** each syllable sends a ripple and a burst of square chip sparks (3 px grid, four-step fade).
- **Lyric:** at power-on the big MARADONNA title lights syllable by syllable; later greetings show a small lyric line.

## REAL pigeon recordings (browser)
**LOAD PIGEON RECORDING** puts a recording into the grain buffer. The page:
1. picks the loudest 1.49 s window;
2. resamples it to 44.1 kHz;
3. loops it with a crossfade and normalises it.

The species keeps its scale, palette and form. **SYNTH SOURCE** returns to the synthetic voice. No recordings are
bundled. The built-in voices are synthetic and pigeon-inspired, not bioacoustic replicas. For real calls, use material
whose licence allows it:
- Freesound CC0 recordings;
- xeno-canto recordings under each recording's own Creative Commons licence (many are NC/SA; credit the recordist);
- Macaulay Library recordings only with permission.

The FM-1 has no audio input; on the device, REAL material would have to be baked into the firmware's source buffer
and licensed accordingly.
