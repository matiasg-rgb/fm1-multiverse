/* SPDX-License-Identifier: GPL-3.0-only */
/* K-Tea in the browser: the same engine, compiled to WebAssembly. */
#include <stdint.h>
#include <stddef.h>
void *memset(void *d, int c, size_t n) { unsigned char *p = d; while (n--) *p++ = (unsigned char)c; return d; }
void *memcpy(void *d, const void *s, size_t n) { unsigned char *p = d; const unsigned char *q = s; while (n--) *p++ = *q++; return d; }
#define KT_API __attribute__((visibility("default")))
#include "ktea_engine.c"
static int32_t abuf[2 * 256];
static uint16_t fb[240 * 240];
static kt_settings_t sbuf;
KT_API int32_t *kt_abuf(void) { return abuf; }
KT_API uint16_t *kt_fb(void) { return fb; }
KT_API kt_settings_t *kt_sbuf(void) { return &sbuf; }
KT_API int kt_sbuf_size(void) { return (int)sizeof(kt_settings_t); }
KT_API void kt_audio_buf(uint32_t n) { uint32_t i; for (i = 0; i < 2u * n; i++) abuf[i] = 0; kt_audio(abuf, n); }
KT_API void kt_render_rows(int y0, int h) { kt_render(fb + y0 * 240, y0, h, 0); }
KT_API void kt_settings_out(void) { kt_get_settings(&sbuf); }
KT_API void kt_settings_in(void) { kt_set_settings(&sbuf); }
static uint32_t leds[3];
KT_API uint32_t *kt_leds_buf(void) { kt_leds(&leds[0], &leds[1], &leds[2]); return leds; }
