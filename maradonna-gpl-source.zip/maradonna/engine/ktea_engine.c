/* SPDX-License-Identifier: GPL-3.0-only */
/* Maradonna: a pigeon morphing instrument for the M-VAVE FM-1.
 *
 * One engine for the FM-1 (built on Dinghy) and for the browser (WebAssembly): integers only, no float,
 * no 64-bit division, no heap. Two owners:
 *   - the AUDIO side: kt_audio() (the FM-1's audio interrupt). It owns the grains, the filter, the reverb.
 *   - the MAIN side: everything else (keys, knobs, evolution, autoplay, the planet generator, the picture).
 * They share only volatile words with one writer each (ap_* main -> audio, ao_* and the event ring audio -> main).
 *
 * Memory: the grain source 128 KB, the reverb 23 KB, the picture layers ~100 KB: all in KT_POOL. */
#include <stdint.h>
#include "ktea_tables.h"
#include "ktea_planets.h"

#ifndef KT_POOL
#define KT_POOL
#endif
#ifndef KT_API
#define KT_API
#endif
#ifndef KT_HAVE_FONT
typedef struct {
    uint8_t h, pad, first, last;
    const uint8_t *adv, *bw;
    const uint16_t *off;
    const uint8_t *data;
} felucca_font_t;
#include "felucca_font.h"
#endif

#define KT_FS 44100
#define SRC_BITS 16
#define SRC_LEN (1u << SRC_BITS)
#define LW 120
#define LH 120
#define LN (LW * LH)
#define NSEED 10
#define MAXG 28
#define NPART 140
#define SUB 32

typedef struct { uint8_t ver, planet, p[6]; int8_t octave; uint8_t autoplay, shimmer, lens, pal, pulse, swell, hold, perc; } kt_settings_t;
enum { P_SIZE, P_DENS, P_SCAT, P_DRIFT, P_SPACE, P_TONE };
static const char *const P_NAME[6] = {"FORM", "FLOCK", "FLUTTER", "MOTION", "AIR", "COLOUR"};

/* ------------------------------------------------------------------ shared memory */
static int16_t kt_src[SRC_LEN + 1] KT_POOL;
#define RVL0 2203
#define RVL1 2687
#define RVL2 3163
#define RVL3 3593
static int16_t kt_rv[RVL0 + RVL1 + RVL2 + RVL3] KT_POOL;
static uint8_t kt_glow[LN] KT_POOL;      /* glow intensity: trails */
static uint8_t kt_hue[LN] KT_POOL;       /* glow colour index 0..15 */
static uint16_t kt_glut[16 * 32];         /* glow colour x intensity */

/* main -> audio */
static volatile uint32_t ap_len = 8820, ap_spawn, ap_center, ap_pulse;
static volatile int32_t ap_scatter, ap_tone = 20000, ap_fb = 26000, ap_wet = 8000, ap_damp = 18000;
static volatile int32_t ap_ggain = 20000, ap_level = 0, ap_shimmer = 0;
static volatile uint32_t ap_kill, ap_bloom, ap_perc, ap_drum_period = 5512;
typedef struct {
    volatile uint32_t rate;               /* playback rate Q16 */
    volatile int32_t gate;                /* target level Q15, 0 = release */
    volatile int32_t att, rel;            /* level step per SUB frames */
} seedshare_t;
static seedshare_t sd[NSEED];
/* audio -> main */
static volatile int32_t ao_amp[NSEED], ao_level, ao_peak;
/* Real-time visual telemetry. Read-only to both the FM-1 UI and the browser.
 * These quantities come from the synthesis graph, not a fabricated animation clock. */
static volatile uint32_t ao_grain_events, ao_grain_count, ao_voice_count;
/* Telemetry 03 (all measured inside kt_audio, nothing animated by a clock):
 *   kt_scope   the last 256 output samples, mono, decimated by 4 (~23 ms): the real oscillation
 *   ao_rev     peak follower of the reverb's own tail (what the FDN outputs), not the AIR knob
 *   ao_dry     peak follower of the dry, filtered signal before the reverb
 *   ao_lfo     the MOTION LFO that actually moves grain position and pan width (Q15)
 *   a_drum_step the percussion step that fired last */
static int16_t kt_scope[256];
static volatile uint32_t ao_scope_head;
static volatile int32_t ao_rev, ao_dry, ao_lfo;
static volatile uint32_t ap_lfo_inc, ap_lfo_depth;
typedef struct { uint8_t seed, pan, len8, amp; int8_t iv; uint8_t pos8, lfo8, pad; } gev_t;   /* 8 bytes: read as-is by the browser */
static gev_t kt_ev[64];
static volatile uint32_t ev_head;
static uint32_t ev_tail;

/* ------------------------------------------------------------------ small helpers */
static int32_t kt_sine(uint32_t ph)       /* full cycle over 2^32 -> -32767..32767 (Dinghy's parabola) */
{
    int32_t x = (int32_t)ph >> 16, ax = x < 0 ? -x : x, y, ay;
    y = (x * (32768 - ax)) >> 13;
    ay = y < 0 ? -y : y;
    y += ((((y * ay) >> 15) - y) * 7373) >> 15;
    return y > 32767 ? 32767 : y < -32767 ? -32767 : y;
}
static uint32_t kt_hash(uint32_t x)
{
    x ^= x >> 16; x *= 0x7feb352du; x ^= x >> 15; x *= 0x846ca68bu; x ^= x >> 16;
    return x;
}
static int32_t clamp16(int32_t v) { return v > 32767 ? 32767 : v < -32767 ? -32767 : v; }
static int32_t clampi(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }
static uint32_t kt_isqrt(uint32_t v)
{
    uint32_t r = 0, b = 1u << 30;
    while (b > v) b >>= 2;
    while (b) {
        if (v >= r + b) { v -= r + b; r = (r >> 1) + b; } else r >>= 1;
        b >>= 2;
    }
    return r;
}
static uint32_t vnoise_w(uint32_t x, uint32_t y, uint32_t sh, uint32_t seed, uint32_t wrapx)   /* smooth value noise 0..255, cells of 2^sh; x wraps at wrapx */
{
    uint32_t cx = x >> sh, cy = y >> sh, cx1 = wrapx ? ((cx + 1u) % (wrapx >> sh)) : cx + 1u, fx = (x & ((1u << sh) - 1u)) << (8u - sh), fy = (y & ((1u << sh) - 1u)) << (8u - sh);
    uint32_t a = kt_hash(cx * 73856093u ^ cy * 19349663u ^ seed) & 255u, b = kt_hash(cx1 * 73856093u ^ cy * 19349663u ^ seed) & 255u;
    uint32_t c = kt_hash(cx * 73856093u ^ (cy + 1u) * 19349663u ^ seed) & 255u, d = kt_hash(cx1 * 73856093u ^ (cy + 1u) * 19349663u ^ seed) & 255u;
    uint32_t sx = fx * fx * (768u - 2u * fx) >> 16, sy = fy * fy * (768u - 2u * fy) >> 16;   /* smoothstep */
    uint32_t top = a * (256u - sx) + b * sx, bot = c * (256u - sx) + d * sx;
    return (top * (256u - sy) + bot * sy) >> 16;
}
static uint32_t vnoise(uint32_t x, uint32_t y, uint32_t sh, uint32_t seed) { return vnoise_w(x, y, sh, seed, 0); }
#define RGB565(r, g, b) ((uint16_t)((((uint32_t)(r) >> 3) << 11) | (((uint32_t)(g) >> 2) << 5) | ((uint32_t)(b) >> 3)))
static uint16_t add565(uint16_t a, uint16_t b)
{
    uint32_t r = (a >> 11) + (b >> 11), g = ((a >> 5) & 63u) + ((b >> 5) & 63u), bl = (a & 31u) + (b & 31u);
    if (r > 31u) r = 31u;
    if (g > 63u) g = 63u;
    if (bl > 31u) bl = 31u;
    return (uint16_t)((r << 11) | (g << 5) | bl);
}
static uint16_t mix565(uint16_t a, uint16_t b, uint32_t t) /* t 0..256 */
{
    int32_t ar = a >> 11, ag = (a >> 5) & 63, ab = a & 31, br = b >> 11, bg = (b >> 5) & 63, bb = b & 31;
    ar += ((br - ar) * (int32_t)t) >> 8;
    ag += ((bg - ag) * (int32_t)t) >> 8;
    ab += ((bb - ab) * (int32_t)t) >> 8;
    return (uint16_t)((ar << 11) | (ag << 5) | ab);
}
static uint16_t scale565(uint16_t a, uint32_t t) /* t 0..256 */
{
    uint32_t r = ((a >> 11) * t) >> 8, g = (((a >> 5) & 63u) * t) >> 8, b = ((a & 31u) * t) >> 8;
    return (uint16_t)((r << 11) | (g << 5) | b);
}
static void lerp3(const uint8_t *a, const uint8_t *b, uint32_t t, uint8_t *o) /* t 0..256 */
{
    int i;
    for (i = 0; i < 3; i++) o[i] = (uint8_t)(a[i] + (((int32_t)b[i] - a[i]) * (int32_t)t >> 8));
}

/* ================================================================== AUDIO SIDE */
typedef struct { uint32_t pos, rate, wph, winc; int32_t gl, gr; } grain_t;
static grain_t gr[MAXG];
static uint8_t gr_on[MAXG];
static int32_t sd_amp[NSEED];
static uint32_t a_rng = 0x1234567u, a_acc, a_beat, a_kill_seen, a_bloom_seen, a_rr;
static uint32_t a_drum_clock, a_kick_phase, a_hat_noise = 0x9f37a611u;
static int32_t a_kick_env, a_hat_env, a_snare_env;
static uint32_t a_lfo_ph, a_scope_dec;
static int32_t a_kick_pk, a_snare_pk, a_hat_pk;          /* the envelopes, peak-held per block (see below) */
static volatile uint32_t ao_hits;                         /* drum hits, monotonic */
static int32_t a_rev_f, a_dry_f;
static uint8_t a_drum_step;
static int32_t a_bloom, a_level, a_lpL, a_lpR, rv_z[4];
static uint32_t rv_pos[4];
static int16_t *const rv_line[4] = {kt_rv, kt_rv + RVL0, kt_rv + RVL0 + RVL1, kt_rv + RVL0 + RVL1 + RVL2};
static const uint32_t rv_len[4] = {RVL0, RVL1, RVL2, RVL3};

static uint32_t a_rand(void) { a_rng ^= a_rng << 13; a_rng ^= a_rng >> 17; a_rng ^= a_rng << 5; return a_rng; }

static void a_spawn(int burst_seed)
{
    uint32_t i, r, k, nact = 0, pick = 0, best;
    int32_t scat = ap_scatter, amp, pan, iv = 0;
    grain_t *g;
    if (burst_seed >= 0) pick = (uint32_t)burst_seed;
    else {                                      /* a sounding seed, weighted by its level */
        int32_t tot = 0, x;
        for (i = 0; i < NSEED; i++) if (sd_amp[i] > 300) { tot += sd_amp[i] >> 4; nact++; }
        if (!nact) return;
        x = (int32_t)(a_rand() % (uint32_t)tot);
        for (i = 0; i < NSEED; i++) if (sd_amp[i] > 300) { x -= sd_amp[i] >> 4; if (x < 0) { pick = i; break; } }
    }
    if (sd_amp[pick] < 200) return;
    for (i = 0, k = MAXG, best = 0; i < MAXG; i++) {   /* a free grain, else the one most nearly done */
        if (!gr_on[i]) { k = i; break; }
        if (gr[i].wph > best) { best = gr[i].wph; k = i; }
    }
    g = &gr[k];
    r = a_rand();
    {   /* pitch: the seed's, sometimes an octave or a fifth away (scatter, shimmer), a little detuned */
        uint32_t rate = sd[pick].rate;
        if ((int32_t)(r & 32767u) < ap_shimmer) { rate <<= 1; iv = 12; }
        else if ((int32_t)((r >> 15) & 32767u) < scat >> 2) {
            uint32_t c = (r >> 3) % 3u;
            if (c == 0) { rate = (uint32_t)(((uint64_t)rate * 98304u) >> 16); iv = 7; }
            else if (c == 1) { rate <<= 1; iv = 12; }
            else { rate >>= 1; iv = -12; }
        }
        r = a_rand();
        {
            int32_t det = ((int32_t)(r & 2047u) - 1024) * (scat >> 7);     /* up to ~+-1.7 % */
            rate = (uint32_t)((int64_t)rate + (((int64_t)rate * det) >> 22));
        }
        g->rate = rate;
    }
    {   /* where in the planet's sound: around the scan point, scattered, swayed by the MOTION LFO */
        int32_t off = ((int32_t)((r >> 11) & 65535u) - 32768) * (scat >> 7) >> 8;
        int32_t sway = (int32_t)(((int64_t)ao_lfo * (int32_t)ap_lfo_depth) >> 15);   /* samples, +- up to ~0.3 s */
        g->pos = ap_center + ((uint32_t)(off + sway) << 16) + (a_rand() & 0xFFFFu);
    }
    {
        uint32_t len = ap_len, rr = a_rand();
        len = len * (96u + (rr & 63u)) >> 7;                  /* 0.75 .. 1.25 */
        if (len < 400u) len = 400u;
        g->wph = 0;
        g->winc = (512u << 16) / len;
        amp = (int32_t)((((int64_t)sd_amp[pick] * ap_ggain) >> 15) * (int32_t)(180u + ((rr >> 6) & 75u)) >> 8);
        pan = 128 + ((((int32_t)((rr >> 13) & 255u) - 128) * (9000 + (scat * 23 >> 5) + (int32_t)(((int64_t)(ao_lfo + 32768) * (int32_t)ap_lfo_depth) >> 18))) >> 15);
        pan = clampi(pan, 0, 255);
        g->gl = (amp * kt_sine(((uint32_t)(255 - pan)) << 22)) >> 15;   /* equal power over a quarter cycle */
        g->gr = (amp * kt_sine(((uint32_t)pan) << 22)) >> 15;
        gr_on[k] = 1;
        ao_grain_events++;
        {   /* tell the picture */
            uint32_t h = ev_head;
            gev_t *e = &kt_ev[h & 63u];
            e->seed = (uint8_t)pick;
            e->pan = (uint8_t)pan;
            e->len8 = (uint8_t)clampi((int32_t)(len >> 8), 1, 255);
            e->amp = (uint8_t)clampi(amp >> 7, 1, 255);
            e->iv = (int8_t)iv;
            e->pos8 = (uint8_t)(g->pos >> 24);         /* where in the 1.5 s source the grain reads */
            e->lfo8 = (uint8_t)((ao_lfo + 32768) >> 8);
            e->pad = 0;
            ev_head = h + 1u;
        }
    }
}


/* ------------------------------------------------------------------ THE SINGER (04)
 * A lush chiptune "vocoder": a 25 % pulse carrier (plus a soft fifth and a detuned octave, panned apart for width)
 * shaped by three resonant formant filters that glide through the phonemes of "MA-RA-DO-NNA". Sung once at power-on
 * and on request (kt_say). It sits after the tone filter and before the reverb, so AIR blooms around it.
 * Measured for the picture, never animated by a clock: the output envelope, each formant band's own output level,
 * the formant centres in use, the pitch in use and the syllable being sung (see kt_visual_say_*). */
typedef struct { uint16_t ms, f1, f2, f3; uint8_t a1, a2, a3, voiced, noise, syl; int8_t st; } vx_seg_t;
static const vx_seg_t VX_SEG[] = {
    /*  ms   F1    F2    F3   a1  a2  a3  vox noi syl  st */
    {  70,  280, 1100, 2300, 255, 70, 40,  95,  0, 0,  7 },    /* m  (nasal, lips closed: low and soft) */
    { 145,  780, 1320, 2700, 255,215,120, 255,  0, 0,  7 },    /* a */
    {  40,  430, 1180, 1650, 220,150, 70, 150,  0, 1,  9 },    /* r  (a tapped r: a quick dip, F3 low) */
    { 135,  780, 1320, 2700, 255,215,120, 245,  0, 1,  9 },    /* a */
    {  32,  300, 1700, 2700, 120, 60, 40,   0,  0, 2, 12 },    /* d  closure */
    {  14,  400, 1750, 2800, 160,220,200,  40,200, 2, 12 },    /* d  release burst */
    { 215,  460,  790, 2400, 255,170, 55, 255,  0, 2, 12 },    /* O  the accent, a fourth above */
    {  70,  270, 1550, 2500, 255, 80, 50, 110,  0, 3,  7 },    /* nn */
    { 300,  770, 1300, 2650, 255,210,115, 240,  0, 3,  7 },    /* a  long, with vibrato, falling */
    { 160,  700, 1200, 2600, 255,170, 90,   0,  0, 3,  4 },    /* release */
};
#define VX_NSEG ((int)(sizeof(VX_SEG) / sizeof(VX_SEG[0])))
static volatile uint32_t ap_say, ap_vx_root = 60;               /* main -> audio: a request counter, the root note */
static volatile int32_t ao_vx_env, ao_vx_band[3], ao_vx_f1, ao_vx_f2, ao_vx_hz;
static volatile int32_t ao_vx_syl = -1;                         /* -1: silent */
static volatile uint32_t ao_vx_count;                           /* phrases begun */
static uint32_t a_say_seen, vx_t, vx_seg_end, vx_ph0, vx_ph1, vx_ph2, vx_ph3, vx_inc, vx_vib, vx_noise = 0x9E3779B9u;
static int vx_seg = -1;
static int32_t vx_f[3], vx_fa[3], vx_amp, vx_nz, vx_lo[3], vx_bp[3], vx_env_f, vx_bpk[3], vx_bf[3];
static const int32_t VX_Q[3] = {5200, 3300, 2600};             /* damping (1/Q, Q15): F1 wider, F3 narrowest */
static uint32_t vx_inc_for(int st)                              /* phase increment for root + st semitones, cute register */
{
    int base = 48 + (int)(ap_vx_root % 12u), n;                 /* the accent (+12) always lands G4..F#5 */
    if (base + 12 < 67) base += 12;
    n = clampi(base + st, 36, 96) - 60;
    return (uint32_t)(((uint64_t)25480013u * KT_SEMI_Q16[60 + n]) >> 16);   /* middle C = 261.63 Hz * 2^32 / 44100 */
}
static void vx_block(uint32_t m)                                /* per 32-sample block: the phoneme timeline, glides */
{
    const vx_seg_t *s;
    int k;
    if (ap_say != a_say_seen) {
        a_say_seen = ap_say;
        vx_seg = 0; vx_t = 0; vx_seg_end = (uint32_t)VX_SEG[0].ms * 441u / 10u;
        vx_inc = vx_inc_for(VX_SEG[0].st);
        for (k = 0; k < 3; k++) { vx_f[k] = (&VX_SEG[0].f1)[k] * 9 / 8; vx_fa[k] = 0; vx_lo[k] = vx_bp[k] = 0; }
        vx_amp = 0; vx_nz = 0; vx_vib = 0;
        ao_vx_count++;
    }
    if (vx_seg < 0) return;
    vx_t += m;
    while (vx_seg >= 0 && vx_t >= vx_seg_end) {
        if (++vx_seg >= VX_NSEG) { vx_seg = -1; break; }
        vx_seg_end += (uint32_t)VX_SEG[vx_seg].ms * 441u / 10u;
    }
    if (vx_seg < 0) { ao_vx_syl = -1; return; }
    s = &VX_SEG[vx_seg];
    for (k = 0; k < 3; k++) {                                   /* formants glide (~12 ms), a small creature: x 1.125 */
        int32_t tf = (int32_t)(&s->f1)[k] * 9 / 8, ta = (int32_t)(&s->a1)[k] << 7;
        vx_f[k] += (tf - vx_f[k]) >> 4;
        vx_fa[k] += (ta - vx_fa[k]) >> 3;
    }
    vx_amp += (((int32_t)s->voiced << 7) - vx_amp) >> 3;
    vx_nz += (((int32_t)s->noise << 7) - vx_nz) >> 2;
    {   /* pitch: a chiptune slide between syllables, vibrato that grows on the last vowel */
        uint32_t tgt = vx_inc_for(s->st);
        vx_inc = (uint32_t)((int32_t)vx_inc + (((int32_t)tgt - (int32_t)vx_inc) >> 4));
    }
    ao_vx_syl = s->syl;
    ao_vx_f1 = vx_f[0]; ao_vx_f2 = vx_f[1];
}
static int32_t vx_sample(int32_t *right)                        /* one stereo sample of the singer (only while singing) */
{
    int32_t car, carR, nz, out = 0, k, inc, f;
    uint32_t vib_d = vx_seg >= 8 ? 1u : 0u;
    vx_vib += 584000u;                                          /* 6 Hz */
    inc = (int32_t)vx_inc;
    if (vib_d) inc += (int32_t)(((int64_t)inc * kt_sine(vx_vib)) >> 21);     /* +-1.6 % */
    vx_ph0 += (uint32_t)inc;
    vx_ph1 += (uint32_t)inc + ((uint32_t)inc >> 1);             /* the fifth */
    vx_ph2 += ((uint32_t)inc << 1) + ((uint32_t)inc >> 8);      /* the octave, a little sharp: shimmer */
    vx_ph3 += (uint32_t)inc << 1;
    car = (vx_ph0 < 0x40000000u ? 9000 : -3000);                /* 25 % pulse, DC-balanced */
    carR = car;
    car += vx_ph1 < 0x80000000u ? 1400 : -1400;                 /* fifth to the left */
    carR += vx_ph2 < 0x60000000u ? 1500 : -900;                 /* octave to the right */
    car = (car * vx_amp) >> 15;
    carR = (carR * vx_amp) >> 15;
    vx_noise ^= vx_noise << 13; vx_noise ^= vx_noise >> 17; vx_noise ^= vx_noise << 5;
    nz = (((int32_t)(vx_noise >> 17) - 16384) * vx_nz) >> 15;
    car += nz; carR += nz;
    {
        int32_t sl = 0, sr = 0, mid = (car + carR) >> 1;
        for (k = 0; k < 3; k++) {                               /* Chamberlin state-variable band-passes */
            int32_t hi, b;
            f = vx_bf[k];
            vx_lo[k] = clampi(vx_lo[k] + ((f * vx_bp[k]) >> 15), -60000, 60000);
            hi = mid - vx_lo[k] - ((VX_Q[k] * vx_bp[k]) >> 15);
            vx_bp[k] += (f * hi) >> 15;
            vx_bp[k] = clampi(vx_bp[k], -60000, 60000);
            b = (vx_bp[k] * vx_fa[k]) >> 15;
            b = b * VX_Q[k] >> 15;                              /* unity at the centre */
            sl += b; sr += b;
            if (b < 0) b = -b;
            if (b > vx_bpk[k]) vx_bpk[k] = b;
        }
        /* stereo: a touch of each side's own carrier on top, and a 4-bit triangle an octave up (the chip sparkle) */
        {
            int32_t tri = (int32_t)((vx_ph3 >> 31) ? ~vx_ph3 : vx_ph3) >> 27;    /* 0..15 */
            tri = ((tri - 8) * 150 * vx_amp) >> 15;
            sl += ((car - mid) >> 2) + tri;
            sr += ((carR - mid) >> 2) + tri;
        }
        out = clamp16(sl * 2);
        *right = clamp16(sr * 2);
    }
    return out;
}
static void vx_measure(int32_t pk)                              /* per block, after the samples */
{
    int k;
    for (k = 0; k < 3; k++) {
        ao_vx_band[k] = vx_bpk[k];
        vx_bpk[k] -= (vx_bpk[k] >> 4) + 1;
        if (vx_bpk[k] < 0) vx_bpk[k] = 0;
        vx_bf[k] = 2 * kt_sine((uint32_t)clampi(vx_f[k], 80, 4200) * 48696u);   /* 2 sin(pi f / fs), Q15 */
    }
    vx_env_f = pk > vx_env_f ? pk : vx_env_f - (vx_env_f >> 5) - 1;
    if (vx_env_f < 0) vx_env_f = 0;
    ao_vx_env = vx_env_f;
    ao_vx_hz = (int32_t)(((uint64_t)vx_inc * 44100u) >> 32);
}

KT_API void kt_audio(int32_t *out, uint32_t n)
{
    int32_t L[SUB], R[SUB];
    uint32_t base, i, j;
    if (ap_kill != a_kill_seen) { a_kill_seen = ap_kill; for (i = 0; i < MAXG; i++) gr_on[i] = 0; }
    if (ap_bloom != a_bloom_seen) { a_bloom_seen = ap_bloom; a_bloom = 14; }
    for (base = 0; base < n; base += SUB) {
        uint32_t m = n - base < SUB ? n - base : SUB;
        int32_t lvl_t = ap_level, peak = 0, rvpk = 0, drypk = 0, vxpk = 0;
        for (i = 0; i < m; i++) L[i] = R[i] = 0;
        vx_block(m);                                    /* the singer's phoneme timeline (idle: returns at once) */
        a_lfo_ph += ap_lfo_inc * m;                     /* the MOTION LFO: one sine, used by the grains below */
        ao_lfo = kt_sine(a_lfo_ph);
        for (i = 0; i < NSEED; i++) {                 /* seed levels glide (slow swells, no clicks) */
            int32_t a = sd_amp[i], gt = sd[i].gate;
            if (a < gt) { a += sd[i].att; if (a > gt) a = gt; }
            else if (a > gt) { a -= sd[i].rel; if (a < gt) a = gt; }
            sd_amp[i] = a;
            ao_amp[i] = a;
        }
        {   /* new grains */
            uint32_t sp = ap_spawn * m;
            if (ap_pulse) {                             /* pulse: bursts on a slow beat, round the seeds */
                uint32_t ob = a_beat;
                a_beat += ap_pulse * m;
                if (a_beat < ob) {
                    for (j = 0; j < NSEED; j++) { a_rr = (a_rr + 1u) % NSEED; if (sd_amp[a_rr] > 300) break; }
                    if (sd_amp[a_rr] > 300) for (j = 0; j < 4u; j++) a_spawn((int)a_rr);
                }
                sp >>= 2;
            }
            a_acc += sp;
            while (a_acc >= (1u << 24)) { a_acc -= 1u << 24; a_spawn(-1); }
            if (a_bloom > 0) { a_bloom--; a_spawn(-1); a_spawn(-1); }
        }
        for (j = 0; j < MAXG; j++) {                  /* the grains */
            grain_t *g = &gr[j];
            uint32_t pos, rate, wph, winc;
            int32_t gl, grr;
            if (!gr_on[j]) continue;
            pos = g->pos; rate = g->rate; wph = g->wph; winc = g->winc; gl = g->gl; grr = g->gr;
            for (i = 0; i < m; i++) {
                uint32_t idx = pos >> 16;
                int32_t s0 = kt_src[idx], s1 = kt_src[idx + 1u], s, w;
                s = s0 + (((s1 - s0) * (int32_t)((pos >> 2) & 0x3FFFu)) >> 14);
                w = KT_HANN[wph >> 16];
                s = (s * w) >> 15;
                L[i] += (s * gl) >> 15;
                R[i] += (s * grr) >> 15;
                pos += rate;
                wph += winc;
                if (wph >= (512u << 16)) { gr_on[j] = 0; break; }
            }
            g->pos = pos; g->wph = wph;
        }
        {   /* level (planet travel), tone, reverb */
            int32_t lv = a_level, step = (lvl_t > lv ? 48 : 64) * (int32_t)m / SUB;
            int32_t tone = ap_tone, fb = ap_fb, wet = ap_wet, dry = 32767 - (ap_wet >> 1), damp = ap_damp;
            if (lv < lvl_t) { lv += step; if (lv > lvl_t) lv = lvl_t; }
            else if (lv > lvl_t) { lv -= step; if (lv < lvl_t) lv = lvl_t; }
            a_level = lv;
            ao_level = lv;
            for (i = 0; i < m; i++) {
                int32_t x = (L[i] * lv) >> 15, y = (R[i] * lv) >> 15, d[4], a, b, c, e, k;
                /* Optional gentle 8-step pigeon-foot rhythm: kick, snap and feather hats.
                 * Pure integers / no dynamic allocation: also safe in the FM-1 audio ISR. */
                if (ap_perc) {
                    if (++a_drum_clock >= ap_drum_period) {
                        a_drum_clock = 0;
                        a_drum_step = (uint8_t)((a_drum_step + 1u) & 7u);
                        if (!(a_drum_step & 3u)) a_kick_env = 10500;
                        if (a_drum_step == 2u || a_drum_step == 6u) a_snare_env = 5700;
                        a_hat_env = (a_drum_step & 1u) ? 2200 : 1500;
                        ao_hits++;
                    }
                    a_hat_noise ^= a_hat_noise << 13;
                    a_hat_noise ^= a_hat_noise >> 17;
                    a_hat_noise ^= a_hat_noise << 5;
                    {
                        int32_t dkick = (kt_sine(a_kick_phase) * a_kick_env) >> 15;
                        int32_t dn = (int32_t)(a_hat_noise >> 17) - 16384;
                        int32_t dperc = dkick + ((dn * (a_hat_env + a_snare_env)) >> 15);
                        x += dperc; y += dperc;
                    }
                    a_kick_phase += (uint32_t)(28000000 + a_kick_env * 1250);
                    a_kick_env -= (a_kick_env >> 9) + 1;
                    a_hat_env -= (a_hat_env >> 6) + 1;
                    a_snare_env -= (a_snare_env >> 8) + 1;
                    if (a_kick_env < 0) a_kick_env = 0;
                    if (a_hat_env < 0) a_hat_env = 0;
                    if (a_snare_env < 0) a_snare_env = 0;
                    if (a_kick_env > a_kick_pk) a_kick_pk = a_kick_env;
                    if (a_snare_env > a_snare_pk) a_snare_pk = a_snare_env;
                    if (a_hat_env > a_hat_pk) a_hat_pk = a_hat_env;
                }
                a_lpL += ((x - a_lpL) * tone) >> 15;
                a_lpR += ((y - a_lpR) * tone) >> 15;
                x = clamp16(a_lpL);
                y = clamp16(a_lpR);
                if (vx_seg >= 0) {                     /* the singer: after the tone filter, into the reverb */
                    int32_t vr2, vl2 = vx_sample(&vr2), va = vl2 < 0 ? -vl2 : vl2;
                    if (va > vxpk) vxpk = va;
                    x = clamp16(x + vl2); y = clamp16(y + vr2);
                }
                for (k = 0; k < 4; k++) {
                    d[k] = rv_line[k][rv_pos[k]];
                    rv_z[k] += ((d[k] - rv_z[k]) * damp) >> 15;
                }
                a = rv_z[0] + rv_z[1]; b = rv_z[0] - rv_z[1]; c = rv_z[2] + rv_z[3]; e = rv_z[2] - rv_z[3];
                d[0] = (a + c) >> 1; d[1] = (b + e) >> 1; d[2] = (a - c) >> 1; d[3] = (b - e) >> 1;
                rv_line[0][rv_pos[0]] = (int16_t)clamp16((x >> 2) + ((d[0] * fb) >> 15));
                rv_line[1][rv_pos[1]] = (int16_t)clamp16((y >> 2) + ((d[1] * fb) >> 15));
                rv_line[2][rv_pos[2]] = (int16_t)clamp16((x >> 2) + ((d[2] * fb) >> 15));
                rv_line[3][rv_pos[3]] = (int16_t)clamp16((y >> 2) + ((d[3] * fb) >> 15));
                for (k = 0; k < 4; k++) if (++rv_pos[k] >= rv_len[k]) rv_pos[k] = 0;
                {   /* measured: the dry signal and the reverb's own tail */
                    int32_t ax = x < 0 ? -x : x, tl = rv_z[0] + rv_z[2];
                    if (tl < 0) tl = -tl;
                    if (ax > drypk) drypk = ax;
                    if (tl > rvpk) rvpk = tl;
                }
                x = ((x * dry) >> 15) + (((rv_z[0] + rv_z[2]) * wet) >> 14);
                y = ((y * dry) >> 15) + (((rv_z[1] + rv_z[3]) * wet) >> 14);
                x = clamp16(x); y = clamp16(y);
                out[2u * (base + i)] += x;
                out[2u * (base + i) + 1u] += y;
                if (++a_scope_dec >= 4u) {             /* the oscilloscope: what actually leaves the engine */
                    uint32_t sh = ao_scope_head;
                    a_scope_dec = 0;
                    kt_scope[sh & 255u] = (int16_t)((x + y) >> 1);
                    ao_scope_head = sh + 1u;
                }
                if (x < 0) x = -x;
                if (x > peak) peak = x;
            }
            ao_peak = peak;
            /* followers: fast attack, release ~0.25 s (dry) / ~0.7 s (tail), per 32-sample block */
            a_dry_f = drypk > a_dry_f ? drypk : a_dry_f - (a_dry_f >> 5) - 1;
            a_rev_f = rvpk > a_rev_f ? rvpk : a_rev_f - (a_rev_f >> 7) - 1;
            if (a_dry_f < 0) a_dry_f = 0;
            /* the drums' envelopes last 2-12 ms; a picture sampled at 30 fps would miss most hits. Publish them
             * peak-held: the attack is the envelope's own, the release ~45 ms (64 blocks). Silent when percussion is off. */
            a_kick_pk -= (a_kick_pk >> 6) + 1; a_snare_pk -= (a_snare_pk >> 6) + 1; a_hat_pk -= (a_hat_pk >> 5) + 1;
            if (a_kick_pk < 0) a_kick_pk = 0;
            if (a_snare_pk < 0) a_snare_pk = 0;
            if (a_hat_pk < 0) a_hat_pk = 0;
            if (a_rev_f < 0) a_rev_f = 0;
            ao_dry = a_dry_f; ao_rev = a_rev_f;
            vx_measure(vxpk);
        }
    }
    {   /* Published once per audio block; no heap, no floating point, no work in the main loop. */
        uint32_t active = 0, voices = 0;
        for (i = 0; i < MAXG; i++) active += gr_on[i] != 0;
        for (i = 0; i < NSEED; i++) voices += sd_amp[i] > 300;
        ao_grain_count = active;
        ao_voice_count = voices;
    }
}

/* ================================================================== MAIN SIDE */
static uint32_t m_rng = 0xC0FFEEu;
static uint32_t m_rand(void) { m_rng ^= m_rng << 13; m_rng ^= m_rng >> 17; m_rng ^= m_rng << 5; return m_rng; }

static kt_settings_t S;
typedef struct { int8_t key; uint8_t on, deg, note, autos, latched; uint32_t until, born; uint16_t theta; int16_t speed; } seedm_t;
static seedm_t sm[NSEED];
static int cur_planet = -1, next_planet;
static uint32_t now_ms, last_ms, next_auto, popup_until, title_until, splash_until, flash_until;
static int popup_p = -1, help_on;
static uint32_t center_q16;                    /* scan position */
static int32_t walk[6], walk_t[6];
static uint32_t walk_next[6];
static int warp;                               /* 0 still, 1 fading out, 2 generating, 3 fading in */
static uint32_t gen_pos, gen_phase;
static int src_note;
static uint8_t src_real;                       /* 1: the grain source is an imported recording, kept across species */
static int save_req;

/* ---- the planet generator: fills kt_src with a seamless loop (integer cycles over the buffer) */
typedef struct { uint32_t inc, am_inc; int32_t amp, am_depth; } partial_t;
static partial_t gp[40];
static int gp_n;
typedef struct { uint32_t pos; uint32_t inc[4]; int32_t amp[4]; uint8_t sh[4]; } strike_t;
static strike_t gs[16];
static int gs_n;
static uint32_t g_seed, g_fund_c;
static int32_t g_noise, g_noise_f, g_noise_q, g_noise_am, g_crackle, g_fm, g_clip, g_strike_amp, g_air;
static int32_t gn_low, gn_band, gn_low2, gn_band2, g_prescale, g_peak;
static uint32_t g_fm_ph[2], g_fm_inc[2], g_noise_am_inc;

static uint32_t cycles_for(int midi)            /* integer cycles over the 65536-sample loop */
{
    /* f = 440 * 2^((midi-69)/12); cycles = f * 65536 / 44100. 440 * 65536 / 44100 = 653.88 */
    int st = midi - 69;
    uint32_t c = 653880u;                       /* x1000 */
    while (st >= 12) { c <<= 1; st -= 12; }
    while (st < 0) { c >>= 1; st += 12; }
    c = (uint32_t)(((uint64_t)c * KT_SEMI_Q16[60 + st]) >> 16);
    return (c + 500u) / 1000u;
}
static void gadd(uint32_t cycles, int32_t amp, uint32_t am_c, int32_t am_depth)
{
    if (gp_n >= 40 || cycles == 0 || cycles >= 29000u) return;
    gp[gp_n].inc = cycles << 16;
    gp[gp_n].am_inc = am_c << 16;
    gp[gp_n].amp = amp;
    gp[gp_n].am_depth = am_depth;
    gp_n++;
}
static int32_t formant_amp(uint32_t cyc)        /* an 'ah' choir: peaks near 700, 1150, 2800 Hz */
{
    static const int32_t F[3] = {1040, 1710, 4160}, W[3] = {420, 520, 900}, A[3] = {32767, 20000, 9000};
    int32_t a = 900, k;
    for (k = 0; k < 3; k++) {
        int32_t d = (int32_t)cyc - F[k];
        if (d < 0) d = -d;
        if (d < W[k]) a += A[k] * (W[k] - d) / W[k];
    }
    return a;
}
static void gen_setup(int pl)
{
    const kt_planet_t *P = &KT_PLANETS[pl];
    uint32_t f, h, k;
    int i;
    src_note = P->root + 12;
    f = cycles_for(src_note);
    g_fund_c = f;
    g_seed = 0x9E3779B9u * (uint32_t)(pl + 1);
    gp_n = gs_n = 0;
    g_noise = g_crackle = g_fm = g_clip = g_strike_amp = g_air = 0;
    g_noise_f = 8000; g_noise_q = 20000; g_noise_am = 0; g_noise_am_inc = 2u << 16;
    gn_low = gn_band = gn_low2 = gn_band2 = 0;
    switch (P->kind) {
    case KIND_KTEA:                              /* warm pad and little tea-cup chimes */
        for (h = 1; h <= 6; h++) { gadd(f * h, 9000 / (int32_t)h, h, 6000); gadd(f * h + 1u, 6000 / (int32_t)h, h + 1u, 8000); }
        gadd(f * 2u - 1u, 3000, 3, 12000);
        g_strike_amp = 1;
        g_noise = 1200; g_noise_f = 22000; g_noise_q = 9000; g_noise_am = 26000; g_noise_am_inc = 3u << 16;
        break;
    case KIND_CRYSTAL: {                          /* glass: inharmonic bell partials, slow shimmer */
        static const uint32_t R[6] = {1000, 2756, 5404, 8933, 13340, 2000};
        for (i = 0; i < 6; i++) gadd((f * 2u * R[i] + 500u) / 1000u, 7000 - i * 800, (uint32_t)(1 + i), 16000);
        for (i = 0; i < 3; i++) gadd((f * 4u * R[i] + 500u) / 1000u + 1u, 2400, (uint32_t)(2 + i), 22000);
        g_strike_amp = 1;
        break; }
    case KIND_AMBER:                              /* a warm saw choir, three slightly apart */
        for (h = 1; h <= 16; h++) {
            int32_t a = 16000 / (int32_t)h;
            if (h > 8) a = a * (int32_t)(20 - h) / 12;
            gadd(f * h, a, h & 3u, 4000);
            gadd(f * h + h, a * 3 / 4, 1, 6000);
            gadd(f * h - h, a / 2, 2, 6000);
        }
        break;
    case KIND_MOSS:                               /* breath through a flute, wind in leaves */
        gadd(f, 14000, 2, 10000); gadd(f * 2u, 4500, 3, 14000); gadd(f * 3u, 2000, 5, 18000);
        gadd(f * 2u + 2u, 3000, 1, 12000);
        g_noise = 9000; g_noise_f = 5200; g_noise_q = 6000; g_noise_am = 22000; g_noise_am_inc = 3u << 16;
        g_air = 1;
        break;
    case KIND_TIDE:                               /* whale song gliding over a slow surf */
        g_fm = 1;
        g_fm_inc[0] = f << 16; g_fm_inc[1] = (f * 3u / 2u) << 16;
        g_fm_ph[0] = g_fm_ph[1] = 0;
        gadd(f / 2u, 5000, 1, 20000);
        g_noise = 10000; g_noise_f = 1600; g_noise_q = 30000; g_noise_am = 30000; g_noise_am_inc = 2u << 16;
        break;
    case KIND_EMBER:                              /* a low drone, crackling */
        gadd(f / 2u, 9000, 1, 8000); gadd(f, 12000, 2, 6000); gadd(f * 2u, 7000, 3, 9000); gadd(f * 3u, 4000, 1, 12000);
        gadd(f + 1u, 6000, 4, 8000); gadd(f * 5u, 1800, 5, 20000);
        g_crackle = 12000; g_clip = 1;
        g_noise = 2500; g_noise_f = 2600; g_noise_q = 14000; g_noise_am = 16000;
        break;
    case KIND_AURORA:                             /* a choir: harmonics shaped by vowel formants */
        for (h = 1; h <= 30; h++) {
            int32_t a = formant_amp(f * h) * 3 / (int32_t)(h + 4);
            gadd(f * h, a, h % 4u + 1u, 7000);
            gadd(f * h + 1u + (h >> 3), a * 2 / 3, h % 3u + 1u, 9000);
        }
        g_noise = 1400; g_noise_f = 14000; g_noise_q = 12000; g_noise_am = 20000;
        break;
    default:                                      /* NEBULA: a sub drone, far stars of high partials */
        gadd(f / 2u, 12000, 1, 6000); gadd(f, 9000, 2, 9000); gadd(f + 1u, 6000, 1, 9000);
        { static const uint8_t H[6] = {8, 11, 13, 17, 19, 23};
          for (i = 0; i < 6; i++) gadd(f * H[i], 2600, (uint32_t)(3 + i), 30000); }
        g_noise = 3000; g_noise_f = 3000; g_noise_q = 16000; g_noise_am = 26000;
        break;
    }
    if (g_strike_amp) {                           /* chimes: struck at fixed places, decaying, wrapping around */
        gs_n = 12;
        for (i = 0; i < gs_n; i++) {
            uint32_t r = kt_hash(g_seed + (uint32_t)i * 77u), deg = r % 5u;
            static const uint8_t PENT[5] = {0, 2, 4, 7, 9};
            int st = PENT[deg] + 12 * (int)((r >> 8) & 1u) + (P->kind == KIND_CRYSTAL ? 12 : 12);
            uint32_t c = cycles_for(src_note + st);
            static const uint32_t BR[4] = {1000, 2000, 3011, 4166};
            gs[i].pos = (uint32_t)i * (SRC_LEN / 12u) + ((r >> 12) & 2047u);
            for (k = 0; k < 4; k++) {
                gs[i].inc[k] = ((c * BR[k] + 500u) / 1000u) << 16;
                gs[i].amp[k] = (int32_t)(9000u >> k) * (P->kind == KIND_CRYSTAL ? 2 : 1);
                gs[i].sh[k] = (uint8_t)(7 - (k > 1));
            }
        }
    }
    {   /* prescale: the sum of all amplitudes fits in int16 */
        int32_t tot = g_noise + g_crackle + (g_fm ? 18000 : 0) + (g_strike_amp ? 30000 : 0);
        for (i = 0; i < gp_n; i++) tot += gp[i].amp;
        if (tot < 1) tot = 1;
        g_prescale = (int32_t)(((int64_t)30000 << 15) / tot);
        if (g_prescale > 4 * 32767) g_prescale = 4 * 32767;
    }
    /* noise filter pre-roll over the loop's last 4096 samples: the loop closes without a seam */
    for (h = SRC_LEN - 4096u; h < SRC_LEN; h++) {
        int32_t x = ((int32_t)(kt_hash(h ^ g_seed) >> 16) - 32768) >> 1;
        gn_low += (g_noise_f * gn_band) >> 15;
        gn_band += (g_noise_f * (x - gn_low - ((g_noise_q * gn_band) >> 15))) >> 15;
        gn_band = clampi(gn_band, -60000, 60000);
    }
}
static int32_t gen_sample(uint32_t p)
{
    int32_t s = 0, i, k;
    for (i = 0; i < gp_n; i++) {
        partial_t *q = &gp[i];
        int32_t am = 32768 - q->am_depth + ((q->am_depth * ((kt_sine(q->am_inc * p) + 32768) >> 1)) >> 15);
        s += (int32_t)(((int64_t)kt_sine(q->inc * p) * ((q->amp * am) >> 15)) >> 15);
    }
    if (g_noise) {
        int32_t x = ((int32_t)(kt_hash(p ^ g_seed) >> 16) - 32768) >> 1, am;
        gn_low += (g_noise_f * gn_band) >> 15;
        gn_band += (g_noise_f * (x - gn_low - ((g_noise_q * gn_band) >> 15))) >> 15;
        gn_band = clampi(gn_band, -60000, 60000);
        am = 32768 - g_noise_am + ((g_noise_am * ((kt_sine(g_noise_am_inc * p) + 32768) >> 1)) >> 15);
        if (g_air) am = (am * (24000 + (kt_sine((5u << 16) * p + 0x40000000u) >> 2))) >> 15;
        s += (((gn_band * g_noise) >> 15) * am) >> 15;
    }
    if (g_crackle) {                              /* sparse cracks: random-access, one per block maybe */
        uint32_t b = p >> 9, hsh = kt_hash(b * 2654435761u ^ g_seed), st = (hsh >> 8) & 511u, t = p & 511u;
        if ((hsh & 255u) < 70u && t >= st) {
            uint32_t dt = t - st;
            if (dt < 255u) {
                int32_t x = ((int32_t)(kt_hash(p * 7u) >> 16) - 32768);
                s += (((x * KT_EXPDEC[dt]) >> 15) * g_crackle) >> 15;
            }
        }
    }
    if (g_fm) {                                   /* two whale voices: slow pitch glides, integer LFO cycles */
        for (k = 0; k < 2; k++) {
            int32_t lfo = kt_sine(((uint32_t)(1 + k) << 16) * p + (uint32_t)k * 0x5000000u);
            uint32_t inc = g_fm_inc[k] + (uint32_t)(((int64_t)(int32_t)(g_fm_inc[k] >> 4) * lfo) >> 15);
            int32_t sw = 32768 - 22000 + ((22000 * ((kt_sine((uint32_t)(3 - k) << 16 * 1 * 1 ? ((uint32_t)(3 - k) << 16) * p : 0) + 32768) >> 1)) >> 15);
            g_fm_ph[k] += inc;
            s += (((kt_sine(g_fm_ph[k]) + (kt_sine(g_fm_ph[k] * 2u) >> 2)) * 9000 >> 15) * sw) >> 15;
        }
    }
    if (g_strike_amp) {
        for (i = 0; i < gs_n; i++) {
            uint32_t dt = (p - gs[i].pos) & (SRC_LEN - 1u);
            if (dt < (255u << 7)) {
                for (k = 0; k < 4; k++) {
                    uint32_t e = dt >> gs[i].sh[k];
                    if (e < 255u) s += (((kt_sine(gs[i].inc[k] * dt) * gs[i].amp[k]) >> 15) * KT_EXPDEC[e]) >> 15;
                }
            }
        }
    }
    s = (int32_t)(((int64_t)s * g_prescale) >> 15);
    if (g_clip) {                                 /* a soft clip: warmth */
        int32_t x = clampi(s, -32767, 32767), x3 = (int32_t)(((int64_t)x * x >> 15) * x >> 15);
        s = x * 3 / 2 - x3 / 2;
    }
    return clamp16(s);
}

static int32_t eff(int p);
/* ================================================================== THE PICTURE (native 03)
 * One renderer for the FM-1 and the browser's Device view: a lit, z-buffered, Gouraud-shaded 3D pigeon built from
 * ellipsoid parts, drawn strip by strip at the panel's full 240 x 240. Every morph below is fed by NMAP, a fixed-point
 * mirror of the browser's VMAP table, from the same measured telemetry. Nothing is driven by a free-running clock
 * except the slow idle turn, whose speed is the MOTION knob. */
#define PCX 60
#define PCY 70
#define PR 25
#define SCX 138                                 /* screen centre of the bird */
#define SCY 116
#define FOCAL 272                               /* px per unit at the model's centre (camera 4.2 units away) */
#define CAMD 17203                              /* 4.2 in Q12 */

#define HZ 140                                  /* the horizon */
#define LEDGE 184                               /* where the river meets the ledge the bird stands on */
static uint8_t sky_h[240];                      /* skyline height above the horizon, per column */
typedef struct { int16_t x, y; uint16_t age, life; uint8_t amp, hue; } node_t;
#define NNODE 16
static node_t NODE[NNODE];
static uint32_t node_next;
static uint8_t top_vc[4][3];                    /* the four loudest voices: colour, weight (0..256), index */
static int32_t top_vw[4];
static int8_t top_vi[4];
/* ---- NMAP: telemetry -> smoothed morph signals, Q15 unless noted (the browser's AUDIT table lists the same rows) */
typedef struct {
    int32_t energy, attack, dry, density, trigger, rev, shim, tone, kick, snare, hat, lfo, wform, wflut;
    uint32_t last_ev, scan;
    int16_t wave[64];                           /* the oscillation, triggered on a rising zero crossing */
    int32_t wpk;                                /* its peak, for a normalised shape */
    int32_t say, sb[3];                         /* the singer: output envelope, the three formant bands' own levels */
    int32_t syl, syl_hi;                        /* the syllable being sung (-1 silent), the furthest reached */
} nmap_t;
static nmap_t NM;
/* ---- the singer's picture: a ribbon traced through vowel space (F2 -> angle, F1 -> reach) and chip sparks */
typedef struct { int16_t x0, y0, vx, vy; uint16_t age, life; uint8_t c[3], e; } vtrail_t;   /* released at x0,y0; vx,vy px/s */
#define NVT 96
typedef struct { int16_t x, y; uint16_t age; uint8_t c[3]; } ripple_t;   /* one per syllable: a ring travelling out from the beak */
static ripple_t RIP[4];
static uint32_t rip_next;
static vtrail_t VT[NVT];
static uint32_t vt_next;
typedef struct { int32_t x, y, vx, vy; uint16_t age, life; uint8_t c[3], sz; } spark_t;
#define NSPK 24
static spark_t SPK[NSPK];
static uint32_t spk_next;
static int32_t beak_x, beak_y, beak_dir;        /* the beak tip on screen (px) and which way it points (+1 right, -1 left) */
static uint32_t say_at;                         /* when to sing at power-on (ms), 0 = done */
static void vowel_rgb(int32_t f1, int32_t f2, uint8_t *c)   /* open vowels warm, back vowels violet, front ones cyan, nasals rose */
{
    static const uint8_t VIO[3] = {150, 120, 255}, CYA[3] = {90, 215, 255}, GOLD[3] = {255, 190, 90}, ROSE[3] = {255, 120, 175};
    uint8_t b[3];
    uint32_t t1 = (uint32_t)clampi((f1 - 330) * 256 / 520, 0, 256), t2 = (uint32_t)clampi((f2 - 980) * 256 / 1100, 0, 256);
    lerp3(VIO, CYA, t2, b);
    lerp3(ROSE, b, (uint32_t)clampi((f1 - 280) * 256 / 140, 0, 256), b);
    lerp3(b, GOLD, t1 * 5u / 8u, c);
}
typedef struct { int32_t x, y, z, r, s; uint16_t age, life; uint8_t hue; } impact_t;   /* object space Q12 */
static impact_t IMP[8];
static uint32_t imp_next;
static uint8_t vis_layers = 31;                 /* VOICE GRAINS MOD FX RHYTHM: the same five toggles as the browser */
static int32_t fol(int32_t y, int32_t x, uint32_t dt, uint32_t atk_ms, uint32_t rel_ms)   /* one-pole, dt-correct */
{
    uint32_t tau = x > y ? atk_ms : rel_ms, k = (dt << 12) / (tau + dt);   /* Q12 */
    return y + (int32_t)(((int64_t)(x - y) * (int32_t)k) >> 12);
}
static void nmap_frame(uint32_t dt)
{
    int32_t sum = 0, atk = 0, i;
    uint32_t sc = ao_scope_head, st, k;
    for (i = 0; i < NSEED; i++) {
        int32_t a = ao_amp[i];
        if (a < 0) a = 0;
        sum += a;
        if (sd[i].gate > a + 64) atk += a + 6000;
    }
    NM.energy = fol(NM.energy, clampi(sum, 0, 52000) * 32767 / 52000, dt, 40, 450);
    NM.attack = fol(NM.attack, clampi(atk, 0, 26000) * 32767 / 26000, dt, 10, 180);
    NM.dry = fol(NM.dry, clampi(ao_dry, 0, 14000) * 32767 / 14000, dt, 20, 250);
    NM.density = fol(NM.density, clampi((int32_t)ao_grain_count * 32767 / 28, 0, 32767), dt, 50, 350);
    {
        uint32_t n = ev_head - NM.last_ev;
        NM.last_ev = ev_head;
        NM.trigger = fol(NM.trigger, clampi((int32_t)(n * 1000u / (dt ? dt : 16u)) * 32767 / 60, 0, 32767), dt, 10, 200);
    }
    NM.rev = fol(NM.rev, clampi(ao_rev, 0, 9000) * 32767 / 9000, dt, 50, 900);
    NM.shim = fol(NM.shim, S.shimmer ? 32767 : 0, dt, 250, 600);
    NM.tone = fol(NM.tone, ap_tone, dt, 200, 200);
    NM.kick = fol(NM.kick, ap_perc ? clampi(a_kick_pk * 32767 / 10500, 0, 32767) : 0, dt, 5, 60);
    NM.snare = fol(NM.snare, ap_perc ? clampi(a_snare_pk * 32767 / 5700, 0, 32767) : 0, dt, 5, 80);
    NM.hat = fol(NM.hat, ap_perc ? clampi(a_hat_pk * 32767 / 2200, 0, 32767) : 0, dt, 3, 50);
    NM.lfo = fol(NM.lfo, (int32_t)(((int64_t)ao_lfo * clampi((int32_t)ap_lfo_depth * 32767 / 12700, 0, 32767)) >> 15), dt, 20, 20);
    NM.wform = fol(NM.wform, (eff(P_SIZE) - S.p[P_SIZE]) * 32767 / 30, dt, 300, 900);
    NM.wflut = fol(NM.wflut, (eff(P_SCAT) - S.p[P_SCAT]) * 32767 / 30, dt, 300, 900);
    NM.scan = center_q16 >> 16;
    st = sc - 140u;                             /* the newest 140 samples: find a rising zero crossing, take 64 */
    for (k = 0; k < 70u; k++) { int16_t a = kt_scope[(st + k) & 255u], b = kt_scope[(st + k + 1u) & 255u]; if (a < 0 && b >= 0) break; }
    st += k < 70u ? k : 0u;
    {
        int32_t pk = 1;
        for (k = 0; k < 64u; k++) { int32_t v; NM.wave[k] = (int16_t)((NM.wave[k] + kt_scope[(st + k) & 255u]) >> 1); v = NM.wave[k] < 0 ? -NM.wave[k] : NM.wave[k]; if (v > pk) pk = v; }
        NM.wpk = fol(NM.wpk, pk, dt, 30, 400);
    }
    {   /* the singer (measured inside kt_audio): envelope, formant bands, syllable */
        int32_t syl = ao_vx_syl, f1 = ao_vx_f1, f2 = ao_vx_f2;
        NM.say = fol(NM.say, clampi(ao_vx_env * 32767 / 11000, 0, 32767), dt, 6, 140);
        for (k = 0; k < 3u; k++) NM.sb[k] = fol(NM.sb[k], clampi(ao_vx_band[k] * 32767 / 5000, 0, 32767), dt, 6, 180);
        if (syl >= 0 && syl != NM.syl) {        /* a new syllable: a burst of chip sparks from the beak */
            int j;
            uint8_t c[3];
            vowel_rgb(f1 + 220, f2, c);         /* the vowel the syllable is heading for */
            for (j = 0; j < 8; j++) {
                spark_t *q = &SPK[spk_next++ % NSPK];
                uint32_t h = kt_hash(ao_vx_count * 131u + (uint32_t)syl * 17u + (uint32_t)j), a = (uint32_t)(j * 0x20000000) + (h & 0x0FFFFFFFu);
                int32_t sp = 70 + (int32_t)(h >> 25) + (NM.say >> 9);
                q->x = beak_x << 8; q->y = beak_y << 8;
                q->vx = (kt_sine(a + 0x40000000u) * sp) >> 11; q->vy = (kt_sine(a) * sp) >> 11;
                if (q->vx * beak_dir < 0) q->vx = -q->vx / 2;
                q->age = 0; q->life = (uint16_t)(700 + (h >> 22 & 255u) * 2u);
                q->c[0] = c[0]; q->c[1] = c[1]; q->c[2] = c[2]; q->sz = (uint8_t)(3 + (syl == 2));
            }
            if (syl > NM.syl_hi) NM.syl_hi = syl;
            {
                ripple_t *r = &RIP[rip_next++ & 3u];
                r->x = (int16_t)beak_x; r->y = (int16_t)beak_y; r->age = 0; r->c[0] = c[0]; r->c[1] = c[1]; r->c[2] = c[2];
            }
        }
        if (syl < 0 && NM.syl >= 0) NM.syl_hi = 3;
        if (syl == 0 && NM.syl != 0) NM.syl_hi = 0;
        NM.syl = syl;
        if (syl >= 0 && NM.say > 500) {         /* the plume: three beads per frame, a fan whose aim is F2 and whose width is F1 */
            int32_t deg = 150 - clampi((f2 - 850) * 125 / 1150, 0, 125);    /* front vowels forward, back vowels up and behind */
            int32_t spread = 7 + clampi((f1 - 280) * 26 / 600, 0, 26);       /* open vowels fan wide, nasals stay narrow */
            int32_t sp = 34 + clampi((f1 - 280) * 40 / 600, 0, 40) + (NM.say >> 11), lane;
            uint8_t c[3];
            vowel_rgb(f1, f2, c);
            for (lane = -1; lane <= 1; lane++) {
                vtrail_t *v = &VT[vt_next++ % NVT];
                uint32_t ph = (uint32_t)(deg + lane * spread) * 11930465u;   /* degrees -> 2^32 per turn (unsigned: no overflow) */
                int32_t s2 = sp - (lane ? 6 : 0);
                v->vx = (int16_t)(((kt_sine(ph + 0x40000000u) * s2) >> 15) * beak_dir);
                v->vy = (int16_t)(-((kt_sine(ph) * s2) >> 15));
                v->x0 = (int16_t)beak_x; v->y0 = (int16_t)beak_y;
                v->c[0] = c[0]; v->c[1] = c[1]; v->c[2] = c[2];
                if (lane) lerp3(c, (const uint8_t[3]){255, 255, 255}, 50, v->c);
                v->e = (uint8_t)clampi((NM.say >> 7) - (lane ? 40 : 0), 40, 255);
                v->age = 0; v->life = (uint16_t)(2000 + (lane + 1) * 150);
            }
        }
        for (k = 0; k < 4u; k++) if (RIP[k].age < 900u) RIP[k].age = (uint16_t)(RIP[k].age + dt);
        for (k = 0; k < NVT; k++) if (VT[k].age < VT[k].life) VT[k].age = (uint16_t)(VT[k].age + dt);
        for (k = 0; k < NSPK; k++) if (SPK[k].age < SPK[k].life) {
            spark_t *q = &SPK[k];
            q->age = (uint16_t)(q->age + dt); q->x += q->vx * (int32_t)dt / 16; q->y += q->vy * (int32_t)dt / 16; q->vy += 2 * (int32_t)dt;
        }
    }
    for (k = 0; k < 8u; k++) if (IMP[k].age < IMP[k].life) IMP[k].age = (uint16_t)(IMP[k].age + dt);
    for (k = 0; k < NNODE; k++) if (NODE[k].age < NODE[k].life) NODE[k].age = (uint16_t)(NODE[k].age + dt);
}
static void node_from(const gev_t *e);
static void impact_from(const gev_t *e)          /* a grain event becomes a bump where it sat (VMAP: impacts[8]) */
{
    node_from(e);
    impact_t *im = &IMP[imp_next++ & 7u];
    im->x = -4096 + (int32_t)e->pos8 * 7168 / 255;
    im->y = -205 + (e->iv > 0 ? 1147 : e->iv < 0 ? -819 : 0) + ((int32_t)e->lfo8 - 128) * 5;
    im->z = ((int32_t)e->pan - 128) * 1720 / 128;
    im->r = 246 + clampi(e->len8, 0, 120) * 655 / 120;
    im->s = clampi(e->amp * 32767 / 160, 0, 32767);
    im->life = (uint16_t)(250 + clampi(e->len8, 0, 140) * 900 / 140);
    im->age = 0;
    im->hue = (uint8_t)(e->seed * 3u % 16u);
}

/* ---- the model: parts are ellipsoids (centre, radii, a pitch about z, a material, a mesh size) */
typedef struct { int32_t cx, cy, cz, rx, ry, rz, pitch; uint8_t mat, lon, lat, rip; } part3_t;
#define MAXPART 20
#define MAXV 980
#define MAXT 1700
static part3_t PT[MAXPART];
static int npart;
static int16_t vsx[MAXV], vsy[MAXV], vsz[MAXV];  /* screen x, y (Q4), depth (larger = nearer) */
static uint8_t vr[MAXV], vg[MAXV], vb[MAXV];
static uint16_t tv[MAXT][3];
static int16_t ty0[MAXT], ty1[MAXT];
static int nvert, ntri;
static int16_t kt_zb[240 * 60] KT_POOL;          /* the z-buffer of one strip */
static uint32_t yaw_ph;
static int32_t eye_x, eye_y, eye_vis;
static int32_t bbx0, bby0, bbx1, bby1;          /* the bird's screen box (for glints) */

static void addp(int32_t cx, int32_t cy, int32_t cz, int32_t rx, int32_t ry, int32_t rz, int32_t pitch, int mat, int lon, int lat, int rip)
{
    part3_t *p;
    if (npart >= MAXPART) return;
    p = &PT[npart++];
    p->cx = cx; p->cy = cy; p->cz = cz; p->rx = rx; p->ry = ry; p->rz = rz; p->pitch = pitch;
    p->mat = (uint8_t)mat; p->lon = (uint8_t)lon; p->lat = (uint8_t)lat; p->rip = (uint8_t)rip;
}
#define Q(x) ((int32_t)((x) * 4096))
static void model_build(void)                   /* the species' silhouette + the morphs (all Q12 object units) */
{
    int bird = cur_planet, i;
    int32_t v = S.p[P_SIZE] * 4096 / 127, fl = S.p[P_DENS] * 4096 / 127, ft = S.p[P_SCAT] * 4096 / 127;
    int32_t breath = (int32_t)(((int64_t)NM.energy * 205 + (int64_t)NM.attack * 143) >> 15);   /* up to ~.085 */
    int32_t po = bird == 5 ? 5325 : 4096, bo = bird == 2 ? 4833 : 4096;
    int32_t nk = (vis_layers & 4) ? (int32_t)(((int64_t)NM.wform * 205) >> 15) : 0;
    int32_t lift = (vis_layers & 4) ? ((kt_sine(NM.scan << 16) * 287) >> 15) + (int32_t)(((int64_t)NM.wflut * 205) >> 15) : 0;
    int32_t fan, sway = (vis_layers & 4) ? (int32_t)(((int64_t)NM.lfo * 737) >> 15) : 0;
    npart = 0;
    if (!(vis_layers & 1)) breath = 0;
    addp(Q(-.19), Q(-.08), 0, ((Q(.76) + v * 14 / 100 + breath) * bo) >> 12, ((Q(.49) + v * 7 / 100 + breath * 4 / 5) * po) >> 12, Q(.46) + breath / 2, 0, 1, 14, 9, 1);
    {   /* the breast; a pigeon's crop swells as it coos (the singer's measured envelope, VOICE) */
        int32_t crop = (vis_layers & 1) ? (int32_t)(((int64_t)NM.say * Q(.07)) >> 15) : 0;
        addp(Q(.38) + crop / 3, Q(.24) + nk, 0, (Q(.26) + crop) * po >> 12, (Q(.44) + crop / 2) * po >> 12, Q(.28) + crop, Q(-.25), 2, 10, 7, 1);
    }
    addp(Q(.64), Q(.54) + nk * 7 / 5, 0, bird == 2 ? Q(.28) : Q(.23), Q(.22), Q(.23), 0, 2, 10, 7, 0);
    {   /* beak: it opens with the singer's envelope (two mandibles while singing) */
        int32_t gape = (vis_layers & 1) ? (int32_t)(((int64_t)NM.say * Q(.62)) >> 15) : 0;
        if (gape > Q(.03)) {
            addp(Q(.93), Q(.485) + nk * 7 / 5, 0, Q(.17), Q(.04), Q(.08), Q(.10) + gape / 2, 6, 6, 4, 0);
            addp(Q(.91), Q(.445) + nk * 7 / 5, 0, Q(.15), Q(.033), Q(.07), Q(.06) - gape / 2, 6, 6, 3, 0);
        } else addp(Q(.93), Q(.47) + nk * 7 / 5, 0, Q(.17), Q(.06), Q(.08), Q(.10), 6, 6, 4, 0);
    }
    for (i = 0; i < 2; i++) {                                                                   /* wings: lift by scan */
        int32_t z = i ? Q(.36) : Q(-.36);
        addp(Q(-.27), Q(-.02), z, Q(.52) + fl * 18 / 100, Q(.26) + ft / 10 + (int32_t)(((int64_t)NM.density * 123) >> 15), Q(.13), Q(.38) + lift, 3, 12, 6, 1);
    }
    fan = (bird == 1 ? Q(1.8) : bird == 4 ? Q(.65) : Q(1.0)) + fl * 22 / 100 + (int32_t)(((int64_t)NM.snare * Q(.6)) >> 15) + (int32_t)(((int64_t)NM.density * Q(.08)) >> 15);
    for (i = 0; i < 7; i++) {                                                                   /* the tail fan: snare flicks it */
        int32_t a = (int32_t)(((int64_t)(i - 3) * Q(.22) * fan) >> 12) + sway;
        uint32_t ang = (uint32_t)(a * 166886);                                                  /* rad Q12 -> 2^32 per turn: 2^32 / (2 pi 4096) = 166886 */
        int32_t ca = kt_sine(ang + 0x40000000u), sa = kt_sine(ang);
        addp(Q(-1.05) - ((Q(.11) * ca) >> 15) - ((Q(.32) * ca) >> 15), Q(.04) + ((Q(.62) * sa) >> 15), Q(.03) + (i - 3) * 150, Q(.43), Q(.09), Q(.10), a, 4, 6, 3, 1);
    }
    for (i = 0; i < 2; i++) {                                                                   /* legs and toes, down to the ledge */
        int32_t z = i ? Q(.20) : Q(-.20);
        addp(Q(-.10), Q(-.70), z, Q(.045), Q(.26), Q(.045), Q(.10), 6, 5, 3, 0);
        addp(Q(.0), Q(-.95), z, Q(.17), Q(.035), Q(.06), 0, 6, 6, 3, 0);
    }
    if (bird == 3) addp(Q(.46), Q(.51) + nk, Q(.02), Q(.29) + (int32_t)(((int64_t)NM.attack * 205) >> 15), Q(.35), Q(.29), 0, 5, 10, 7, 0);   /* jacobin ruff */
    if (bird == 6) addp(Q(.30), Q(.08), Q(.015), Q(.42), Q(.17), Q(.38), 0, 5, 10, 5, 0);                                                    /* nicobar collar */
}
static void mat_rgb(int mat, int32_t u, uint8_t *c)   /* a material's colour from the species palette; u: along the body 0..256 */
{
    const kt_planet_t *P = &KT_PLANETS[cur_planet];
    switch (mat) {
    case 2: lerp3(P->pl1, P->pl2, 120, c); break;                          /* neck, head */
    case 3: lerp3(P->gl1, P->pl1, 150, c); break;                          /* wings: the species' iridescent tone */
    case 4: lerp3(P->pl0, P->gl0, 90, c); break;                           /* tail */
    case 5: lerp3(P->gl2, P->gl1, 110, c); break;                          /* ruff, collar */
    case 6: c[0] = 242; c[1] = 158; c[2] = 77; break;                      /* beak */
    default: lerp3(P->pl0, P->pl1, (uint32_t)clampi(110 + u / 2, 0, 256), c); break;
    }
}
static void mesh_frame(uint32_t dt)              /* transform, deform, light: once per frame, before the strips */
{
    const kt_planet_t *P = &KT_PLANETS[cur_planet];
    int pi_, i, j;
    uint32_t yaw;
    int32_t cyw, syw, cp = 31170, sp = 10126;   /* camera pitch ~ 0.32 rad */
    int32_t lx = -13000, ly = 21000, lz = 19000;   /* light, Q15-ish, normalised below */
    int32_t spk = 8 + (int32_t)(((int64_t)NM.tone * 40) >> 15);
    uint8_t vc[4][3];
    int32_t vw[4] = {0, 0, 0, 0}, kick_sq = 32767 - NM.kick / 12;   /* y scale toward the feet, Q15 */
    model_build();
    yaw_ph += dt * (uint32_t)(5000 + S.p[P_DRIFT] * 160);                 /* MOTION: the slow turn of the sculpture */
    yaw = (uint32_t)(kt_sine(yaw_ph) >> 2) * 32768u + 0x10000000u + (uint32_t)(((vis_layers & 4) ? NM.lfo : 0) * 4800);
    cyw = kt_sine(yaw + 0x40000000u); syw = kt_sine(yaw);
    if (S.lens == 1) { lx = 12000; ly = 15000; lz = -24000; }             /* NOCTURNE: lit from behind */
    {   /* what is sounding paints the feathers: the four loudest voices' colours (VMAP voiceCol) */
        int n = 0, k2;
        for (k2 = 0; k2 < NSEED && n < 4; k2++) {
            int best = -1;
            int32_t ba = 300;
            for (i = 0; i < NSEED; i++) {
                int used = 0, q;
                for (q = 0; q < n; q++) if (vw[q] == -1 - i) used = 1;
                if (!used && ao_amp[i] > ba) { ba = ao_amp[i]; best = i; }
            }
            if (best < 0) break;
            {
                uint32_t hh = (uint32_t)sm[best].deg * 256u / KT_SCALES[P->scale].len;
                if (hh < 128u) lerp3(P->gl0, P->gl1, hh * 2u, vc[n]); else lerp3(P->gl1, P->gl2, (hh - 128u) * 2u, vc[n]);
            }
            vw[n] = -1 - best;
            n++;
        }
        for (i = 0; i < 4; i++) { top_vi[i] = (int8_t)(vw[i] < 0 ? -1 - vw[i] : -1); vw[i] = vw[i] < 0 ? clampi(ao_amp[-1 - vw[i]] * 256 / 26000, 0, 256) : 0; }
        for (i = 0; i < 4; i++) { top_vw[i] = vw[i]; if (i < n) { top_vc[i][0] = vc[i][0]; top_vc[i][1] = vc[i][1]; top_vc[i][2] = vc[i][2]; } }
        if (!(vis_layers & 1)) vw[0] = vw[1] = vw[2] = vw[3] = 0;
    }
    nvert = ntri = 0;
    bbx0 = bby0 = 9999; bbx1 = bby1 = -9999;
    {   /* the eye on the side that faces us */
        int32_t ex = Q(.76), ey = PT[2].cy + Q(.07), ez = Q(.205), X, Y, Z, t, d, side;
        for (side = 0; side < 2; side++, ez = -ez) {
            X = (ex * cyw + ez * syw) >> 15; Z = (-ex * syw + ez * cyw) >> 15; Y = ey;
            t = (Y * cp - Z * sp) >> 15; Z = (Y * sp + Z * cp) >> 15; Y = t;
            if (Z > Q(.05)) break;
        }
        d = CAMD - Z;
        eye_vis = side < 2;
        eye_x = SCX + X * FOCAL / d; eye_y = SCY - Y * FOCAL / d;
    }
    {   /* the beak tip, where the song comes out */
        int32_t bx = Q(1.10), by = PT[3].cy, X, Y, Z, t, d;
        X = (bx * cyw) >> 15; Z = (-bx * syw) >> 15; Y = by;
        t = (Y * cp - Z * sp) >> 15; Z = (Y * sp + Z * cp) >> 15; Y = t;
        d = CAMD - Z;
        beak_x = SCX + X * FOCAL / d; beak_y = SCY - Y * FOCAL / d;
        beak_dir = beak_x >= SCX ? 1 : -1;
    }
    for (pi_ = 0; pi_ < npart; pi_++) {
        part3_t *p = &PT[pi_];
        int base = nvert, lon = p->lon, lat = p->lat;
        int32_t cpz = kt_sine((uint32_t)(p->pitch * 166886) + 0x40000000u), spz = kt_sine((uint32_t)(p->pitch * 166886));
        if (nvert + lon * (lat + 1) > MAXV || ntri + lon * lat * 2 > MAXT) break;
        for (i = 0; i <= lat; i++) {
            uint32_t phi = (uint32_t)((int32_t)(i * 2 - lat) * (int32_t)(0x40000000u / (uint32_t)lat) / 2);   /* -90..90 deg */
            int32_t cphi = kt_sine(phi + 0x40000000u), sphi = kt_sine(phi);
            if (i == 0) { cphi = 0; sphi = -32767; }
            if (i == lat) { cphi = 0; sphi = 32767; }
            for (j = 0; j < lon; j++) {
                uint32_t th = (uint32_t)j * (0xFFFFFFFFu / (uint32_t)lon);
                int32_t ct = kt_sine(th + 0x40000000u), stt = kt_sine(th);
                int32_t ux = (int32_t)(((int64_t)cphi * ct) >> 15), uy = sphi, uz = (int32_t)(((int64_t)cphi * stt) >> 15);   /* unit, Q15 */
                int32_t x = (ux * p->rx) >> 15, y = (uy * p->ry) >> 15, z = (uz * p->rz) >> 15;           /* Q12 */
                int32_t nx = ux * 4096 / (p->rx > 64 ? p->rx : 64), ny = uy * 4096 / (p->ry > 64 ? p->ry : 64), nz = uz * 4096 / (p->rz > 64 ? p->rz : 64), nl, t;
                int32_t X, Y, Z, NX, NY, NZ, d, sx, sy, diff, rim, spec, k2, cr, cg, cb, glow = 0, u;
                uint8_t base_c[3];
                nl = (int32_t)kt_isqrt((uint32_t)((nx >> 4) * (nx >> 4) + (ny >> 4) * (ny >> 4) + (nz >> 4) * (nz >> 4))) + 1;
                nx = (nx >> 4) * 32767 / nl; ny = (ny >> 4) * 32767 / nl; nz = (nz >> 4) * 32767 / nl;
                t = (x * cpz - y * spz) >> 15; y = (x * spz + y * cpz) >> 15; x = t;               /* the part's pitch */
                t = (nx * cpz - ny * spz) >> 15; ny = (nx * spz + ny * cpz) >> 15; nx = t;
                x += p->cx; y += p->cy; z += p->cz;
                u = clampi((x + Q(1.25)) * 256 / Q(2.3), 0, 256);
                /* --- morphs on the surface: the measured waveform, grain impacts, the kick */
                d = 0;
                if (p->rip && (vis_layers & 1)) {
                    int32_t w = NM.wave[clampi((x + Q(1.3)) * 63 / Q(2.6), 0, 63)];
                    d += (int32_t)(((int64_t)w * NM.dry) >> 15) * 225 >> 15;                         /* up to ~.055 */
                }
                if (vis_layers & 2) for (k2 = 0; k2 < 8; k2++) {
                    impact_t *im = &IMP[k2];
                    int32_t dx, dy, dz, d2, r2, live;
                    if (im->age >= im->life) continue;
                    dx = (x - im->x) >> 4; dy = (y - im->y) >> 4; dz = (z - im->z) >> 4;
                    d2 = dx * dx + dy * dy + dz * dz; r2 = (im->r >> 4) * (im->r >> 4) * 3;
                    if (d2 >= r2) continue;
                    live = 32767 - im->age * 32767 / im->life;
                    {
                        int32_t sl = (int32_t)(((int64_t)im->s * live) >> 15), fr = (r2 - d2) * 256 / r2;
                        d += ((sl * fr) >> 8) * 205 >> 15;                                                   /* a bulge, up to ~.05 */
                    }
                    {   /* a ring spreading from where it landed */
                        int32_t rr = (int32_t)kt_isqrt((uint32_t)d2), front = (im->r >> 4) * 2 * im->age / im->life, e = rr - front;
                        if (e < 0) e = -e;
                        if (e < 40) glow += (40 - e) * (im->s >> 9) * live >> 15;
                    }
                }
                x += (nx * d) >> 15; y += (ny * d) >> 15; z += (nz * d) >> 15;
                if ((vis_layers & 16) && NM.kick > 0) {   /* the kick: the bird settles onto its feet and widens */
                    y = (int32_t)(((int64_t)(y + Q(.97)) * kick_sq) >> 15) - Q(.97);
                    x += (int32_t)(((int64_t)x * NM.kick) >> 19); z += (int32_t)(((int64_t)z * NM.kick) >> 19);
                }
                /* --- world: yaw, then the camera's pitch */
                X = (x * cyw + z * syw) >> 15; Z = (-x * syw + z * cyw) >> 15; Y = y;
                t = (Y * cp - Z * sp) >> 15; Z = (Y * sp + Z * cp) >> 15; Y = t;
                NX = (nx * cyw + nz * syw) >> 15; NZ = (-nx * syw + nz * cyw) >> 15; NY = ny;
                t = (NY * cp - NZ * sp) >> 15; NZ = (NY * sp + NZ * cp) >> 15; NY = t;
                d = CAMD - Z; if (d < 1200) d = 1200;
                sx = (SCX << 4) + X * (FOCAL * 16) / d;    /* |X| < 2^13: 32-bit is enough */
                sy = (SCY << 4) - Y * (FOCAL * 16) / d;
                vsx[nvert] = (int16_t)sx; vsy[nvert] = (int16_t)sy; vsz[nvert] = (int16_t)(Z >> 4);
                if ((sx >> 4) < bbx0) bbx0 = sx >> 4;
                if ((sx >> 4) > bbx1) bbx1 = sx >> 4;
                if ((sy >> 4) < bby0) bby0 = sy >> 4;
                if ((sy >> 4) > bby1) bby1 = sy >> 4;
                /* --- light: diffuse, fresnel rim, a filter-sharpened highlight */
                diff = (int32_t)(((int64_t)NX * lx + (int64_t)NY * ly + (int64_t)NZ * lz) >> 15) * 32767 / 31000;
                if (diff < 0) diff = 0;
                rim = 32767 - (NZ < 0 ? -NZ : NZ); rim = (int32_t)((int64_t)rim * rim >> 15) * rim >> 15;
                spec = clampi((int32_t)(((int64_t)NX * -6500 + (int64_t)NY * 13000 + (int64_t)NZ * 28800) >> 15), 0, 32767);
                for (k2 = 0; k2 < 5 && spec > 0; k2++) { spec = (int32_t)((int64_t)spec * spec >> 15); if (k2 * 8 + 8 >= spk) break; }
                mat_rgb(p->mat, u, base_c);
                if (cur_planet == 6 && (p->mat == 2 || p->mat == 3 || p->mat == 5)) {   /* nicobar: green-gold sheen */
                    uint8_t g2[3] = {46, 237, 181};
                    lerp3(base_c, g2, (uint32_t)((kt_sine((uint32_t)(y * 17 + x * 9) << 12) + 32768) >> 9) * (uint32_t)S.p[P_TONE] / 127u, base_c);
                }
                if (p->mat <= 5) {                                                     /* the sounding voices' gradient */
                    int32_t wsum = 0, ar = 0, ag = 0, ab = 0, q;
                    for (q = 0; q < 4; q++) {
                        int32_t du = u - (q * 64 + 32), w = du < 0 ? -du : du;
                        w = vw[q] * clampi(96 - w, 0, 96) / 96;
                        ar += vc[q][0] * w; ag += vc[q][1] * w; ab += vc[q][2] * w; wsum += w;
                    }
                    if (wsum > 8) {
                        uint8_t mixc[3] = {(uint8_t)(ar / wsum), (uint8_t)(ag / wsum), (uint8_t)(ab / wsum)};
                        lerp3(base_c, mixc, (uint32_t)clampi(wsum / 2, 0, 140), base_c);
                    }
                }
                {
                    int32_t amb = S.lens == 1 ? 9000 : 15500, lit = amb + (int32_t)((int64_t)diff * 21000 >> 15);
                    int32_t warm = 32767 - NM.tone;                                       /* filter closed: warmer */
                    cr = base_c[0] * lit >> 15; cg = base_c[1] * lit >> 15; cb = base_c[2] * lit >> 15;
                    cr += cr * warm >> 18; cb -= cb * warm >> 18;
                    {   /* rim: the species' light colour; brighter with the reverb tail and on a note's attack */
                        int32_t rk = (int32_t)((int64_t)rim * (9000 + (int32_t)(((int64_t)NM.rev * 9000) >> 15) * ((vis_layers >> 3) & 1) + (int32_t)(((int64_t)NM.attack * 22000) >> 15) * (vis_layers & 1) + (S.lens == 1 ? 14000 : 0)) >> 15);
                        cr += P->gl2[0] * rk >> 15; cg += P->gl2[1] * rk >> 15; cb += P->gl2[2] * rk >> 15;
                    }
                    if (NM.shim > 300 && (vis_layers & 8)) {                                /* shimmer: thin-film colours */
                        int32_t ph = (NZ + y) * 3, fk = (int32_t)(((int64_t)NM.shim * (8000 + rim / 3)) >> 15);
                        cr += ((kt_sine((uint32_t)ph << 16) + 32768) >> 8) * fk >> 15;
                        cg += ((kt_sine(((uint32_t)ph << 16) + 0x55555555u) + 32768) >> 8) * fk >> 15;
                        cb += ((kt_sine(((uint32_t)ph << 16) + 0xAAAAAAAAu) + 32768) >> 8) * fk >> 15;
                    }
                    k2 = (int32_t)((int64_t)spec * (60 + (NM.tone >> 9)) >> 15);
                    cr += k2; cg += k2; cb += k2;
                    if (glow) { cr += P->gl2[0] * glow >> 8; cg += P->gl2[1] * glow >> 8; cb += P->gl2[2] * glow >> 8; }
                }
                vr[nvert] = (uint8_t)clampi(cr, 0, 255); vg[nvert] = (uint8_t)clampi(cg, 0, 255); vb[nvert] = (uint8_t)clampi(cb, 0, 255);
                nvert++;
            }
        }
        for (i = 0; i < lat; i++)
            for (j = 0; j < lon; j++) {
                int a = base + i * lon + j, b = base + i * lon + (j + 1) % lon, c2 = a + lon, d2 = b + lon, q;
                int quad[2][3] = {{a, c2, b}, {b, c2, d2}};
                for (q = 0; q < 2; q++) {
                    int A = quad[q][0], B = quad[q][1], C = quad[q][2];
                    int32_t cross = (vsx[B] - vsx[A]) * (vsy[C] - vsy[A]) - (vsy[B] - vsy[A]) * (vsx[C] - vsx[A]);
                    if (cross >= 0) continue;                                            /* facing away */
                    tv[ntri][0] = (uint16_t)A; tv[ntri][1] = (uint16_t)B; tv[ntri][2] = (uint16_t)C;
                    ty0[ntri] = (int16_t)((vsy[A] < vsy[B] ? (vsy[A] < vsy[C] ? vsy[A] : vsy[C]) : (vsy[B] < vsy[C] ? vsy[B] : vsy[C])) >> 4);
                    ty1[ntri] = (int16_t)(((vsy[A] > vsy[B] ? (vsy[A] > vsy[C] ? vsy[A] : vsy[C]) : (vsy[B] > vsy[C] ? vsy[B] : vsy[C])) >> 4) + 1);
                    ntri++;
                }
            }
    }
}

/* ---- the world around the bird (motifs from Matias's own ENSI figures, redrawn procedurally, no text):
 * a river city at the horizon with an arched bridge, the river's wave crests (the measured waveform), a ledge,
 * a constellation network that grain events build, ribbon streamers for the sounding voices. */
static void visual_setup(int pl)                 /* per species: a different skyline, same river */
{
    uint32_t x = 0, h = g_seed ^ 0xC17Eu * (uint32_t)(pl + 1);
    while (x < 150u) {
        uint32_t w, ht, k;
        h = kt_hash(h + x);
        w = 4u + (h & 7u) + ((h >> 3) & 3u); ht = 3u + ((h >> 6) % 17u) + (x > 40u && x < 110u ? 4u : 0u);
        for (k = 0; k < w && x < 150u; k++, x++) sky_h[x] = (uint8_t)ht;
        if (((h >> 12) & 7u) == 0u && x >= 2u && x < 148u) { sky_h[x - 1] = (uint8_t)(ht + 7u); sky_h[x - 2] = (uint8_t)(ht + 3u); }   /* a spire */
    }
    for (; x < 240u; x++) sky_h[x] = (uint8_t)(x < 236u ? 0u : 4u);    /* the bridge is drawn analytically */
}
static int bridge_at(int32_t x, int32_t up)      /* the arched bridge: 1 deck or rail, 2 masonry, 0 none (up: px above the horizon) */
{
    int32_t a, open_;
    if (x < 152 || x > 236 || up < 0) return 0;
    if (up >= 7 && up <= 9) return 1;            /* the deck */
    if (up == 10 || up == 11) return ((x - 152) % 6 == 0) ? 1 : 0;   /* the rail's posts */
    if (up > 11) return 0;
    a = (x - 152) % 21;
    if (a < 2) return 2;                         /* a pier */
    open_ = 1 + ((kt_sine((uint32_t)a * 102261126u) * 5) >> 15);    /* the arch's opening: sin(pi a / 21) */
    return up >= open_ ? 2 : 0;
}
static void node_from(const gev_t *e)            /* a grain event becomes a star in the network (GRAINS) */
{
    node_t *n = &NODE[node_next++ % NNODE];
    n->x = (int16_t)(18 + (int32_t)e->pan * 204 / 255);
    n->y = (int16_t)(16 + (255 - (int32_t)e->pos8) * 92 / 255 - e->iv * 2);
    n->age = 0; n->life = (uint16_t)(1600 + clampi(e->len8, 0, 160) * 14);
    n->amp = e->amp; n->hue = (uint8_t)(e->seed * 3u % 16u);
}

static void glut_build(int pl)
{
    const kt_planet_t *P = &KT_PLANETS[pl];
    const uint8_t *a = P->gl0, *b = P->gl1, *cc = P->gl2;
    uint8_t c[3], tmp[3];
    uint32_t h, j;
    if (S.pal == 1) { a = P->gl2; cc = P->gl0; }
    for (h = 0; h < 16u; h++) {
        if (h < 8u) lerp3(a, b, h * 32u, c); else lerp3(b, cc, (h - 8u) * 32u, c);
        if (S.pal == 2) { tmp[0] = c[0]; c[0] = c[2]; c[2] = c[1]; c[1] = tmp[0]; }
        if (S.pal == 3) { uint32_t l = (c[0] * 3u + c[1] * 5u + c[2] * 2u) / 10u; c[0] = c[1] = c[2] = (uint8_t)l; }
        for (j = 0; j < 32u; j++) {
            uint32_t t = j * j / 4u + j * 2u;   /* gentle gamma: 0 .. 310 */
            if (t > 256u) t = 256u;
            kt_glut[h * 32u + j] = RGB565(c[0] * t >> 8, c[1] * t >> 8, c[2] * t >> 8);
        }
    }
}

/* ---- seeds (what sounds), keys, autoplay */
static int key_note(int k)
{
    const kt_scale_t *sc = &KT_SCALES[KT_PLANETS[cur_planet < 0 ? 0 : cur_planet].scale];
    int base = KT_PLANETS[cur_planet < 0 ? 0 : cur_planet].root + 12 * S.octave;
    return base + sc->st[k % sc->len] + 12 * (k / sc->len);
}
static uint32_t rate_for(int note)
{
    int st = clampi(note - src_note, -60, 60);
    return KT_SEMI_Q16[60 + st];
}
static int seed_start(int note, int key, int autos, uint32_t dur, int deg)
{
    int i, pick = -1;
    uint32_t oldest = 0xFFFFFFFFu;
    for (i = 0; i < NSEED; i++) if (!sm[i].on && ao_amp[i] < 100) { pick = i; break; }
    if (pick < 0) for (i = 0; i < NSEED; i++) if (sm[i].autos && sm[i].born < oldest) { oldest = sm[i].born; pick = i; }
    if (pick < 0) for (i = 0; i < NSEED; i++) if (sm[i].born < oldest) { oldest = sm[i].born; pick = i; }
    sd[pick].gate = 0;
    sd[pick].rate = rate_for(note);
    if (autos) { sd[pick].att = 30; sd[pick].rel = 14; }
    else if (S.swell) { sd[pick].att = 22; sd[pick].rel = 10; }
    else { sd[pick].att = 600; sd[pick].rel = 26; }
    sd[pick].gate = autos ? 21000 : 26000;
    sm[pick].on = 1; sm[pick].key = (int8_t)key; sm[pick].autos = (uint8_t)autos; sm[pick].latched = 0;
    sm[pick].note = (uint8_t)note; sm[pick].deg = (uint8_t)deg; sm[pick].born = now_ms; sm[pick].until = now_ms + dur;
    sm[pick].theta = (uint16_t)(m_rand());
    sm[pick].speed = (int16_t)(60 + (int)(m_rand() & 63u) + (note & 15) * 6);
    if (m_rand() & 1u) sm[pick].speed = (int16_t)-sm[pick].speed;
    return pick;
}
static void seed_stop(int i) { sm[i].on = 0; sd[i].gate = 0; }
static void all_stop(void) { int i; for (i = 0; i < NSEED; i++) seed_stop(i); }

KT_API void kt_key(int k, int down)
{
    int i;
    if (k < 0 || k > 26 || warp) return;
    if (down) {
        const kt_scale_t *sc = &KT_SCALES[KT_PLANETS[cur_planet].scale];
        seed_start(key_note(k), k, 0, 0, k % sc->len);
    } else {
        for (i = 0; i < NSEED; i++)
            if (sm[i].on && sm[i].key == k && !sm[i].autos) {
                if (S.hold) sm[i].latched = 1; else seed_stop(i);
            }
    }
}
KT_API void kt_midi_note(int note, int vel, int on)
{
    int i;
    if (warp) return;
    if (on && vel) { i = seed_start(note, 100 + note, 0, 0, (uint32_t)note % 12u); sd[i].gate = 9000 + vel * 140; }
    else for (i = 0; i < NSEED; i++) if (sm[i].on && sm[i].key == 100 + note) { if (S.hold) sm[i].latched = 1; else seed_stop(i); }
}

static void popup(int p) { popup_p = p; popup_until = now_ms + 1600u; }
static void travel(int dir)
{
    int n = cur_planet + dir;
    while (n < 0) n += KT_NPLANETS;
    n %= KT_NPLANETS;
    next_planet = n;
    if (!warp) { warp = 1; ap_level = 0; }
    title_until = now_ms + 4200u;
}
KT_API void kt_encoder(int e, int steps)
{
    static const int MAP[7] = {P_SPACE, P_TONE, P_SIZE, P_DENS, P_SCAT, P_DRIFT, -1};
    int p;
    if (e < 0 || e > 6 || !steps) return;
    if (e == 6) { travel(steps > 0 ? 1 : -1); return; }
    p = MAP[e];
    S.p[p] = (uint8_t)clampi(S.p[p] + steps * 3, 0, 127);
    popup(p);
}
KT_API void kt_button(int b)
{
    int i;
    switch (b) {
    case 0: if (S.octave > -2) S.octave--; popup(10); break;               /* OCT- */
    case 1: if (S.octave < 2) S.octave++; popup(10); break;                /* OCT+ */
    case 2: S.shimmer ^= 1u; popup(11); break;                             /* FX: shimmer */
    case 3:                                                                /* SCL: mutate */
        for (i = 0; i < 4; i++) S.p[i] = (uint8_t)clampi(S.p[i] + (int)(m_rand() % 41u) - 20, 4, 123);
        popup(12); break;
    case 4: S.swell ^= 1u; popup(13); break;                               /* ENV: swell */
    case 5: S.pal = (uint8_t)((S.pal + 1u) & 3u); glut_build(cur_planet); popup(14); break;   /* LFO: colours */
    case 6: S.lens = (uint8_t)((S.lens + 1u) % 3u); popup(15); break;      /* EDIT: lens */
    case 7: ap_bloom++; flash_until = now_ms + 700u; break;                /* GLO: bloom */
    case 8: help_on ^= 1; break;                                           /* HOME: help */
    case 9: save_req = 1; popup(16); break;                                /* SAVE */
    case 10: S.pulse ^= 1u; popup(17); break;                              /* ARP: pulse */
    case 11: S.perc ^= 1u; popup(20); break;                              /* SEQ: feather percussion */
    case 12: S.autoplay ^= 1u; popup(18); if (!S.autoplay) for (i = 0; i < NSEED; i++) if (sm[i].autos) seed_stop(i); break;
    case 13: S.hold ^= 1u; popup(19);                                      /* REC: hold (and freeze the scan) */
        if (!S.hold) for (i = 0; i < NSEED; i++) if (sm[i].latched) seed_stop(i);
        break;
    }
}

/* ---- the planet changes, and the slow weather */
static void planet_apply(int pl)
{
    int i;
    cur_planet = pl;
    S.planet = (uint8_t)pl;
    for (i = 0; i < 6; i++) { S.p[i] = KT_PLANETS[pl].def[i]; walk[i] = walk_t[i] = 0; }
    glut_build(pl);
    for (i = 0; i < LN; i++) kt_glow[i] = 0;
    center_q16 = 0;
}
static int gen_step(uint32_t budget)            /* returns 1 when the planet is ready */
{
    uint32_t i, end;
    if (gen_phase == 0) {
        gen_setup(next_planet); gen_pos = 0; gen_phase = 1; g_peak = 1;
        if (src_real) gen_phase = 3;            /* a recording is loaded: keep it, change only scale, palette, form */
        return 0;
    }
    if (gen_phase == 1) {
        end = gen_pos + budget; if (end > SRC_LEN) end = SRC_LEN;
        for (i = gen_pos; i < end; i++) {
            int32_t s = gen_sample(i);
            kt_src[i] = (int16_t)s;
            if (s < 0) s = -s;
            if (s > g_peak) g_peak = s;
        }
        gen_pos = end;
        if (gen_pos >= SRC_LEN) { gen_phase = 2; gen_pos = 0; }
        return 0;
    }
    if (gen_phase == 2) {                       /* normalise to a common loudness */
        int32_t sc = (int32_t)((29000u << 12) / (uint32_t)g_peak);
        end = gen_pos + budget * 4u; if (end > SRC_LEN) end = SRC_LEN;
        for (i = gen_pos; i < end; i++) kt_src[i] = (int16_t)clamp16((kt_src[i] * sc) >> 12);
        gen_pos = end;
        if (gen_pos >= SRC_LEN) { kt_src[SRC_LEN] = kt_src[0]; gen_phase = 3; }
        return 0;
    }
    visual_setup(next_planet);
    gen_phase = 0;
    return 1;
}
static int32_t eff(int p)                       /* a parameter with the weather on it */
{
    int32_t depth = S.p[P_DRIFT];
    int32_t v = S.p[p] + ((walk[p] * depth) >> 7);
    return clampi(v, 0, 127);
}
static void weather(uint32_t dt)
{
    int i;
    for (i = 0; i < 6; i++) {
        if (i == P_DRIFT) continue;
        if (now_ms >= walk_next[i]) {
            walk_t[i] = (int32_t)(m_rand() % 61u) - 30;
            walk_next[i] = now_ms + 6000u + (m_rand() % 18000u) * (128u - S.p[P_DRIFT]) / 128u;
        }
        walk[i] += ((walk_t[i] - walk[i]) * (int32_t)dt) / 3000;
        if (walk[i] == 0 && walk_t[i]) walk[i] += walk_t[i] > 0 ? 1 : -1;
    }
    if (!S.hold) center_q16 += (uint32_t)((2u + S.p[P_DRIFT] / 6u) * dt) << 8;
}
static void autoplay(void)
{
    const kt_scale_t *sc = &KT_SCALES[KT_PLANETS[cur_planet].scale];
    int i, n = 0, deg;
    for (i = 0; i < NSEED; i++) {
        if (sm[i].on && sm[i].autos) { n++; if (now_ms >= sm[i].until) seed_stop(i); }
    }
    if (!S.autoplay || warp || now_ms < next_auto) return;
    if (n < 3) {
        static const uint8_t CH[8] = {0, 2, 4, 7, 9, 11, 14, 4};
        deg = CH[m_rand() & 7u];
        if (sc->len == 5) deg = deg * 5 / 7;
        seed_start(key_note(deg + (m_rand() % 3u == 0 ? sc->len : 0)), -1, 1,
                   9000u + m_rand() % 16000u - S.p[P_DRIFT] * 30u, deg % sc->len);
    }
    next_auto = now_ms + 2500u + m_rand() % 7000u - S.p[P_DRIFT] * 12u;
}
static void params_out(void)
{
    uint32_t len = KT_SIZE_LEN[eff(P_SIZE)], gps16 = KT_DENS_GPS_Q4[eff(P_DENS)], ov;
    ap_len = len;
    ap_spawn = KT_DENS_Q24[eff(P_DENS)];
    ap_scatter = eff(P_SCAT) * 258;
    ap_tone = KT_TONE[eff(P_TONE)];
    ap_fb = KT_SPACE_FB[eff(P_SPACE)];
    ap_wet = KT_SPACE_WET[eff(P_SPACE)];
    ap_damp = 6000 + eff(P_TONE) * 150;
    ap_center = center_q16;
    ap_shimmer = S.shimmer ? 9000 : 0;
    /* MOTION also drives a real LFO: 0.05 Hz .. ~1.3 Hz, sways grain position (up to ~0.3 s) and stereo width */
    ap_lfo_inc = 4870u + (uint32_t)eff(P_DRIFT) * 990u;          /* 2^32 / 44100 * Hz */
    ap_lfo_depth = (uint32_t)eff(P_DRIFT) * 100u;
    ap_perc = S.perc ? 1u : 0u;
    ap_drum_period = (uint32_t)(KT_FS * 60u / (4u * (70u + S.p[P_DENS] / 2u)));
    ap_pulse = S.pulse ? (uint32_t)(((uint64_t)(70u + S.p[P_DENS] / 2u) << 32) / (60u * KT_FS) ) : 0u;
    ov = gps16 * len / KT_FS;                   /* grains overlapping, Q4 */
    ap_ggain = (int32_t)(((int64_t)KT_INVSQRT[ov > 1023u ? 1023u : ov] * 60000) >> 15);
}

/* ---- the picture's moving parts */
typedef struct { int32_t x, y, vx, vy; uint16_t age, life; uint8_t hue, amp, size, on; } part_t;
static part_t pt[NPART];
static uint32_t pt_next;
static void seed_xy(int i, int32_t *x, int32_t *y, int32_t *front) /* full-res position on the orbit */
{
    int32_t r = 40 + (sm[i].note & 63) * 3 / 2, c = kt_sine((uint32_t)sm[i].theta << 16), s = kt_sine(((uint32_t)sm[i].theta << 16) + 0x40000000u);
    r = clampi(r, 44, 116);
    *x = PCX * 2 + ((r * c) >> 15);
    *y = PCY * 2 + ((r * 40 / 100 * s) >> 15) - (sm[i].note % 24) * 2 + 10;
    *front = s > 0;
}
static void particles(uint32_t dt)
{
    const kt_planet_t *P = &KT_PLANETS[cur_planet];
    uint32_t h = ev_head, i, decay;
    int k;
    while (ev_tail != h) {                      /* each grain heard becomes a mote of light */
        gev_t e = kt_ev[ev_tail & 63u];
        int32_t sx, sy, fr;
        part_t *p = &pt[pt_next++ % NPART];
        ev_tail++;
        if (e.seed >= NSEED) continue;
        impact_from(&e);
        seed_xy(e.seed, &sx, &sy, &fr);
        p->x = (sx << 7) + (((int32_t)(m_rand() & 1023u) - 512) * 6);
        p->y = (sy << 7) + (((int32_t)(m_rand() & 1023u) - 512) * 6);
        {
            int32_t dx = sx - PCX * 2, dy = sy - PCY * 2, sp = 1 + S.p[P_SCAT] / 20, d = 1 + (int32_t)kt_isqrt((uint32_t)(dx * dx + dy * dy));
            p->vx = dx * sp * 8 / d + ((int32_t)(m_rand() & 63u) - 32) + ((int32_t)e.pan - 128) / 4 + P->wind_x * 8;
            p->vy = dy * sp * 8 / d + ((int32_t)(m_rand() & 63u) - 32) + P->wind_y * 8;
        }
        p->age = 0;
        p->life = (uint16_t)clampi((int32_t)e.len8 * 12 + 900 + (int32_t)(m_rand() & 511u), 900, 4200);   /* ms: a mote outlives its grain */
        p->hue = (uint8_t)clampi((int32_t)(sm[e.seed].deg * 16 / KT_SCALES[P->scale].len) + e.iv / 3, 0, 15);
        p->amp = e.amp;
        p->size = (uint8_t)(e.len8 > 90 ? 3 : e.len8 > 30 ? 2 : 1);
        p->on = 1;
    }
    /* trails fade */
    decay = P->trail;
    if (dt > 50u) decay = decay * decay >> 8;
    for (i = 0; i < LN; i++) kt_glow[i] = (uint8_t)((kt_glow[i] * decay) >> 8);
    /* motes move and leave light */
    for (k = 0; k < NPART; k++) {
        part_t *p = &pt[k];
        int32_t lx, ly, b, r, dy2, dx2;
        if (!p->on) continue;
        p->x += p->vx * (int32_t)dt / 32;
        p->y += p->vy * (int32_t)dt / 32;
        p->vx = p->vx * 63 / 64;
        p->vy = p->vy * 63 / 64 + (cur_planet == 5 ? -1 : 0);
        p->age = (uint16_t)(p->age + dt);
        if (p->age >= p->life) { p->on = 0; continue; }
        lx = p->x >> 8; ly = p->y >> 8;             /* full-res Q7 -> low-res */
        b = (p->amp + 50) * (p->life - p->age) / p->life;
        r = p->size;
        for (dy2 = -r; dy2 <= r; dy2++)
            for (dx2 = -r; dx2 <= r; dx2++) {
                int32_t x = lx + dx2, y = ly + dy2, idx, v, d2 = dx2 * dx2 + dy2 * dy2, w;
                if ((uint32_t)x >= LW || (uint32_t)y >= LH || d2 > r * r + 1) continue;
                idx = y * LW + x;
                w = 256 - d2 * 200 / (r * r + 1);
                v = kt_glow[idx] + ((b * w) >> 10);
                kt_glow[idx] = (uint8_t)(v > 255 ? 255 : v);
                kt_hue[idx] = p->hue;
            }
    }
    /* the seeds turn on their orbits and glow where they are */
    for (k = 0; k < NSEED; k++) {
        int32_t sx, sy, fr, a = ao_amp[k];
        if (a < 200) continue;
        sm[k].theta = (uint16_t)(sm[k].theta + sm[k].speed * (int32_t)dt / 16);
        seed_xy(k, &sx, &sy, &fr);
        sx >>= 1; sy >>= 1;
        if ((uint32_t)sx < LW && (uint32_t)sy < LH) {
            int32_t idx = sy * LW + sx, v = kt_glow[idx] + (a >> 6);
            kt_glow[idx] = (uint8_t)(v > 255 ? 255 : v);
            kt_hue[idx] = (uint8_t)(sm[k].deg * 16 / KT_SCALES[P->scale].len);
        }
    }
    /* the warp: streaks from the middle */
    if (warp) {
        for (k = 0; k < 6; k++) {
            uint32_t r = m_rand(), a = r << 16;
            int32_t d, c = kt_sine(a), s = kt_sine(a + 0x40000000u);
            for (d = 10; d < 80; d += 3) {
                int32_t x = PCX + ((c * d) >> 15), y = PCY + ((s * d) >> 15);
                if ((uint32_t)x < LW && (uint32_t)y < LH) { kt_glow[y * LW + x] = (uint8_t)clampi(d * 3, 0, 255); kt_hue[y * LW + x] = (uint8_t)(r >> 28); }
            }
        }
    }
}
/* ---- public: start, update, draw */
KT_API void kt_say(void)                          /* sing "MA-RA-DO-NNA" in the species' key */
{
    ap_vx_root = KT_PLANETS[cur_planet < 0 ? 0 : cur_planet].root;
    ap_say++;
}
KT_API void kt_init(uint32_t seed)
{
    int i;
    m_rng = seed | 1u;
    a_rng = (seed * 2654435761u) | 1u;
    S.ver = 2; S.perc = 0; S.planet = 0; S.octave = 0; S.autoplay = 1; S.shimmer = 0; S.lens = 0; S.pal = 0; S.pulse = 0; S.swell = 0; S.hold = 0;
    for (i = 0; i < (int)sizeof(kt_rv) / 2; i++) kt_rv[i] = 0;
    next_planet = 0;
    gen_phase = 0;
    while (!gen_step(65536u)) {}
    planet_apply(0);
    ap_level = 32767;
    splash_until = 5200u;
    title_until = 0;
    next_auto = 1900u;                          /* the flock waits for the greeting */
    say_at = 650u;                              /* power-on: the singer greets */
    NM.syl = -1; NM.syl_hi = 3;
    { int r; for (r = 0; r < 4; r++) RIP[r].age = 900u; }
    params_out();
}
KT_API void kt_get_settings(kt_settings_t *o) { *o = S; o->planet = (uint8_t)cur_planet; }
KT_API void kt_set_settings(const kt_settings_t *in)   /* at boot, after kt_init */
{
    int pl;
    if (in->ver != 2) return;
    pl = in->planet % KT_NPLANETS;
    if (pl != cur_planet) {
        next_planet = pl; gen_phase = 0;
        while (!gen_step(65536u)) {}
        planet_apply(pl);
    }
    S = *in;
    S.perc = !!S.perc;
    S.planet = (uint8_t)pl;
    S.hold = 0;
    glut_build(pl);
    params_out();
}
KT_API int kt_take_save(void) { int r = save_req; save_req = 0; return r; }
KT_API int kt_quiet(void) { return ao_peak < 40; }
/* Host/Web UI integration. Hardware knobs and these setters enter the same state. */
KT_API int kt_get_species(void) { return cur_planet; }
KT_API int kt_get_param(int p) { return p >= 0 && p < 6 ? S.p[p] : 0; }
KT_API int kt_get_flag(int f)
{
    switch (f) { case 0: return S.perc; case 1: return S.autoplay;
                 case 2: return S.pulse; case 3: return S.shimmer;
                 case 4: return S.hold; default: return 0; }
}
KT_API uint32_t kt_visual_peak(void) { return (uint32_t)ao_peak; }
KT_API uint32_t kt_visual_grain_events(void) { return ao_grain_events; }
KT_API uint32_t kt_visual_grain_count(void) { return ao_grain_count; }
KT_API uint32_t kt_visual_voice_count(void) { return ao_voice_count; }
KT_API uint32_t kt_visual_kick(void) { return (uint32_t)a_kick_pk; }     /* peak-held envelopes (see kt_audio) */
KT_API uint32_t kt_visual_snare(void) { return (uint32_t)a_snare_pk; }
KT_API uint32_t kt_visual_hat(void) { return (uint32_t)a_hat_pk; }
KT_API uint32_t kt_visual_drum_hits(void) { return ao_hits; }
KT_API uint32_t kt_visual_wet(void) { return (uint32_t)ap_wet; }
KT_API uint32_t kt_visual_pulse_phase(void) { return a_beat >> 16; }
KT_API uint32_t kt_visual_scan_phase(void) { return (center_q16 >> 16) & 65535u; }
KT_API uint32_t kt_visual_bloom(void) { return ap_bloom; }
/* ---- telemetry 03: every value below is produced by the DSP itself (or is the exact value it is using) */
KT_API uint32_t kt_visual_rev_tail(void) { return (uint32_t)ao_rev; }          /* measured FDN output, 0..~32767 */
KT_API uint32_t kt_visual_dry(void) { return (uint32_t)ao_dry; }               /* measured dry level before the reverb */
KT_API int32_t kt_visual_lfo(void) { return ao_lfo; }                          /* the MOTION LFO, -32767..32767 */
KT_API uint32_t kt_visual_lfo_depth(void) { return ap_lfo_depth; }             /* its depth in samples of sway */
KT_API uint32_t kt_visual_tone(void) { return (uint32_t)ap_tone; }             /* the low-pass coefficient in use, Q15 */
KT_API uint32_t kt_visual_drum_step(void) { return a_drum_step; }
KT_API uint32_t kt_visual_scope_head(void) { return ao_scope_head; }
KT_API int16_t *kt_visual_scope(void) { return kt_scope; }                    /* 256 x int16 ring */
KT_API uint32_t kt_visual_ev_head(void) { return ev_head; }
KT_API gev_t *kt_visual_ev_ring(void) { return kt_ev; }                        /* 64 x 8 bytes ring */
KT_API uint32_t kt_visual_src_real(void) { return src_real; }
/* the singer (04), measured in kt_audio */
KT_API uint32_t kt_visual_say_env(void) { return (uint32_t)ao_vx_env; }        /* output peak follower, 0..32767 */
KT_API uint32_t kt_visual_say_band(int k) { return k >= 0 && k < 3 ? (uint32_t)ao_vx_band[k] : 0u; }   /* each formant filter's own output */
KT_API int32_t kt_visual_say_f(int k) { return k == 0 ? ao_vx_f1 : ao_vx_f2; }   /* formant centres in use, Hz */
KT_API int32_t kt_visual_say_hz(void) { return ao_vx_hz; }                      /* the carrier pitch in use, Hz */
KT_API int32_t kt_visual_say_syl(void) { return ao_vx_syl; }                    /* 0 MA 1 RA 2 DO 3 NNA, -1 silent */
KT_API uint32_t kt_visual_say_count(void) { return ao_vx_count; }
/* the stage and the five visual layers live in the engine, so the browser's Device view and the FM-1 agree */
KT_API void kt_set_scene(int n) { S.lens = (uint8_t)(((n % 3) + 3) % 3); }
KT_API int kt_get_scene(void) { return S.lens; }
KT_API void kt_set_layers(int mask) { vis_layers = (uint8_t)(mask & 31); }
KT_API int kt_get_layers(void) { return vis_layers; }
KT_API int kt_visual_tris(void) { return ntri; }                               /* triangles drawn this frame */
/* ---- an imported recording as the grain source (browser: REAL mode). The page writes n mono int16 samples at
 * kt_src_buf() (already resampled to 44.1 kHz, normalised, ends crossfaded), then commits. Shorter material is
 * repeated to fill the 65536-sample loop so grains never read silence. kt_src_synth() returns to the species' voice. */
KT_API int16_t *kt_src_buf(void) { return kt_src; }
KT_API int kt_src_commit(uint32_t n)
{
    uint32_t i;
    if (n < 2048u) return 0;
    if (n > SRC_LEN) n = SRC_LEN;
    for (i = n; i < SRC_LEN; i++) kt_src[i] = kt_src[i % n];
    kt_src[SRC_LEN] = kt_src[0];
    src_real = 1;
    src_note = KT_PLANETS[cur_planet < 0 ? 0 : cur_planet].root + 12;
    return 1;
}
KT_API void kt_src_synth(void)
{
    if (!src_real) return;
    src_real = 0;
    next_planet = cur_planet;
    if (!warp) { warp = 1; ap_level = 0; }
}
KT_API int kt_visual_eff(int p) { return p >= 0 && p < 6 ? eff(p) : 0; }      /* parameter after the slow weather */
/* a voice, packed: level (bits 0-14), rising (15), scale degree (16-23), MIDI note (24-31) */
KT_API uint32_t kt_visual_voice(int i)
{
    int32_t a;
    if (i < 0 || i >= NSEED) return 0;
    a = ao_amp[i];
    if (a < 0) a = 0;
    if (a > 32767) a = 32767;
    return (uint32_t)a | ((uint32_t)(sd[i].gate > a + 64) << 15) | ((uint32_t)sm[i].deg << 16) | ((uint32_t)sm[i].note << 24);
}
KT_API void kt_set_param(int p, int val)
{
    if (p < 0 || p >= 6) return;
    S.p[p] = (uint8_t)clampi(val, 0, 127);
    popup(p);
}
KT_API void kt_set_species(int species)
{
    if (species < 0 || species >= KT_NPLANETS || species == cur_planet) return;
    next_planet = species;
    if (!warp) { warp = 1; ap_level = 0; }
    title_until = now_ms + 3400u;
}


KT_API void kt_update(uint32_t ms)
{
    uint32_t dt;
    now_ms = ms;
    dt = last_ms ? ms - last_ms : 16u;
    if (dt > 120u) dt = 120u;
    last_ms = ms;
    if (warp == 1 && ao_level == 0) { ap_kill++; all_stop(); warp = 2; gen_phase = 0; }
    if (warp == 2) {
        if (gen_step(6144u)) { planet_apply(next_planet); warp = 3; ap_level = 32767; next_auto = now_ms + 300u; }
    } else if (warp == 3 && ao_level > 30000) warp = 0;
    if (warp != 2) {
        weather(dt);
        autoplay();
        params_out();
    }
    if (say_at && now_ms >= say_at) { say_at = 0; kt_say(); }
    particles(dt);
    nmap_frame(dt);
    mesh_frame(dt);
}

/* LEDs: buttons lit (bits by Dinghy's BTN_ ids), keys sounding, keys glowing (the roots) */
KT_API void kt_leds(uint32_t *btn, uint32_t *keys, uint32_t *glow)
{
    const kt_scale_t *sc = &KT_SCALES[KT_PLANETS[cur_planet].scale];
    uint32_t b = 0, k = 0, g = 0;
    int i;
    if (S.shimmer) b |= 1u << 2;
    if (S.swell) b |= 1u << 4;
    if (S.pulse) b |= 1u << 10;
    if (S.perc) b |= 1u << 11;
    if (S.autoplay) b |= 1u << 12;
    if (S.hold) b |= 1u << 13;
    if (now_ms < flash_until) b |= 1u << 7;
    for (i = 0; i < NSEED; i++) if (sm[i].on && sm[i].key >= 0 && sm[i].key < 27) k |= 1u << sm[i].key;
    for (i = 0; i < 27; i += sc->len) g |= 1u << i;
    *btn = b; *keys = k; *glow = g;
}

/* ---- drawing into a strip of rows (240 wide), RGB565; swap = the panel's byte order */
static uint16_t *rb;
static int ry0, rh;
static void px(int32_t x, int32_t y, uint16_t c)
{
    y -= ry0;
    if ((uint32_t)x < 240u && (uint32_t)y < (uint32_t)rh) rb[y * 240 + x] = c;
}
static void pxadd(int32_t x, int32_t y, uint16_t c)
{
    y -= ry0;
    if ((uint32_t)x < 240u && (uint32_t)y < (uint32_t)rh) rb[y * 240 + x] = add565(rb[y * 240 + x], c);
}
static void line(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c)
{
    int32_t dx = x1 > x0 ? x1 - x0 : x0 - x1, sx = x0 < x1 ? 1 : -1, dy = y1 > y0 ? y0 - y1 : y1 - y0, sy = y0 < y1 ? 1 : -1, err = dx + dy, n = 600;
    if ((y0 < ry0 - 2 && y1 < ry0 - 2) || (y0 >= ry0 + rh + 2 && y1 >= ry0 + rh + 2)) return;
    while (n--) {
        int32_t e2 = 2 * err;
        pxadd(x0, y0, c);
        if (x0 == x1 && y0 == y1) break;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}
/* ---- native 03: drawing helpers for the strips */
static void aline(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c)   /* Q4 ends; anti-aliased (Wu), additive */
{
    int32_t dx = x1 - x0, dy = y1 - y0, adx = dx < 0 ? -dx : dx, ady = dy < 0 ? -dy : dy, i, n, acc, step;
    int32_t ya = y0 >> 4, yb = y1 >> 4;
    if ((ya < ry0 - 2 && yb < ry0 - 2) || (ya >= ry0 + rh + 2 && yb >= ry0 + rh + 2)) return;
    if (adx >= ady) {
        if (x1 < x0) { int32_t t = x0; x0 = x1; x1 = t; t = y0; y0 = y1; y1 = t; dy = -dy; }
        dx = x1 - x0;
        if (dx < 16) { pxadd(x0 >> 4, y0 >> 4, c); return; }
        step = (dy << 8) / dx;
        n = (x1 >> 4) - (x0 >> 4);
        acc = (y0 << 8) + ((((x0 >> 4) << 4) + 8 - x0) * step);
        step <<= 4;
        for (i = 0; i <= n; i++) {
            int32_t yq = (acc >> 8) - 8, row = yq >> 4, f = (yq & 15) << 4, x = (x0 >> 4) + i;
            pxadd(x, row, scale565(c, (uint32_t)(256 - f)));
            pxadd(x, row + 1, scale565(c, (uint32_t)f));
            acc += step;
        }
    } else {
        if (y1 < y0) { int32_t t = x0; x0 = x1; x1 = t; t = y0; y0 = y1; y1 = t; dx = -dx; }
        dy = y1 - y0;
        if (dy < 16) { pxadd(x0 >> 4, y0 >> 4, c); return; }
        step = (dx << 8) / dy;
        n = (y1 >> 4) - (y0 >> 4);
        acc = (x0 << 8) + ((((y0 >> 4) << 4) + 8 - y0) * step);
        step <<= 4;
        for (i = 0; i <= n; i++) {
            int32_t xq = (acc >> 8) - 8, col = xq >> 4, f = (xq & 15) << 4, y = (y0 >> 4) + i;
            if (y >= ry0 && y < ry0 + rh) { pxadd(col, y, scale565(c, (uint32_t)(256 - f))); pxadd(col + 1, y, scale565(c, (uint32_t)f)); }
            acc += step;
        }
    }
}
static void aring(int32_t cx, int32_t cy, int32_t rx, int32_t ry, uint32_t a0, uint32_t a1, uint16_t c)   /* an arc of an ellipse, Q4 radii */
{
    int k, n = 40;
    int32_t px0 = 0, py0 = 0;
    uint32_t step = (a1 - a0) / 40u;
    if (cy + (ry >> 4) + 2 < ry0 || cy - (ry >> 4) - 2 >= ry0 + rh) return;
    for (k = 0; k <= n; k++) {
        uint32_t a = a0 + step * (uint32_t)k;
        int32_t x = (cx << 4) + ((rx * kt_sine(a + 0x40000000u)) >> 15), y = (cy << 4) + ((ry * kt_sine(a)) >> 15);
        if (k) aline(px0, py0, x, y, c);
        px0 = x; py0 = y;
    }
}
static void tri_strip(int t)                     /* one triangle into the strip: z-buffered, Gouraud */
{
    int A = tv[t][0], B = tv[t][1], C = tv[t][2], y, ymin, ymax, xmin, xmax;
    int32_t x0 = vsx[A], y0 = vsy[A], x1 = vsx[B], y1 = vsy[B], x2 = vsx[C], y2 = vsy[C], area;
    int32_t zA = vsz[A], zB = vsz[B] - zA, zC = vsz[C] - zA;
    int32_t rA = vr[A], gA = vg[A], bA = vb[A], rB = vr[B] - rA, gB = vg[B] - gA, bB = vb[B] - bA, rC = vr[C] - rA, gC = vg[C] - gA, bC = vb[C] - bA;
    if (ty1[t] < ry0 || ty0[t] >= ry0 + rh) return;
    area = (x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0);
    if (area > 0) {                             /* make it counter-clockwise for the edge tests below */
        int32_t s; s = x1; x1 = x2; x2 = s; s = y1; y1 = y2; y2 = s;
        s = zB; zB = zC; zC = s; s = rB; rB = rC; rC = s; s = gB; gB = gC; gC = s; s = bB; bB = bC; bC = s;
        area = -area;
    }
    area = -area;
    if (area < 16) return;
    ymin = ty0[t] < ry0 ? ry0 : ty0[t]; ymax = ty1[t] >= ry0 + rh ? ry0 + rh - 1 : ty1[t];
    xmin = x0 < x1 ? x0 : x1; if (x2 < xmin) xmin = x2;
    xmax = x0 > x1 ? x0 : x1; if (x2 > xmax) xmax = x2;
    xmin = clampi(xmin >> 4, 0, 239); xmax = clampi((xmax >> 4) + 1, 0, 239);
    for (y = ymin; y <= ymax; y++) {
        int32_t cyq = y * 16 + 8, x, xs = -1, xe = -1, b1s, b2s, b1e, b2e, b1, b2, d1, d2, n;
        uint16_t *row = rb + (y - ry0) * 240;
        int16_t *zr = kt_zb + (y - ry0) * 240;
        for (x = xmin; x <= xmax; x++) {        /* the span: edge tests only */
            int32_t cxq = x * 16 + 8;
            int32_t w0 = (x2 - x1) * (cyq - y1) - (y2 - y1) * (cxq - x1), w1 = (x0 - x2) * (cyq - y2) - (y0 - y2) * (cxq - x2), w2 = (x1 - x0) * (cyq - y0) - (y1 - y0) * (cxq - x0);
            if (w0 > 0 || w1 > 0 || w2 > 0) { if (xs >= 0) break; continue; }
            if (xs < 0) xs = x;
            xe = x;
        }
        if (xs < 0) continue;
        {   /* barycentrics (Q8) at both ends of the span, then linear across it (they are affine in x) */
            int32_t cxs = xs * 16 + 8, cxe = xe * 16 + 8;
            int32_t w1s = (x0 - x2) * (cyq - y2) - (y0 - y2) * (cxs - x2), w2s = (x1 - x0) * (cyq - y0) - (y1 - y0) * (cxs - x0);
            int32_t w1e = (x0 - x2) * (cyq - y2) - (y0 - y2) * (cxe - x2), w2e = (x1 - x0) * (cyq - y0) - (y1 - y0) * (cxe - x0);
            /* w1 weights vertex B (opposite edge C-A), w2 weights vertex C (opposite edge A-B) */
            if (area < (1 << 22)) { b1s = (-w1s << 8) / area; b2s = (-w2s << 8) / area; b1e = (-w1e << 8) / area; b2e = (-w2e << 8) / area; }
            else { int32_t a8 = area >> 8; b1s = -w1s / a8; b2s = -w2s / a8; b1e = -w1e / a8; b2e = -w2e / a8; }   /* 32-bit only: the FM-1 has no 64-bit divide */
        }
        n = xe - xs; if (n < 1) n = 1;
        b1 = b1s << 16; b2 = b2s << 16; d1 = ((b1e - b1s) << 16) / n; d2 = ((b2e - b2s) << 16) / n;
        for (x = xs; x <= xe; x++, b1 += d1, b2 += d2) {
            int32_t p1 = b1 >> 16, p2 = b2 >> 16, z = zA + ((zB * p1 + zC * p2) >> 8);
            if (z <= zr[x]) continue;
            zr[x] = (int16_t)z;
            row[x] = RGB565(clampi(rA + ((rB * p1 + rC * p2) >> 8), 0, 255), clampi(gA + ((gB * p1 + gC * p2) >> 8), 0, 255), clampi(bA + ((bB * p1 + bC * p2) >> 8), 0, 255));
        }
    }
}
static void stage_rows(uint32_t warpdim)         /* the world behind the bird: sky, city, river, ledge; the reverb's halo */
{
    const kt_planet_t *P = &KT_PLANETS[cur_planet];
    static const uint8_t PAPER0[3] = {250, 247, 238}, PAPER1[3] = {241, 235, 222}, INK[3] = {38, 40, 46}, DUSK[3] = {255, 120, 40}, NIGHT0[3] = {6, 8, 20}, NIGHT1[3] = {24, 26, 52};
    uint8_t top[3], bot[3], hal[3], c[3], ink[3], foam[3], water[3];
    int32_t x, y, rev = (vis_layers & 8) ? NM.rev : 0, hr = 46 + (rev * 70 >> 15) + S.p[P_SPACE] / 6, hr2 = hr * hr;
    int32_t wamp = (vis_layers & 1) ? clampi(NM.dry * 256 / 1200, 0, 256) + (NM.dry >> 12) * 256 : 0;   /* the crests: the measured waveform, its shape normalised, its height the dry level (Q8; a silent floor relaxes flat) */
    int32_t refl = 6 + (rev >> 10) + (NM.energy >> 12);                        /* the reflections lengthen with the tail */
    uint32_t hk = (uint32_t)(70 + (rev * 150 >> 15)), lph = (uint32_t)(NM.lfo + 32768) * 9000u;
    int scene = S.lens;
    if (scene == 1) { lerp3(NIGHT0, P->sky0, 70, top); lerp3(NIGHT1, DUSK, 60, bot); lerp3(DUSK, P->gl2, 60, foam); lerp3(NIGHT0, P->sky1, 50, water); ink[0] = 4; ink[1] = 5; ink[2] = 10; }
    else if (scene == 0) { lerp3(PAPER0, P->pl2, 30, top); lerp3(PAPER1, P->gl0, 25, bot); lerp3(INK, P->pl0, 60, ink); lerp3(P->gl0, INK, 90, foam); lerp3(PAPER1, P->gl0, 40, water); }
    else { lerp3(P->pl2, PAPER0, 150, top); lerp3(P->gl0, PAPER0, 120, bot); lerp3(P->gl1, INK, 60, ink); foam[0] = foam[1] = foam[2] = 255; lerp3(bot, P->gl1, 50, water); }
    lerp3(P->gl1, P->gl2, 128, hal);
    for (y = ry0; y < ry0 + rh; y++) {
        uint16_t *row = rb + (y - ry0) * 240;
        int32_t ly = y >> 1, ly2 = ly + ((y & 1) && ly < LH - 1), dy = y - SCY, up = HZ - y;
        if (y < HZ) lerp3(top, bot, (uint32_t)(y * 256 / HZ), c);
        else if (y < LEDGE) lerp3(water, bot, (uint32_t)((LEDGE - y) * 120 / (LEDGE - HZ)), c);
        else lerp3(bot, scene == 1 ? NIGHT0 : PAPER1, (uint32_t)(scene == 1 ? 150 : 40), c);
        if (scene == 1 && y < HZ && y > HZ - 60) { uint8_t t2[3]; lerp3(c, DUSK, (uint32_t)((60 - up) * 150 / 60), t2); c[0] = t2[0]; c[1] = t2[1]; c[2] = t2[2]; }   /* dusk */
        for (x = 0; x < 240; x++) {
            int32_t dx = x - SCX, d2 = dx * dx + dy * dy, r = c[0], g = c[1], b = c[2];
            int32_t lx = x >> 1, lx2 = lx + ((x & 1) && lx < LW - 1), i = ly * LW + lx;
            uint32_t gl_;
            if (y < HZ) {                       /* the city and the bridge */
                int32_t sh = sky_h[x], br = bridge_at(x, up), solid = up < sh || br;
                if (scene == 1) {
                    if (solid) {
                        r = ink[0]; g = ink[1]; b = ink[2];
                        if (!br && up > 2 && up < sh - 1 && (kt_hash((uint32_t)(x / 3) * 977u + (uint32_t)(up / 3) * 131u + g_seed) & 15u) == 0u && (x % 3) && (up % 3)) { r = 255; g = 190; b = 110; }   /* a lit window */
                        if (br == 1 && (x & 3) == 0) { r = 255; g = 200; b = 120; }   /* the bridge's lamps */
                    }
                } else {
                    int edge = (up == sh || (x && ((up >= sky_h[x - 1] && up < sh) || (up >= sh && up < sky_h[x - 1])))) && up < 32;
                    int bedge = br && (!bridge_at(x, up + 1) || !bridge_at(x, up - 1) || !bridge_at(x - 1, up) || !bridge_at(x + 1, up));
                    if (edge || bedge) { int32_t k = scene == 2 ? 120 : 210; r += (ink[0] - r) * k >> 8; g += (ink[1] - g) * k >> 8; b += (ink[2] - b) * k >> 8; }
                }
                if (d2 < hr2 * 3 && !solid) {   /* the halo: the reverb's measured tail widens and brightens it */
                    int32_t t = 256 - d2 * 256 / (hr2 * 3);
                    t = (int32_t)((uint32_t)(t * t >> 8) * hk >> 8);
                    r += (hal[0] - r) * t >> 8; g += (hal[1] - g) * t >> 8; b += (hal[2] - b) * t >> 8;
                }
                {   /* the sun, low over the river: its glow is the voices' energy */
                    int32_t sx = x - 60, sy2 = y - (HZ - 16), sd = sx * sx + sy2 * sy2, sr = 7;
                    if (sd < sr * sr && !solid) { r = DUSK[0]; g = DUSK[1] - (scene == 0 ? 20 : 0); b = DUSK[2]; }
                    else if (sd < 900 && !solid) { int32_t k = (900 - sd) * (40 + (NM.energy >> 9)) / 900; r += (DUSK[0] - r) * k >> 8; g += (DUSK[1] - g) * k >> 8; b += (DUSK[2] - b) * k >> 8; }
                }
            } else if (y < LEDGE) {             /* the river: wave crests are the oscillation; reflections stretch with the tail */
                int32_t k2, depth = y - HZ, best = 99;
                for (k2 = 0; k2 < 3; k2++) {
                    int32_t base = HZ + 9 + k2 * 12, a2 = wamp * (k2 + 2) / 3, w = NM.wave[(x * 63 / 239 + k2 * 11) & 63] * 32767 / (NM.wpk > 600 ? NM.wpk : 600);
                    int32_t cy2 = base + ((w * a2) >> 23), dd = y - cy2;
                    if (dd < 0) dd = -dd;
                    if (dd < best) best = dd;
                }
                if (scene == 1) {               /* dusk light on the water, broken by the LFO's swell */
                    int32_t streak = (int32_t)(kt_hash((uint32_t)(y >> 1) * 2654435761u + (uint32_t)((x + (kt_sine(lph + (uint32_t)y * 0x1000000u) >> 12)) / 23)) & 255u);
                    if ((y & 1) && depth < refl * 3 && streak < 60 + rev / 400) { int32_t k = (255 - depth * 255 / (refl * 3)) * 120 >> 8; r += (DUSK[0] - r) * k >> 8; g += (DUSK[1] - g) * k >> 8; b += (DUSK[2] - b) * k >> 8; }
                    if (sky_h[x] > 0 && depth < sky_h[x] && ((y + x) & 1)) { r = r * 3 >> 2; g = g * 3 >> 2; b = b * 3 >> 2; }   /* the city, mirrored */
                }
                if (best == 0) { r = foam[0]; g = foam[1]; b = foam[2]; }
                else if (best == 1) { r = (r + foam[0]) >> 1; g = (g + foam[1]) >> 1; b = (b + foam[2]) >> 1; }
                else if (scene == 0 && (y == HZ + 3 || y == HZ + 27) && (x / 7 + y) % 4) { r = (r * 3 + ink[0]) >> 2; g = (g * 3 + ink[1]) >> 2; b = (b * 3 + ink[2]) >> 2; }   /* ink strokes */
            } else {                            /* the ledge, and the bird's soft shadow on it */
                int32_t fx = dx * 256 / 70, fy = (y - (LEDGE + 6)) * 256 / 8, f2 = (fx * fx + fy * fy) >> 8;
                if (y == LEDGE || (scene != 1 && y == LEDGE + 1)) { r = ink[0]; g = ink[1]; b = ink[2]; }
                else if (scene == 0 && y < LEDGE + 8 && (x + y * 2) % 9 == 0) { r = (r + ink[0]) >> 1; g = (g + ink[1]) >> 1; b = (b + ink[2]) >> 1; }   /* hatching */
                else if (scene == 1) { int32_t n = (int32_t)(kt_hash((uint32_t)x * 31u + (uint32_t)y * 7919u) & 15u); r += n; g += n; b += n + 4; }
                if (f2 < 256) { int32_t sd2 = (256 - f2) * (scene == 1 ? 60 : 90) >> 8; r -= r * sd2 >> 8; g -= g * sd2 >> 8; b -= b * sd2 >> 8; }
            }
            if (scene == 2) {                   /* PRISM: spectral bands that the LFO and the voice energy move */
                uint32_t ph = (uint32_t)(x * 3 - y * 2) * 0x0300000u + (uint32_t)NM.lfo * 4000u;
                int32_t k = 10 + (NM.energy >> 11) + (rev >> 11);
                r += (kt_sine(ph) * k) >> 15; g += (kt_sine(ph + 0x55555555u) * k) >> 15; b += (kt_sine(ph + 0xAAAAAAAAu) * k) >> 15;
            }
            gl_ = ((uint32_t)kt_glow[i] + kt_glow[ly * LW + lx2] + kt_glow[ly2 * LW + lx] + kt_glow[ly2 * LW + lx2]) >> 2;
            {
                uint16_t col = RGB565(clampi(r, 0, 255), clampi(g, 0, 255), clampi(b, 0, 255));
                if (warpdim < 256u) col = scale565(col, warpdim);
                if (gl_ && (vis_layers & 2)) col = add565(col, kt_glut[kt_hue[i] * 32u + (gl_ >> 3)]);
                row[x] = col;
            }
        }
    }
}
static void bird_strip(void)
{
    int t, i;
    for (i = 0; i < 240 * rh; i++) kt_zb[i] = -32768;
    for (t = 0; t < ntri; t++) tri_strip(t);
    if (S.lens != 1) {                          /* ATELIER / PRISM: an ink line where the body meets the air or folds */
        const kt_planet_t *P = &KT_PLANETS[cur_planet];
        uint16_t ink = scale565(RGB565(P->pl0[0], P->pl0[1], P->pl0[2]), 120);
        uint32_t k = S.lens == 0 ? 210u : 110u;
        int y;
        for (y = 0; y < rh; y++) {
            uint16_t *row = rb + y * 240;
            int16_t *zr = kt_zb + y * 240;
            int x;
            for (x = 1; x < 239; x++) {
                int32_t z = zr[x], in = z > -32768, l = zr[x - 1] > -32768, r = zr[x + 1] > -32768, u = y ? zr[x - 240] > -32768 : in, d = y < rh - 1 ? zr[x + 240] > -32768 : in;
                int32_t dz = in && l ? z - zr[x - 1] : 0;
                if (in && (!l || !r || !u || !d)) row[x] = mix565(row[x], ink, k);
                else if (dz > 22 || dz < -22) row[x] = mix565(row[x], ink, k / 2);
            }
        }
    }
}
static void vdot(int32_t x, int32_t y, uint16_t c, uint32_t a, int32_t r)   /* a soft bead: light on Nocturne, ink-glaze on paper */
{
    int32_t dx, dy, yy;
    if (y + r < ry0 || y - r >= ry0 + rh) return;
    for (dy = -r; dy <= r; dy++) {
        yy = y + dy - ry0;
        if ((uint32_t)yy >= (uint32_t)rh) continue;
        for (dx = -r; dx <= r; dx++) {
            int32_t d2 = dx * dx + dy * dy, xx = x + dx;
            uint32_t w;
            if (d2 > r * r + r || (uint32_t)xx >= 240u) continue;
            w = a * (uint32_t)(r * r + r + 1 - d2) / (uint32_t)(r * r + r + 1);
            if (S.lens == 1) rb[yy * 240 + xx] = add565(rb[yy * 240 + xx], scale565(c, w));
            else rb[yy * 240 + xx] = mix565(rb[yy * 240 + xx], c, w * 3u / 4u);
        }
    }
}
static void singer_strip(void)                   /* VOICE: the song made visible (all from the singer's measured state) */
{
    int k;
    for (k = 0; k < NVT; k++) {                  /* the plume: each bead flies from where the beak was, rising (warm air) */
        vtrail_t *v = &VT[k], *w = &VT[(k + NVT - 3) % NVT];   /* same lane, one frame older */
        int32_t x, y, wx, wy, t, rr;
        uint32_t al;
        uint16_t c;
        if (v->age >= v->life) continue;
        t = v->age;
        x = v->x0 + v->vx * t / 1000; y = v->y0 + v->vy * t / 1000 - t * t / 120000;
        al = (uint32_t)v->e * (uint32_t)(v->life - v->age) / v->life;
        c = RGB565(v->c[0], v->c[1], v->c[2]);
        rr = 1 + (v->e > 100u) + (t < 900);
        vdot(x, y, c, al, rr);
        if (w->age < w->life && w->age > v->age && w->age - v->age < 140u) {   /* join to the bead before it */
            t = w->age;
            wx = w->x0 + w->vx * t / 1000; wy = w->y0 + w->vy * t / 1000 - t * t / 120000;
            if ((wx - x) * (wx - x) + (wy - y) * (wy - y) < 30 * 30) {
                if (S.lens == 1) { aline(x << 4, y << 4, wx << 4, wy << 4, scale565(c, al)); aline((x << 4) + 16, y << 4, (wx << 4) + 16, wy << 4, scale565(c, al >> 1)); }
                else { int j2; for (j2 = 1; j2 < 4; j2++) vdot(x + (wx - x) * j2 / 4, y + (wy - y) * j2 / 4, c, al * 3u / 5u, rr > 1 ? rr - 1 : 1); }
            }
        }
    }
    for (k = 0; k < NSPK; k++) {                 /* chip sparks: square pixels on a 3 px grid, fading in four steps */
        spark_t *q = &SPK[k];
        int32_t x, y, dx, dy;
        uint32_t al;
        uint16_t c;
        if (q->age >= q->life) continue;
        x = (q->x >> 8) / 3 * 3; y = (q->y >> 8) / 3 * 3;
        al = 64u * (4u - (uint32_t)q->age * 4u / q->life);
        c = RGB565(q->c[0], q->c[1], q->c[2]);
        for (dy = 0; dy < q->sz; dy++) for (dx = 0; dx < q->sz; dx++) {
            if (S.lens == 1) pxadd(x + dx, y + dy, scale565(c, al));
            else { int32_t yy = y + dy - ry0, xx = x + dx; if ((uint32_t)yy < (uint32_t)rh && (uint32_t)xx < 240u) rb[yy * 240 + xx] = mix565(rb[yy * 240 + xx], c, al); }
        }
    }
    for (k = 0; k < 4; k++) {                    /* a ripple per syllable, travelling out from where it was sung */
        ripple_t *r = &RIP[k];
        int32_t rr;
        uint32_t al;
        if (r->age >= 900u) continue;
        rr = (6 + (int32_t)r->age * 80 / 900) << 4;
        al = 200u * (900u - r->age) / 900u;
        aring(r->x, r->y, rr, rr * 4 / 5, 0, 0xFFFFFFFFu, scale565(RGB565(r->c[0], r->c[1], r->c[2]), S.lens == 1 ? al : al * 3u / 4u));
        aring(r->x, r->y, rr - 24, (rr - 24) * 4 / 5, 0, 0xFFFFFFFFu, scale565(RGB565(r->c[0], r->c[1], r->c[2]), al >> 2));
    }
    if (NM.say > 900) {                          /* three formant halos round the beak: each ring is one band's own output */
        static const uint8_t FC[3][3] = {{255, 170, 90}, {120, 220, 255}, {200, 150, 255}};
        for (k = 0; k < 3; k++) {
            int32_t rr = (8 + k * 7 + (NM.sb[k] * 14 >> 15)) << 4;
            uint32_t al = (uint32_t)(NM.sb[k] >> 7) * (uint32_t)(NM.say >> 7) >> 7;
            if (al > 256u) al = 256u;
            if (al < 8u) continue;
            aring(beak_x, beak_y, rr, rr * 3 / 4, 0, 0xFFFFFFFFu, scale565(RGB565(FC[k][0], FC[k][1], FC[k][2]), S.lens == 1 ? al : al * 3u / 4u));
            aring(beak_x, beak_y, rr + 16, (rr + 16) * 3 / 4, 0, 0xFFFFFFFFu, scale565(RGB565(FC[k][0], FC[k][1], FC[k][2]), al >> 2));
        }
    }
}
static void overlays_strip(void)                 /* signal shapes that are not part of the body */
{
    const kt_planet_t *P = &KT_PLANETS[cur_planet];
    uint16_t hi = RGB565(P->gl2[0], P->gl2[1], P->gl2[2]), md = RGB565(P->gl1[0], P->gl1[1], P->gl1[2]), lo = RGB565(P->gl0[0], P->gl0[1], P->gl0[2]);
    uint16_t net = S.lens == 1 ? RGB565(255, 150, 70) : S.lens == 0 ? RGB565(232, 120, 50) : RGB565(255, 255, 255);
    int k;
    if (vis_layers & 2) {                       /* GRAINS: the network. Each grain is a star; recent ones join up */
        for (k = 0; k < NNODE; k++) {
            node_t *n = &NODE[k], *m = &NODE[(k + NNODE - 1) % NNODE];
            uint32_t a, b2;
            if (n->age >= n->life) continue;
            a = (uint32_t)(n->life - n->age) * 256u / n->life * ((uint32_t)n->amp + 80u) >> 8;
            if (m->age < m->life && (uint32_t)((n->x - m->x) * (n->x - m->x) + (n->y - m->y) * (n->y - m->y)) < 110u * 110u) {
                b2 = (uint32_t)(m->life - m->age) * 256u / m->life;
                aline(n->x << 4, n->y << 4, m->x << 4, m->y << 4, scale565(net, (a < b2 ? a : b2) * (S.lens == 0 ? 120u : 90u) >> 8));
            }
            pxadd(n->x, n->y, scale565(net, a)); pxadd(n->x - 1, n->y, scale565(net, a >> 1)); pxadd(n->x + 1, n->y, scale565(net, a >> 1));
            pxadd(n->x, n->y - 1, scale565(net, a >> 1)); pxadd(n->x, n->y + 1, scale565(net, a >> 1));
            if (n->age < 160u) { pxadd(n->x - 2, n->y, scale565(net, a >> 2)); pxadd(n->x + 2, n->y, scale565(net, a >> 2)); pxadd(n->x, n->y - 2, scale565(net, a >> 2)); pxadd(n->x, n->y + 2, scale565(net, a >> 2)); }
        }
    }
    if (vis_layers & 1) for (k = 0; k < 4; k++) {   /* VOICE: a ribbon streamer for each sounding voice, swayed by the MOTION LFO */
        int32_t w = top_vw[k], j, len, x0, y0, px0, py0;
        uint16_t col;
        if (w < 12 || top_vi[k] < 0) continue;
        col = RGB565(top_vc[k][0], top_vc[k][1], top_vc[k][2]);
        x0 = (k & 1) ? 228 - (k >> 1) * 13 : 12 + (k >> 1) * 13; y0 = -2;
        len = 4 + w * 9 / 256;
        px0 = x0 << 4; py0 = y0 << 4;
        for (j = 1; j <= 12; j++) {
            int32_t sway = (vis_layers & 4) ? (kt_sine(a_lfo_ph + (uint32_t)k * 0x30000000u + (uint32_t)j * 0x0B000000u) * (2 + j)) >> 13 : 0;
            int32_t xx = (x0 << 4) + sway * 4 + ((k & 1) ? -j * 6 : j * 6), yy = (y0 + j * len) << 4;
            uint32_t a = (uint32_t)(120 + w / 2 + (NM.attack >> 9));
            aline(px0, py0, xx, yy, scale565(col, a > 256u ? 256u : a));
            aline(px0 + 16, py0, xx + 16, yy, scale565(col, (a > 256u ? 256u : a) >> 1));
            px0 = xx; py0 = yy;
        }
    }
    if ((vis_layers & 16) && ap_perc) {         /* RHYTHM: a kick ring across the floor, snare arcs to the sides, hat glints */
        if (NM.kick > 1200) {
            int32_t rr = (24 + (32767 - NM.kick) * 70 / 32767) << 4;
            aring(SCX, LEDGE + 6, rr, rr / 6, 0, 0xFFFFFFFFu, scale565(hi, (uint32_t)(NM.kick >> 7)));
        }
        if (NM.snare > 900) {
            int32_t rr = (50 + (32767 - NM.snare) * 50 / 32767) << 4;
            aring(SCX, LEDGE - 6, rr, rr * 2 / 3, 0x60000000u, 0x9FFFFFFFu, scale565(lo, (uint32_t)(NM.snare >> 7)));
            aring(SCX, LEDGE - 6, rr, rr * 2 / 3, 0xE0000000u, 0x1FFFFFFFu, scale565(lo, (uint32_t)(NM.snare >> 7)));
        }
        if (NM.hat > 600 && bbx1 > bbx0) {
            uint32_t h = (uint32_t)a_hat_pk * 2654435761u + a_drum_step;
            int n = NM.hat >> 10;
            for (k = 0; k < n; k++) {
                int32_t x, y;
                h = kt_hash(h + (uint32_t)k);
                x = bbx0 + (int32_t)(h % (uint32_t)(bbx1 - bbx0 + 1)); y = bby0 + (int32_t)((h >> 12) % (uint32_t)(bby1 - bby0 + 1));
                if (y >= ry0 && y < ry0 + rh && kt_zb[(y - ry0) * 240 + x] > -32768) { pxadd(x, y, RGB565(255, 255, 255)); pxadd(x + 1, y, RGB565(120, 120, 120)); }
            }
        }
    }
    if ((vis_layers & 1) && NM.dry > 600) {     /* VOICE: the actual waveform, a fine line on the floor */
        int32_t px0 = 0, py0 = 0;
        for (k = 0; k < 64; k++) {
            int32_t x = (40 + k * 160 / 63) << 4, y = (226 << 4) - (int32_t)(((int64_t)NM.wave[k] * (6 + (NM.dry >> 11))) >> 11);
            if (k) aline(px0, py0, x, y, scale565(md, 110u + (uint32_t)(NM.dry >> 9)));
            px0 = x; py0 = y;
        }
    }
    if (vis_layers & 1) singer_strip();
    if ((vis_layers & 8) && NM.shim > 2000)     /* FX: shimmer, a high thin ring */
        aring(SCX, SCY, 100 << 4, 92 << 4, 0, 0xFFFFFFFFu, scale565(RGB565(245, 245, 255), (uint32_t)(NM.shim >> 8)));
}

static void shade_rect(int32_t x, int32_t y, int32_t w, int32_t h, uint32_t t)
{
    int32_t i, j;
    for (j = y; j < y + h; j++) {
        int32_t yy = j - ry0;
        if ((uint32_t)yy >= (uint32_t)rh) continue;
        for (i = x; i < x + w; i++) if ((uint32_t)i < 240u) rb[yy * 240 + i] = scale565(rb[yy * 240 + i], t);
    }
}
static int32_t text(int32_t x, int32_t y, const felucca_font_t *f, const char *s, uint16_t c, uint32_t alpha)
{
    if (y >= ry0 + rh || y + f->h <= ry0) {   /* not in this strip: just measure */
        for (; *s; s++) { uint32_t ch = (uint8_t)*s; if (ch >= 'a' && ch <= 'z' && f->last < 'a') ch -= 32u; if (ch < f->first || ch > f->last) ch = '?'; x += f->adv[ch - f->first]; }
        return x;
    }
    for (; *s; s++) {
        uint32_t ch = (uint8_t)*s, gi, gx, gy, w, bpr;
        const uint8_t *gd;
        if (ch >= 'a' && ch <= 'z' && f->last < 'a') ch -= 32u;
        if (ch < f->first || ch > f->last) ch = '?';
        gi = ch - f->first;
        w = f->bw[gi]; bpr = (w + 1u) / 2u; gd = f->data + f->off[gi];
        for (gy = 0; gy < f->h; gy++) {
            int32_t yy = y + (int32_t)gy - ry0;
            if ((uint32_t)yy >= (uint32_t)rh) continue;
            for (gx = 0; gx < w; gx++) {
                uint32_t v = gd[gy * bpr + gx / 2u];
                int32_t xx = x - f->pad + (int32_t)gx;
                v = (gx & 1u) ? (v & 15u) : (v >> 4);
                if (v && (uint32_t)xx < 240u) rb[yy * 240 + xx] = mix565(rb[yy * 240 + xx], c, v * 17u * alpha >> 8);
            }
        }
        x += f->adv[gi];
    }
    return x;
}
static int32_t tw(const felucca_font_t *f, const char *s) { int32_t ry = ry0; int32_t w; ry0 = -10000; w = text(0, 0, f, s, 0, 0); ry0 = ry; return w; }
static void text_c(int32_t y, const felucca_font_t *f, const char *s, uint16_t c, uint32_t a) { text((240 - tw(f, s)) / 2, y, f, s, c, a); }
static void lyric(int32_t y, const felucca_font_t *f, uint16_t ink, uint32_t a)   /* MA RA DO NNA, lit by the syllable being sung */
{
    static const char *const SY[4] = {"MA", "RA", "DO", "NNA"};
    int32_t x = (240 - tw(f, "MARADONNA")) / 2, k;
    for (k = 0; k < 4; k++) {
        uint32_t al = a;
        int32_t lift = 0, w = tw(f, SY[k]);
        if (NM.syl == k) { al = a; lift = NM.say * (f == &FONT_L ? 4 : 2) >> 15; }
        else if (NM.syl >= 0 || NM.say > 1500) al = k <= NM.syl_hi ? a * 3u / 4u : a * 5u / 16u;
        text(x, y - lift, f, SY[k], ink, al);
        if (NM.syl == k && NM.say > 2000) {     /* the sung syllable glows in its vowel's colour */
            uint8_t c[3];
            vowel_rgb(ao_vx_f1, ao_vx_f2, c);
            text(x + 1, y - lift + 1, f, SY[k], RGB565(c[0], c[1], c[2]), (uint32_t)(NM.say >> 8) * a >> 8);
        }
        x += w;
    }
}
static void polygon(int32_t cx, int32_t cy, int32_t r, int sides, uint32_t ph, uint16_t c)
{
    int i, n = sides < 3 ? 12 : sides, step = sides == 7 ? 3 : 1;
    int32_t x0 = 0, y0 = 0, x1, y1;
    for (i = 0; i <= n; i++) {
        uint32_t a = ph + (uint32_t)((i * step) % n) * (0xFFFFFFFFu / (uint32_t)n);
        x1 = cx + ((r * kt_sine(a)) >> 15);
        y1 = cy + ((r * kt_sine(a + 0x40000000u)) >> 15);
        if (i) line(x0, y0, x1, y1, c);
        x0 = x1; y0 = y1;
    }
}

KT_API void kt_render(uint16_t *buf, int y0, int h, int swap)
{
    const kt_planet_t *P = &KT_PLANETS[cur_planet];
    int32_t x, k;
    uint32_t warpdim = 256;
    rb = buf; ry0 = y0; rh = h;
    if (warp == 1) warpdim = 64u + (uint32_t)ao_level * 192u / 32767u;
    else if (warp == 2) warpdim = 64u;
    else if (warp == 3) warpdim = 64u + (uint32_t)ao_level * 192u / 32767u;
    stage_rows(warpdim);
    if (!warp) { bird_strip(); overlays_strip(); }
    if (!warp && eye_vis && eye_y >= ry0 && eye_y < ry0 + rh) {   /* the eye: a dark bead and its highlight */
        px(eye_x, eye_y, RGB565(14, 18, 28)); px(eye_x + 1, eye_y, RGB565(14, 18, 28)); px(eye_x, eye_y + 1, RGB565(14, 18, 28)); px(eye_x + 1, eye_y + 1, RGB565(30, 34, 44));
        px(eye_x, eye_y, RGB565(250, 250, 244));
    }
    /* voices on their orbits, and the freshest grain motes, crisp */
    if (!warp) {
        uint16_t acc = RGB565(P->gl1[0], P->gl1[1], P->gl1[2]);
        if (P->ring) {                              /* a planetary ring, tilted */
            for (k = 0; k < 96; k++) {
                uint32_t a = (uint32_t)k << 26 >> 0;
                int32_t c = kt_sine((uint32_t)k * 0x2AAAAAAu), s = kt_sine((uint32_t)k * 0x2AAAAAAu + 0x40000000u), rx = PR * 2 + 22;
                (void)a;
                if (s < 0 && (c * c >> 15) < 20000) continue;   /* behind the planet */
                pxadd(PCX * 2 + ((rx * c) >> 15), PCY * 2 + ((rx * 28 / 100 * s) >> 15), scale565(acc, 120));
            }
        }
        for (k = 0; k < NSEED; k++) {
            int32_t sx, sy, fr, a = ao_amp[k], r;
            uint16_t col;
            uint8_t cc[3];
            if (a < 300) continue;
            seed_xy(k, &sx, &sy, &fr);
            if (!fr) {                              /* behind the planet: hidden by it */
                int32_t dx = sx - PCX * 2, dy = sy - PCY * 2;
                if (dx * dx + dy * dy < PR * PR * 4) continue;
            }
            {
                uint32_t hh = (uint32_t)sm[k].deg * 256u / KT_SCALES[P->scale].len;
                if (hh < 128u) lerp3(P->gl0, P->gl1, hh * 2u, cc); else lerp3(P->gl1, P->gl2, (hh - 128u) * 2u, cc);
            }
            col = RGB565(cc[0], cc[1], cc[2]);
            r = 2 + (a >> 13);
            {   /* a small glowing wisp with a short tail along its orbit */
                int32_t dx2, dy2, tx = sx - (sm[k].speed > 0 ? 6 : -6), ty = sy + 2;
                uint32_t al = 120u + (uint32_t)(a >> 8);
                for (dy2 = -r; dy2 <= r; dy2++) for (dx2 = -r; dx2 <= r; dx2++) { int32_t d2 = dx2 * dx2 + dy2 * dy2; if (d2 <= r * r) pxadd(sx + dx2, sy + dy2, scale565(col, al * (uint32_t)(r * r + 1 - d2) / (uint32_t)(r * r + 1))); }
                aline(sx << 4, sy << 4, tx << 4, ty << 4, scale565(col, al >> 1));
            }
        }
        for (k = 0; k < NPART; k++) {               /* the freshest motes, crisp */
            part_t *p = &pt[k];
            if (!p->on || p->age > 1500u) continue;
            pxadd(p->x >> 7, p->y >> 7, scale565(kt_glut[p->hue * 32u + 31u], ((uint32_t)p->amp + 60u) * (1500u - p->age) / 1500u + 30u));
        }
    }
    /* quiet always-visible species identifier; readable even without a popup. */
    if (!help_on && now_ms >= splash_until && now_ms >= title_until) {
        uint16_t ink = S.lens == 1 ? RGB565(P->gl2[0], P->gl2[1], P->gl2[2]) : scale565(RGB565(P->pl0[0], P->pl0[1], P->pl0[2]), 200);
        text(10, 8, &FONT_S, P->name, ink, 228);
        text(160, 8, &FONT_S, "MARADONNA", ink, 120);
    }
    /* words */
    if (now_ms < splash_until) {
        uint32_t a = splash_until - now_ms > 1500u ? 256u : (splash_until - now_ms) * 256u / 1500u;
        uint16_t ink = S.lens == 1 ? RGB565(255, 220, 200) : scale565(RGB565(P->pl0[0], P->pl0[1], P->pl0[2]), 190);
        lyric(20, &FONT_L, ink, a);
        text_c(56, &FONT_S, "8 birds / 8 voices", ink, a * 3u / 4u);
    } else if (now_ms < title_until) {
        const kt_planet_t *T = &KT_PLANETS[warp ? next_planet : cur_planet];
        uint32_t a = title_until - now_ms > 1200u ? 256u : (title_until - now_ms) * 256u / 1200u;
        uint16_t ink = S.lens == 1 ? RGB565(T->gl2[0], T->gl2[1], T->gl2[2]) : scale565(RGB565(T->pl0[0], T->pl0[1], T->pl0[2]), 190);
        text_c(8, &FONT_L, T->name, ink, a);
        text_c(42, &FONT_S, T->mood, ink, a * 3u / 4u);
    }
    if (now_ms >= splash_until && (NM.syl >= 0 || NM.say > 1500) && !help_on) {   /* a later greeting: the lyric, small */
        uint16_t ink = S.lens == 1 ? RGB565(P->gl2[0], P->gl2[1], P->gl2[2]) : scale565(RGB565(P->pl0[0], P->pl0[1], P->pl0[2]), 200);
        lyric(196, &FONT_S, ink, 256);
    }
    if (popup_p >= 0 && now_ms < popup_until && !help_on) {
        char b[24];
        const char *nm = "";
        int v = -1, n;
        uint16_t col = RGB565(P->gl2[0], P->gl2[1], P->gl2[2]);
        shade_rect(0, 212, 240, 28, 90);
        switch (popup_p) {
        case 10: nm = S.octave < 0 ? (S.octave == -2 ? "OCTAVE -2" : "OCTAVE -1") : S.octave ? (S.octave == 2 ? "OCTAVE +2" : "OCTAVE +1") : "OCTAVE 0"; break;
        case 11: nm = S.shimmer ? "SHIMMER ON" : "SHIMMER OFF"; break;
        case 12: nm = "MUTATED"; break;
        case 13: nm = S.swell ? "SLOW SWELL" : "QUICK TOUCH"; break;
        case 14: nm = S.pal == 0 ? "COLOURS: TRUE" : S.pal == 1 ? "COLOURS: TURNED" : S.pal == 2 ? "COLOURS: STRANGE" : "COLOURS: MOON"; break;
        case 15: nm = S.lens == 0 ? "SCENE: ATELIER" : S.lens == 1 ? "SCENE: NOCTURNE" : "SCENE: PRISM"; break;
        case 16: nm = "SAVED"; break;
        case 17: nm = S.pulse ? "PULSE ON" : "PULSE OFF"; break;
        case 18: nm = S.autoplay ? "FLOCK PLAYS" : "YOU PLAY"; break;
        case 19: nm = S.hold ? "HOLD: FROZEN" : "HOLD OFF"; break;
        case 20: nm = S.perc ? "FEET: ON" : "FEET: OFF"; break;
        default: nm = P_NAME[popup_p]; v = S.p[popup_p]; break;
        }
        for (n = 0; nm[n] && n < 20; n++) b[n] = nm[n];
        b[n] = 0;
        text(8, 218, &FONT_S, b, col, 256);
        if (v >= 0) {
            int32_t bx = 110, bw = 120 * v / 127, yy;
            for (yy = 222; yy < 230; yy++) for (x = 0; x < 120; x++) px(bx + x, yy, x < bw ? col : RGB565(30, 30, 40));
        }
    }
    if (help_on) {
        static const char *const H[] = {"K1 FORM   K2 FLOCK", "K3 FLUTTER K4 MOTION", "SELECT AIR ALG COLOUR", "PRESETS: SPECIES",
                                        "PLAY flock REC hold", "SEQ feet: drums on/off", "ARP pulse ENV swell", "LFO colours  SCL evolve",
                                        "FX shimmer GLO bloom", "EDIT scene: 3 stages"};
        shade_rect(0, 0, 240, 240, 60);
        for (k = 0; k < 10; k++) text(10, 12 + k * 22, &FONT_S, H[k], RGB565(P->gl2[0], P->gl2[1], P->gl2[2]), 256);
    }
    if (swap) {
        uint32_t n = (uint32_t)h * 240u, i;
        for (i = 0; i < n; i++) buf[i] = (uint16_t)((buf[i] >> 8) | (buf[i] << 8));
    }
}
