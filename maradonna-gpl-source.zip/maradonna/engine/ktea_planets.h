/* SPDX-License-Identifier: GPL-3.0-only */
/* K-Tea: the planets. Each is a sound recipe, a scale, a palette and a geometry.
 * Adding a planet costs a few hundred bytes: the sound is generated when you travel there. */
#pragma once
#include <stdint.h>

enum { KIND_KTEA, KIND_CRYSTAL, KIND_AMBER, KIND_MOSS, KIND_TIDE, KIND_EMBER, KIND_AURORA, KIND_NEBULA };
enum { TEX_SOFT, TEX_FACET, TEX_BANDS, TEX_MOSS, TEX_OCEAN, TEX_LAVA, TEX_ICE, TEX_SWIRL };

typedef struct { uint8_t len; int8_t st[7]; } kt_scale_t;
static const kt_scale_t KT_SCALES[] = {
    {5, {0, 2, 4, 7, 9}},              /* 0 major pentatonic */
    {7, {0, 2, 4, 6, 7, 9, 11}},       /* 1 lydian */
    {7, {0, 2, 3, 5, 7, 9, 10}},       /* 2 dorian */
    {7, {0, 2, 4, 5, 7, 9, 10}},       /* 3 mixolydian */
    {7, {0, 2, 3, 5, 7, 8, 10}},       /* 4 aeolian */
    {7, {0, 1, 3, 5, 7, 8, 10}},       /* 5 phrygian */
    {7, {0, 2, 4, 5, 7, 9, 11}},       /* 6 ionian */
    {5, {0, 3, 5, 7, 10}},             /* 7 minor pentatonic */
};

typedef struct {
    const char *name, *mood;
    uint8_t root;                      /* MIDI note of the lowest key's degree */
    uint8_t scale, kind, tex;
    uint8_t sides;                     /* seed polygon: 0 circle, 3.. sides; 7 draws a star */
    uint8_t ring;                      /* planetary ring */
    int8_t wind_x, wind_y;             /* particle drift, 1/16 px per frame (low-res) */
    uint8_t trail;                     /* glow memory, 200..250: higher = longer trails */
    uint8_t spin;                      /* planet rotation speed */
    uint8_t sky0[3], sky1[3], neb[3];  /* sky top, sky bottom, nebula */
    uint8_t pl0[3], pl1[3], pl2[3];    /* planet: dark, mid, light */
    uint8_t gl0[3], gl1[3], gl2[3];    /* glow: low, mid, high pitch */
    uint8_t def[6];                    /* size, density, scatter, drift, space, tone */
} kt_planet_t;

/* Each pigeon is a complete voice / scale / motion / colour theme.
 * Name strings are intentionally short enough for the FM-1 screen. */
static const kt_planet_t KT_PLANETS[] = {
    {"ROCK DOVE", "warm urban coos", 46, 0, KIND_KTEA, TEX_SOFT, 5, 0, 0, -2, 235, 2,
     {13, 22, 40}, {46, 63, 93}, {115, 145, 174},
     {52, 67, 104}, {145, 163, 190}, {224, 232, 241},
     {108, 234, 229}, {183, 110, 235}, {255, 192, 134},
     {66, 64, 24, 34, 79, 65}},
    {"FANTAIL", "glass plumes and bells", 52, 1, KIND_CRYSTAL, TEX_FACET, 7, 0, 1, -3, 226, 3,
     {30, 12, 47}, {85, 45, 103}, {198, 112, 171},
     {116, 72, 117}, {239, 173, 205}, {255, 242, 230},
     {246, 163, 235}, {255, 224, 161}, {184, 248, 252},
     {52, 57, 24, 55, 105, 94}},
    {"KING", "rounded bass and velvet", 41, 2, KIND_AMBER, TEX_BANDS, 4, 0, 1, 0, 238, 1,
     {22, 25, 30}, {87, 79, 66}, {161, 143, 105},
     {67, 69, 63}, {159, 151, 120}, {244, 224, 177},
     {255, 176, 85}, {255, 214, 155}, {221, 237, 177},
     {92, 65, 23, 25, 75, 43}},
    {"JACOBIN", "breathy ruff and air", 47, 3, KIND_MOSS, TEX_MOSS, 6, 0, -1, -2, 240, 1,
     {8, 33, 35}, {33, 86, 81}, {84, 142, 112},
     {31, 79, 78}, {94, 170, 144}, {202, 242, 201},
     {124, 244, 169}, {221, 252, 174}, {111, 209, 247},
     {76, 80, 33, 44, 101, 66}},
    {"TUMBLER", "liquid diving glides", 45, 4, KIND_TIDE, TEX_OCEAN, 3, 0, 3, 2, 246, 4,
     {7, 17, 54}, {19, 58, 117}, {40, 123, 172},
     {17, 48, 111}, {66, 170, 210}, {166, 245, 241},
     {89, 130, 247}, {73, 235, 240}, {230, 177, 252},
     {80, 63, 46, 62, 113, 72}},
    {"POUTER", "brassy low throbs", 40, 5, KIND_EMBER, TEX_LAVA, 4, 0, -1, -6, 223, 3,
     {40, 17, 32}, {115, 48, 64}, {201, 94, 75},
     {72, 37, 61}, {202, 96, 99}, {254, 202, 120},
     {255, 99, 106}, {255, 167, 101}, {255, 238, 170},
     {76, 100, 55, 39, 82, 65}},
    {"NICOBAR", "iridescent choir", 50, 6, KIND_AURORA, TEX_ICE, 8, 0, 0, -1, 246, 2,
     {12, 17, 38}, {31, 66, 90}, {58, 111, 114},
     {34, 63, 88}, {45, 166, 162}, {197, 248, 199},
     {70, 240, 172}, {159, 114, 252}, {250, 232, 117},
     {102, 76, 34, 58, 114, 93}},
    {"RACER", "electric precise motion", 48, 7, KIND_NEBULA, TEX_SWIRL, 5, 0, 5, 0, 226, 5,
     {16, 15, 47}, {48, 32, 113}, {104, 55, 190},
     {31, 29, 91}, {132, 101, 241}, {243, 204, 255},
     {109, 117, 255}, {251, 113, 208}, {255, 222, 101},
     {55, 96, 51, 88, 107, 100}},
};
#define KT_NPLANETS ((int)(sizeof(KT_PLANETS) / sizeof(KT_PLANETS[0])))
