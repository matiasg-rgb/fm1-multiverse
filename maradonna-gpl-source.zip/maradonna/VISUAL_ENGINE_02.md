# MARADONNA / VISUAL ENGINE 02

## What changed
The browser now visualizes the sound graph rather than only animating 3D form with UI sliders. Audio processing remains in the original cross-platform C synthesis engine; its audible output is also measured by a Web Audio analyser. The visual system does not alter the exported settings format or add a dependency on a hosted service.

| Sound source or state | Readout / origin | Morphological effect | Screen layer |
|:--|:--|:--|:--|
| Tonal/voice activity | Real AudioContext spectrum (low, mid, high), audio peak, active seed voices | Breathing body, wing surface distortion, colour changes | VOICE |
| Grain density and triggers | Actual active grain slots and monotonic grain spawn count, exported from C | Spawn-triggered pastel motes, surface segmentation, fine rings | GRAINS |
| Engine modulation | Real scan position, flutter/density controls and time-domain motion | Wing flutter, tail fanning, scan-responsive movement | MOD |
| Atmospheric effects | Actual engine reverb wet-mix and shimmer toggle, bloom control and grain density | Translucent atmospheric halos, reflective glints, highlight bloom | FX |
| Rhythmic modulation | Actual kick, snare and hat envelopes, pulse phase and percussion toggle | Expanding footstep impact rings and small sharp accents | RHYTHM |

### Interactivity
- Click any signal strip to mute/unmute only its visual layer. Shift-click to solo a layer; click again to restore all when only one is left enabled. This never changes the sound.
- Select **Atelier**, **Nocturne**, or **Prism** to change stage mood; species palettes remain independent.
- The six hardware-matched controls still act on the *same C sound engine*. They also cause immediate visual changes.
- Turn on **Feet / Percussion** for the rhythmic engine; it is off by default. Rhythm graphics also react to actual kick/snare/hat envelope levels, not just metronomic guesswork.
- Granular particles are spawned by **real grain events**, but their screen positions are artistic approximations, not individual audio-source positions.
- Spectrum bands are taken from the real WebAssembly-generated audio after the voice engine, not from prerecorded or fake audio data.

### Browser / firmware differentiation
The browser uses a ray-marched pigeon in GPU WebGL, complemented by a transparent canvas-based signal field. Where WebGL is unavailable, the renderer displays the embedded native bird framebuffer with the same signal field and controls.

The hardware FM-1 has no WebGL. Its 240×240 framebuffer gains low-cost, fixed-point, sound-reactive vector rings (grains, reverb, footsteps, shimmer) over the existing native bird illustration. These changes use the existing 14-button, 7-encoder mapping.

### Compile / verification
- `./build_web.sh` recompiles the C engine to WebAssembly and embeds it into an offline, self-contained HTML instrument.
- `node tests-reactivity.mjs` checks the actual WebAssembly telemetry bridge, percussion off-by-default, grain event changes and kick/hat/snare envelopes.
- `cd fw && tests/run_host.sh tests/scripts/ktea_tour.txt` compiles the FM-1 host simulator and emits a WAV + screenshot frames.
- The WebGL shaders were **compiled, linked and rendered** in a software OpenGL ES 3 / ANGLE + Mesa test context; the test produced the three sample renders in this archive.
- Chromium headless exercised the browser fallback, spectrum analyser, live signals, percussion toggle, five interactive visual strips, and species changes, with no JavaScript exceptions. **It could not create a WebGL context** in that browser runner; browser-based GPU validation on real consumer hardware is still outstanding.
- Device `.fwsc` creation and physical hardware validation require the separate FM-1 proprietary build toolchain and board. This package does **not** include a flashed or verified native firmware image.

### Integrity and license
Synthetic pigeon-inspired sounds, not bioacoustic recordings. Based on K-Tea / Dinghy / Felucca code with retained GPL-3.0-only notices. See `fw/LICENSING.md`.
